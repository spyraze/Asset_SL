using System.Collections.Generic;
using Mirror;

namespace InventorySystem.Items.MicroHID.Modules
{
	public class EnergyManagerModule : MicroHidModuleBase
	{
		private static readonly Dictionary<ushort, float> SyncEnergy;

		private byte _serverLastSentEnergy;

		public float Energy => 0f;

		public static float GetEnergy(ushort serial)
		{
			return 0f;
		}

		public override void ClientProcessRpcTemplate(NetworkReader reader, ushort serial)
		{
		}

		internal override void OnClientReady()
		{
		}

		internal override void OnAdded()
		{
		}

		internal override void EquipUpdate()
		{
		}

		private byte EncodeEnergy(float energy)
		{
			return 0;
		}

		private float DecodeEnergy(byte compressed)
		{
			return 0f;
		}

		public void ServerSetEnergy(ushort serial, float amount)
		{
		}

		internal override void ServerOnPlayerConnected(ReferenceHub hub, bool firstSubcomponent)
		{
		}
	}
}
