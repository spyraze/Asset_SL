using System;
using Mirror;

namespace InventorySystem.Items.MicroHID.Modules
{
	public class InputSyncModule : MicroHidModuleBase
	{
		[Flags]
		private enum SyncData : byte
		{
			None = 0,
			Primary = 1,
			Secondary = 2
		}

		private SyncData? _lastSent;

		private SyncData _lastReceived;

		public bool Primary => false;

		public bool Secondary => false;

		public override void ServerProcessCmd(NetworkReader reader)
		{
		}

		internal override void OnHolstered()
		{
		}

		internal override void EquipUpdate()
		{
		}

		private void SerializeCmd(NetworkWriter writer)
		{
		}
	}
}
