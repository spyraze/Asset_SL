using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace InventorySystem.Items.MicroHID.Modules
{
	public class CycleController
	{
		private const float MinIdleCooldown = 1.5f;

		private float _windUpProgress;

		private float _serverIdleTimer;

		private bool _hasOwner;

		private MicroHidPhase _phase;

		private MicroHIDItem _prevItem;

		private readonly List<FiringModeControllerModule> _firingModeControllers;

		private readonly Dictionary<MicroHidPhase, double> _lastChangeTimes;

		public readonly ushort Serial;

		public float ServerWindUpProgress
		{
			get
			{
				return 0f;
			}
			private set
			{
			}
		}

		public float CurrentPhaseElapsed => 0f;

		public MicroHidPhase Phase
		{
			get
			{
				return default(MicroHidPhase);
			}
			set
			{
			}
		}

		public MicroHidFiringMode LastFiringMode { get; set; }

		public static event Action<ushort, MicroHidPhase> OnPhaseChanged
		{
			[CompilerGenerated]
			add
			{
			}
			[CompilerGenerated]
			remove
			{
			}
		}

		public CycleController(ushort serial)
		{
		}

		public void ServerUpdateHeldItem(MicroHIDItem item)
		{
		}

		public void ServerUpdatePickup(MicroHIDPickup pickup)
		{
		}

		public bool TryGetElapsed(MicroHidPhase phase, out float elapsed)
		{
			elapsed = default(float);
			return false;
		}

		public bool TryGetLastFiringController(out FiringModeControllerModule ret)
		{
			ret = null;
			return false;
		}

		private void RecacheFiringModes(MicroHIDItem item)
		{
		}

		private void UpdatePhase()
		{
		}

		private void UpdateStandby()
		{
		}

		private void UpdateWindingUp()
		{
		}

		private void UpdateWindingDown()
		{
		}

		private void UpdateWoundUp()
		{
		}

		private void UpdateFiring()
		{
		}
	}
}
