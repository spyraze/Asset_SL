using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Mirror;
using UnityEngine;

namespace InventorySystem.Items.MicroHID.Modules
{
	public class DrawAndInspectorModule : MicroHidModuleBase
	{
		private enum RpcType
		{
			AddPickup = 0,
			OnEquipped = 1,
			OnHolstered = 2,
			InspectRequested = 3
		}

		private static readonly HashSet<ushort> PickupAnimSerials;

		[SerializeField]
		private AudioClip _equipSound;

		[SerializeField]
		private AudioClip _pickupSound;

		public static event Action<ushort> OnInspectRequested
		{
			[CompilerGenerated]
			add
			{
			}
			[CompilerGenerated]
			remove
			{
			}
		}

		public static bool CheckPickupPreference(ushort serial)
		{
			return false;
		}

		public void ServerRegisterSerial(ushort serial)
		{
		}

		public override void ClientProcessRpcTemplate(NetworkReader reader, ushort serial)
		{
		}

		internal override void OnEquipped()
		{
		}

		internal override void OnHolstered()
		{
		}

		internal override void EquipUpdate()
		{
		}

		public override void ServerProcessCmd(NetworkReader reader)
		{
		}

		internal override void OnClientReady()
		{
		}

		internal override void ServerOnPlayerConnected(ReferenceHub hub, bool firstSubcomponent)
		{
		}
	}
}
