using System.Collections.Generic;
using Mirror;

namespace InventorySystem.Items.MicroHID.Modules
{
	public class WindupSyncModule : MicroHidModuleBase
	{
		private static readonly Dictionary<ushort, byte> ReceivedData;

		private void ServerUpdateController(CycleController cycle)
		{
		}

		internal override void OnClientReady()
		{
		}

		internal override void TemplateUpdate()
		{
		}

		public override void ClientProcessRpcTemplate(NetworkReader reader, ushort serial)
		{
		}

		public static float GetProgress(ushort serial)
		{
			return 0f;
		}
	}
}
