namespace InventorySystem.Items.MicroHID.Modules
{
	public enum MicroHidFiringMode
	{
		PrimaryFire = 0,
		ChargeFire = 1,
		BrokenFire = 2
	}
}
