using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Mirror;
using UnityEngine;

namespace InventorySystem.Items.MicroHID.Modules
{
	public class BrokenSyncModule : MicroHidModuleBase
	{
		private enum RpcType
		{
			BreakSpecific = 0,
			ResyncAll = 1,
			UnbreakSpecific = 2
		}

		private static readonly Dictionary<ushort, double> BrokenSerialTimes;

		[SerializeField]
		private AudioClip _explosionClip;

		[SerializeField]
		private float _explosionSoundRange;

		public bool Broken => false;

		public static event Action<ushort> OnBroken
		{
			[CompilerGenerated]
			add
			{
			}
			[CompilerGenerated]
			remove
			{
			}
		}

		public static bool GetBroken(ushort serial)
		{
			return false;
		}

		public static bool TryGetBrokenElapsed(ushort serial, out float elapsed)
		{
			elapsed = default(float);
			return false;
		}

		public void ServerSetBroken(ushort serial, bool broken)
		{
		}

		public void ServerSetBroken()
		{
		}

		public override void ClientProcessRpcTemplate(NetworkReader reader, ushort serial)
		{
		}

		internal override void OnClientReady()
		{
		}

		internal override void OnAdded()
		{
		}

		internal override void ServerOnPlayerConnected(ReferenceHub hub, bool firstSubcomponent)
		{
		}
	}
}
