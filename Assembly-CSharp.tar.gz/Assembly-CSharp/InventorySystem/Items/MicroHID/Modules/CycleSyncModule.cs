using System;
using System.Collections.Generic;
using Mirror;

namespace InventorySystem.Items.MicroHID.Modules
{
	public class CycleSyncModule : MicroHidModuleBase
	{
		private class SyncedCycleController
		{
			public readonly CycleController Controller;

			public MicroHidPhase? LastSentPhase;

			public bool NeedsResync => false;

			public SyncedCycleController(ushort serial)
			{
			}

			public void WriteSelf(NetworkWriter writer)
			{
			}
		}

		private static readonly List<SyncedCycleController> SyncControllers;

		private CycleController _instCycleController;

		public static CycleController GetCycleController(ushort serial)
		{
			return null;
		}

		public static MicroHidPhase GetPhase(ushort serial)
		{
			return default(MicroHidPhase);
		}

		public static MicroHidFiringMode GetFiringMode(ushort serial)
		{
			return default(MicroHidFiringMode);
		}

		public static void ForEachController(Action<CycleController> action)
		{
		}

		internal override void OnClientReady()
		{
		}

		internal override void TemplateUpdate()
		{
		}

		internal override void ServerOnPlayerConnected(ReferenceHub hub, bool firstSubcomponent)
		{
		}

		public override void ClientProcessRpcTemplate(NetworkReader reader, ushort serial)
		{
		}

		private void Update()
		{
		}

		private void ServerWriteAllDelta(NetworkWriter writer)
		{
		}

		private void ServerWriteAllActive(NetworkWriter writer)
		{
		}
	}
}
