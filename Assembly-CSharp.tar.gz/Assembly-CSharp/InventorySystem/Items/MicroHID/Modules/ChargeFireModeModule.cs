using Interactables;
using Interactables.Interobjects.DoorUtils;
using UnityEngine;

namespace InventorySystem.Items.MicroHID.Modules
{
	public class ChargeFireModeModule : FiringModeControllerModule
	{
		private static readonly DoorLockReason BypassableLocks;

		public const float MaxSustainBeforeExplosionSeconds = 15f;

		private const float RaycastThickness = 0.65f;

		private const float DamagePerSec = 1000f;

		private const float StartFiringEnergyUse = 0.1f;

		private const float ExplosionEnergyPenalty = 0.25f;

		private const float ExplosionPlayerDamage = 125f;

		private const float ExplosionDoorDamage = 350f;

		private const float ExplosionRadius = 10f;

		private const float ExplosionBlackoutSeconds = 1f;

		private MicroHidPhase _prevStatus;

		private float _woundUpElapsed;

		private bool _alreadyExploded;

		public override MicroHidFiringMode AssignedMode => default(MicroHidFiringMode);

		public override float WindUpRate => 0f;

		public override float WindDownRate => 0f;

		public override float DrainRateWindUp => 0f;

		public override float DrainRateSustain => 0f;

		public override float DrainRateFiring => 0f;

		public override bool ValidateStart => false;

		public override bool ValidateEnterFire => false;

		public override bool ValidateUpdate => false;

		public override float FiringRange => 0f;

		public override float BacktrackerDot => 0f;

		public override void ServerUpdateSelected(MicroHidPhase status)
		{
		}

		private void ServerOnModeChanged(MicroHidPhase status)
		{
		}

		private void ServerUpdateWoundUp()
		{
		}

		private void ServerExplode()
		{
		}

		private void ServerFire()
		{
		}

		private void HandlePotentialDoor(InteractableCollider interactable)
		{
		}

		private bool CheckIntercolLineOfSight(Vector3 originPoint, InteractableCollider collider)
		{
			return false;
		}
	}
}
