namespace InventorySystem.Items.MicroHID.Modules
{
	public class PrimaryFireModeModule : FiringModeControllerModule
	{
		private const float RaycastThickness = 0.2f;

		private const float DamagePerSec = 400f;

		public override MicroHidFiringMode AssignedMode => default(MicroHidFiringMode);

		public override float WindUpRate => 0f;

		public override float WindDownRate => 0f;

		public override float DrainRateWindUp => 0f;

		public override float DrainRateSustain => 0f;

		public override float DrainRateFiring => 0f;

		public override bool ValidateStart => false;

		public override bool ValidateEnterFire => false;

		public override bool ValidateUpdate => false;

		public override float FiringRange => 0f;

		public override float BacktrackerDot => 0f;

		private float FrameDamage => 0f;

		public override void ServerUpdateSelected(MicroHidPhase status)
		{
		}

		private void ServerFire()
		{
		}
	}
}
