namespace InventorySystem.Items.MicroHID.Modules
{
	public enum MicroHidPhase
	{
		Standby = 0,
		WindingUp = 1,
		WindingDown = 2,
		WoundUpSustain = 3,
		Firing = 4
	}
}
