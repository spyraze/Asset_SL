namespace InventorySystem.Items.MicroHID.Modules
{
	public class BrokenFireModeModule : FiringModeControllerModule
	{
		private const float FiringConeAngleDeg = 30f;

		private const float FiringAlwaysIncludeDistSqr = 1f;

		private const float DamagePerSecond = 400f;

		private static readonly float FiringConeDot;

		public override MicroHidFiringMode AssignedMode => default(MicroHidFiringMode);

		public override float WindUpRate => 0f;

		public override float WindDownRate => 0f;

		public override float DrainRateWindUp => 0f;

		public override float DrainRateSustain => 0f;

		public override float DrainRateFiring => 0f;

		public override bool ValidateStart => false;

		public override bool ValidateEnterFire => false;

		public override bool ValidateUpdate => false;

		public override float FiringRange => 0f;

		public override float BacktrackerDot => 0f;

		public override void ServerUpdateSelected(MicroHidPhase status)
		{
		}

		private void ServerFire()
		{
		}

		private bool CheckAngle(IDestructible dest)
		{
			return false;
		}
	}
}
