using System;
using System.Collections.Generic;
using UnityEngine;

namespace InventorySystem.Items.MicroHID.Modules
{
	public static class HitregUtils
	{
		public static readonly CachedLayerMask DetectionMask;

		public static readonly Collider[] DetectionsNonAlloc;

		public static readonly RaycastHit[] HitsNonAlloc;

		public static readonly HashSet<uint> DetectedNetIds;

		public static readonly List<IDestructible> DetectedDestructibles;

		public static bool ServerDealDamage(this IDestructible target, FiringModeControllerModule firingCtrl, float damage)
		{
			return false;
		}

		public static void Raycast(Transform plyCam, float thickness, float range, out int detections)
		{
			detections = default(int);
		}

		public static void OverlapSphere(Vector3 point, float radius, out int detections, Predicate<IDestructible> prevalidator = null)
		{
			detections = default(int);
		}
	}
}
