using System;
using System.Collections.Generic;
using AudioPooling;
using UnityEngine;

namespace InventorySystem.Items.MicroHID.Modules
{
	public class AudioController : MonoBehaviour, ISoundEmittingItem
	{
		[Serializable]
		private struct FiringClipSet
		{
			public MicroHidFiringMode FiringMode;

			public AudioClip WindUpClip;

			public AudioClip StopFiringClip;

			public AudioClip FireClip;

			public AudioClip AbortClip;

			public AnimationCurve AbortStartTimeOverElapsed;
		}

		private bool _cacheSet;

		private bool? _last3d;

		private MicroHidPhase _lastPhase;

		private Transform _cachedTransform;

		private bool _allSilent;

		private FiringClipSet _lastClipSet;

		private float _crossfadeSpeed;

		private readonly List<AudioPoolSession> _activeSessions;

		[SerializeField]
		private AudioSource _windupSource;

		[SerializeField]
		private AudioSource _winddownSource;

		[SerializeField]
		private AudioSource _firingSource;

		[SerializeField]
		private FiringClipSet[] _clipSets;

		public List<AudioPoolSession> ActiveSessions => null;

		public ushort Serial { get; set; }

		public bool Idle => false;

		public Transform FastTr => null;

		private void ValidateCache()
		{
		}

		private void AdjustVolume(AudioSource src, bool enable, float speed)
		{
		}

		private void AdjustVolumeFast(AudioSource src, bool enable)
		{
		}

		private void AdjustVolumeSlow(AudioSource src, bool enable)
		{
		}

		private void AdjustVolumeInstant(AudioSource src, bool enable)
		{
		}

		private void OnDestroy()
		{
		}

		public AudioPoolSession PlayOneShot(AudioClip clip, float range = 10f, MixerChannel mixer = MixerChannel.NoDucking)
		{
			return default(AudioPoolSession);
		}

		public void UpdateAudio(MicroHidPhase phase)
		{
		}

		private void UpdateConditionally(MicroHidPhase phase)
		{
		}

		private void Set3d(bool is3D)
		{
		}

		private void UpdateSourcePosition()
		{
		}

		private bool TryFindClipSet(out FiringClipSet clipSet)
		{
			clipSet = default(FiringClipSet);
			return false;
		}

		private void UpdateStandby()
		{
		}

		private void UpdateWindUp(bool changed)
		{
		}

		private void UpdateWindDown(bool changed)
		{
		}

		private void UpdateFiring(bool changed)
		{
		}

		public bool ServerTryGetSoundEmissionRange(out float range)
		{
			range = default(float);
			return false;
		}
	}
}
