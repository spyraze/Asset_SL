using System.Collections.Generic;
using InventorySystem.Items.Autosync;
using UnityEngine;

namespace InventorySystem.Items.MicroHID.Modules
{
	public class AudioManagerModule : MicroHidModuleBase
	{
		private static readonly Dictionary<ushort, AudioController> Instances;

		private static AudioController _globalAudioControllerTemplate;

		[SerializeField]
		private AudioController _audioControllerPrefab;

		public static AudioController GetController(ushort serial)
		{
			return null;
		}

		public static void RegisterDestroyed(AudioController destroyed)
		{
		}

		private static void UpdateInstance(CycleController cycleController)
		{
		}

		internal override void TemplateUpdate()
		{
		}

		internal override void OnTemplateReloaded(ModularAutosyncItem template, bool wasEverLoaded)
		{
		}
	}
}
