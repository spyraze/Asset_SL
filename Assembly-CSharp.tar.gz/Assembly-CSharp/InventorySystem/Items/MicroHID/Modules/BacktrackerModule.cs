using System;
using System.Collections.Generic;
using Mirror;
using PlayerRoles.FirstPersonControl;
using RelativePositioning;
using UnityEngine;

namespace InventorySystem.Items.MicroHID.Modules
{
	public class BacktrackerModule : MicroHidModuleBase
	{
		private struct BacktrackPair
		{
			public ReferenceHub Hub;

			public RelativePosition RelPos;

			public BacktrackPair(ReferenceHub hub, RelativePosition pos)
			{
				Hub = null;
				RelPos = default(RelativePosition);
			}
		}

		private const float TickCooldown = 0.05f;

		private const float WindupWarmupDuration = 0.3f;

		private const float AlwaysIncludeDistSqr = 4f;

		private const float BacktrackExpirationSeconds = 0.5f;

		private const float BacktrackExtraDistance = 4f;

		private float _remainingCooldown;

		private double _lastReceivedMessageTimestamp;

		private FiringModeControllerModule _lastFiringMode;

		private IFpcRole _lastOwnerFpc;

		private RelativePosition _receivedOwnerPosition;

		private Quaternion _receivedOwnerRotation;

		private readonly List<BacktrackPair> _receivedBacktracks;

		private static readonly List<FpcBacktracker> VictimBacktrackers;

		private void UpdateTick()
		{
		}

		private void ClientSendUpdate(FiringModeControllerModule firingCtrl)
		{
		}

		private void ClientWriteMessage(NetworkWriter writer)
		{
		}

		internal override void EquipUpdate()
		{
		}

		public override void ServerProcessCmd(NetworkReader reader)
		{
		}

		public void BacktrackAll(Action callback)
		{
		}
	}
}
