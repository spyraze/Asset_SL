using System;
using InventorySystem.Items.Firearms.Extensions;
using PlayerRoles.FirstPersonControl.Thirdperson;
using PlayerRoles.FirstPersonControl.Thirdperson.Subcontrollers;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Thirdperson
{
	[Serializable]
	public class LeftHandIKHandler : IHandPoseModifier
	{
		[Serializable]
		private struct Anchor
		{
			public Transform Point;

			public float PoseTime;

			public float PoseOverride;

			public ConditionalEvaluator Condition;
		}

		private Animator _anim;

		[SerializeField]
		private Anchor[] _anchors;

		public HandPoseData ProcessHandPose(HandPoseData data)
		{
			return default(HandPoseData);
		}

		public void Initialize(FirearmWorldmodel woldmodel, AnimatedCharacterModel model)
		{
		}

		public void IKUpdateLeftHandAnchor(float ikScale)
		{
		}
	}
}
