using System;
using InventorySystem.Items.Firearms.Extensions;
using PlayerRoles.FirstPersonControl.Thirdperson;
using PlayerRoles.FirstPersonControl.Thirdperson.Subcontrollers;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Thirdperson
{
	[Serializable]
	public class RightHandIKHandler : IHandPoseModifier
	{
		[Serializable]
		private struct RightHandSettings
		{
			public float IKPositionWeight;

			public Vector3 IKPosition;

			public float PoseTime;

			public float PoseWeight;

			public ConditionalEvaluator Condition;

			public RightHandSettings LerpTo(RightHandSettings target, float weight)
			{
				return default(RightHandSettings);
			}
		}

		private const float MinAimDistance = 1.2f;

		private const float IgnoreAimDistance = 0.05f;

		private const float CorrectionLerpSpeed = 9f;

		private Vector2 _prevCorrection;

		private float _lastAdsBlend;

		private AnimatedCharacterModel _model;

		[SerializeField]
		private Vector3 _handRotation;

		[SerializeField]
		private RightHandSettings[] _hipSettings;

		[SerializeField]
		private RightHandSettings[] _adsSettings;

		[SerializeField]
		private float _aimCorrectionIntensity;

		public HandPoseData ProcessHandPose(HandPoseData data)
		{
			return default(HandPoseData);
		}

		public void Initialize(FirearmWorldmodel woldmodel, AnimatedCharacterModel model)
		{
		}

		public void IKUpdateRightHandRotation(float ikScale, float adsBlend)
		{
		}

		private Vector2 CalculateAimCorrection(float blend, float aimDistance, Transform cam, Transform rightHand)
		{
			return default(Vector2);
		}

		private void ApplyIKRotation(Transform cam, Vector2 correction, float ikScale)
		{
		}

		private void ApplyIKPosition(Transform cam, Transform rightHand, float ikScale)
		{
		}

		private RightHandSettings GetCurSettings(float adsBlend)
		{
			return default(RightHandSettings);
		}
	}
}
