using System.Collections.Generic;
using System.Diagnostics;
using AnimatorLayerManagement;
using InventorySystem.Items.Thirdperson;
using InventorySystem.Items.Thirdperson.LayerProcessors;
using PlayerRoles.FirstPersonControl.Thirdperson.Subcontrollers;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Thirdperson
{
	public class FirearmThirdpersonItem : ThirdpersonItemBase, ILookatModifier, IHandPoseModifier
	{
		private enum FirearmAnim
		{
			Ads = 0,
			Hip = 1,
			Reload = 2
		}

		private readonly Dictionary<Light, Color> _defaultColors;

		private readonly Stopwatch _reloadElapsed;

		private const float DefaultEquipTime = 0.5f;

		private const float BlendTransitionSpeed = 4f;

		[SerializeField]
		private AnimationClip _hipAnim;

		[SerializeField]
		private AnimationClip _adsAnim;

		[SerializeField]
		private AnimationClip _reloadAnim;

		[SerializeField]
		private AnimOverrideState3pPair[] _additionalOverrideClips;

		[SerializeField]
		private bool _isAdsing;

		[SerializeField]
		private bool _isReloading;

		[SerializeField]
		private float _maxReloadTimeSeconds;

		[SerializeField]
		private LayerProcessorBase _regularLayerProcessor;

		[SerializeField]
		private LayerProcessorBase _reloadLayerProcessor;

		[Header("Inverse Kinematics")]
		[SerializeField]
		private LayerRefId _ikLayerRightHand;

		[SerializeField]
		private LayerRefId _ikLayerLeftHand;

		[SerializeField]
		private float _bodyIkMultiplier;

		[SerializeField]
		private float _bodyIkAbsolute;

		[SerializeField]
		private Vector3 _localPosition;

		[SerializeField]
		private Vector3 _localRotation;

		[SerializeField]
		private LeftHandIKHandler _leftHandIK;

		[SerializeField]
		private RightHandIKHandler _rightHandIK;

		[SerializeField]
		private bool _editorPauseIK;

		private float _prevAdsBlend;

		private bool _shotReceived;

		private bool _eventAssigned;

		private float _lastReloadBlend;

		private Firearm _template;

		public bool WorldmodelInstanceSet { get; private set; }

		public FirearmWorldmodel WorldmodelInstance { get; private set; }

		public override float GetTransitionTime(ItemIdentifier iid)
		{
			return 0f;
		}

		public override ThirdpersonLayerWeight GetWeightForLayer(AnimItemLayer3p layer)
		{
			return default(ThirdpersonLayerWeight);
		}

		public override void ResetObject()
		{
		}

		public LookatData ProcessLookat(LookatData data)
		{
			return default(LookatData);
		}

		public HandPoseData ProcessHandPose(HandPoseData data)
		{
			return default(HandPoseData);
		}

		protected override void Update()
		{
		}

		internal override void OnFadeChanged(float newFade)
		{
		}

		internal override void Initialize(InventorySubcontroller srctr, ItemIdentifier id)
		{
		}

		internal override void OnAnimIK(int layerIndex, float ikScale)
		{
		}

		private void OnAttachmentsUpdated(ushort serial, uint code)
		{
		}

		private void Awake()
		{
		}

		private void OnDestroy()
		{
		}

		private void UnsubscribeEvents()
		{
		}

		private void UpdateAnims()
		{
		}
	}
}
