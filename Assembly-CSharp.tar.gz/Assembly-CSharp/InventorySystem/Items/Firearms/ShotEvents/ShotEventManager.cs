using System.Runtime.CompilerServices;

namespace InventorySystem.Items.Firearms.ShotEvents
{
	public static class ShotEventManager
	{
		public delegate void Shot(ShotEvent shotEvent);

		public static event Shot OnShot
		{
			[CompilerGenerated]
			add
			{
			}
			[CompilerGenerated]
			remove
			{
			}
		}

		public static void Trigger(ShotEvent ev)
		{
		}
	}
}
