namespace InventorySystem.Items.Firearms.ShotEvents
{
	public interface IMultiBarreledShot
	{
		int BarrelId { get; }
	}
}
