namespace InventorySystem.Items.Firearms.ShotEvents
{
	public class BulletShotEvent : ShotEvent, IMultiBarreledShot
	{
		public int BarrelId { get; }

		public BulletShotEvent(ItemIdentifier shotFirearm)
			: base(default(ItemIdentifier))
		{
		}

		public BulletShotEvent(ItemIdentifier shotFirearm, int barrelId)
			: base(default(ItemIdentifier))
		{
		}
	}
}
