using UnityEngine;

namespace InventorySystem.Items.Firearms.Extensions
{
	public abstract class MixedExtension : MonoBehaviour, IWorldmodelExtension, IViewmodelExtension
	{
		public const int ViewmodelLayer = 10;

		public const int Worldmodellayer = 9;

		protected ItemIdentifier Identifier { get; private set; }

		protected FirearmWorldmodel Worldmodel { get; private set; }

		protected bool WorldmodelMode { get; private set; }

		protected bool ViewmodelMode { get; private set; }

		protected AnimatedFirearmViewmodel Viewmodel { get; private set; }

		public virtual void InitViewmodel(AnimatedFirearmViewmodel viewmodel)
		{
		}

		public virtual void SetupWorldmodel(FirearmWorldmodel worldmodel)
		{
		}

		public virtual void SetupAny()
		{
		}

		protected void SetLayer(int layer)
		{
		}

		private void SetLayer(int layer, Transform t)
		{
		}
	}
}
