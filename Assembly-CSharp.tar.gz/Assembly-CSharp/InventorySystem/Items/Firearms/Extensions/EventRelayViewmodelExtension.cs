using System;
using UnityEngine;
using UnityEngine.Events;

namespace InventorySystem.Items.Firearms.Extensions
{
	public class EventRelayViewmodelExtension : MonoBehaviour, IViewmodelExtension
	{
		[Serializable]
		private class Relay
		{
			public int GUID;

			public UnityEvent Action;
		}

		[SerializeField]
		private Relay[] _relays;

		public void InitViewmodel(AnimatedFirearmViewmodel viewmodel)
		{
		}

		private void OnTriggered(int guid)
		{
		}
	}
}
