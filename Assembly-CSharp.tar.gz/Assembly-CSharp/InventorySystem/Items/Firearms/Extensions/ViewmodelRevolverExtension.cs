using System;
using InventorySystem.Items.Firearms.Modules;
using InventorySystem.Items.Firearms.Modules.Misc;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Extensions
{
	public class ViewmodelRevolverExtension : MonoBehaviour, IViewmodelExtension
	{
		[SerializeField]
		private WorldmodelRevolverExtension.RoundsSet[] _roundsSets;

		[SerializeField]
		private int _cockedOffset;

		[SerializeField]
		private int _insertionOffset;

		[SerializeField]
		private AnimatorLayerMask _inspectTriggerOverrides;

		[SerializeField]
		private float _inspectTriggerWeightScale;

		private RevolverClipReloaderModule _clipModule;

		private CylinderAmmoModule _cylinderModule;

		private DoubleActionModule _doubleActionModule;

		private Action<int, float> _setWeightAction;

		private int _prevWithheld;

		private ushort _serial;

		public void InitViewmodel(AnimatedFirearmViewmodel viewmodel)
		{
		}

		private void OnDisable()
		{
		}

		private void OnAmmoInserted(int amt)
		{
		}

		private void OnAmmoWithheld()
		{
		}

		private void LateUpdate()
		{
		}
	}
}
