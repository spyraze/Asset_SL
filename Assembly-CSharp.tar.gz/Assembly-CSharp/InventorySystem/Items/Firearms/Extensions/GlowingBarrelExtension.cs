using System;
using System.Collections.Generic;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Extensions
{
	public class GlowingBarrelExtension : OverheatExtensionBase
	{
		[Serializable]
		private struct AffectedMaterial
		{
			public Renderer[] Renderers;
		}

		private static readonly Dictionary<Material, Queue<Material>> MaterialPool;

		private static readonly int TemperatureHash;

		[SerializeField]
		private AffectedMaterial[] _materialsToCopy;

		private Material[] _materialTemplates;

		private Material[] _materialInstances;

		private int _materialCount;

		protected override void OnTemperatureChanged(float temp)
		{
		}

		public override void OnDestroyExtension()
		{
		}

		private void Start()
		{
		}
	}
}
