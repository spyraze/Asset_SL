using System.Collections.Generic;
using Footprinting;
using InventorySystem.Items.Firearms.Modules;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Extensions
{
	public class DisruptorWorldmodelActionExtension : MonoBehaviour, IWorldmodelExtension, IPickupLockingExtension
	{
		private static readonly int DissolveHash;

		private static readonly Dictionary<Material, Queue<Material>> DissolveMatPool;

		private static readonly List<Material> MatsNonAlloc;

		private FirearmWorldmodel _worldmodel;

		private float[] _scheduledRemainingShotTimes;

		private Footprint _scheduledAttackerFootprint;

		private DisruptorActionModule.FiringState _scheduledFiringState;

		private Rigidbody _rigidbody;

		private float _breakingProgress;

		private bool _isWorldmodel;

		private Dictionary<Material, Material> _materialInstances;

		[SerializeField]
		private float _singleShotForce;

		[SerializeField]
		private float _rapidFireForce;

		[SerializeField]
		private float _torqueMultiplier;

		[SerializeField]
		private float _breakingSpeed;

		[SerializeField]
		private float _breakingDestroyThreshold;

		[SerializeField]
		private MeshRenderer[] _renderers;

		private bool Breaking => false;

		public bool LockPrefab => false;

		private void Update()
		{
		}

		private void Start()
		{
		}

		private void OnDestroy()
		{
		}

		private Material DuplicateMaterial(Material shared)
		{
			return null;
		}

		private void ReplaceMaterials(MeshRenderer rend)
		{
		}

		private void UpdateBreaking()
		{
		}

		private void ServerUpdateShots()
		{
		}

		private void ServerFire()
		{
		}

		public void SetupWorldmodel(FirearmWorldmodel worldmodel)
		{
		}

		public void ServerScheduleShot(Footprint attackerFootprint, DisruptorActionModule.FiringState firingState, float[] remainingShots)
		{
		}
	}
}
