using System;
using InventorySystem.Items.Firearms.Attachments;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Extensions
{
	public class WorldmodelRevolverExtension : MonoBehaviour, IWorldmodelExtension, IDestroyExtensionReceiver
	{
		[Serializable]
		public class RoundsSet
		{
			[SerializeField]
			private AttachmentLink _attachment;

			[SerializeField]
			private GameObject[] _liveRounds;

			[SerializeField]
			private GameObject[] _dischargedRounds;

			private bool _worldmodelMode;

			private bool _attachmentActive;

			private uint? _filter;

			public void Init(Firearm fa)
			{
			}

			public void Init(FirearmWorldmodel worldmodel)
			{
			}

			public void UpdateAmount(int amt, int offset)
			{
			}

			public void UpdateAmount(ushort serial, int offset)
			{
			}

			private bool Setup()
			{
				return false;
			}

			private GameObject GetSafe(GameObject[] arr, int index)
			{
				return null;
			}
		}

		[SerializeField]
		private RoundsSet[] _roundsSets;

		[SerializeField]
		private int _chambersOffset;

		[SerializeField]
		private BipolarTransform _hammer;

		private ushort _serial;

		private bool _eventsAssigned;

		public void OnDestroyExtension()
		{
		}

		public void SetupWorldmodel(FirearmWorldmodel worldmodel)
		{
		}

		private void UpdateChambers(ushort serial)
		{
		}

		private void OnCockedChanged(ushort serial, bool cocked)
		{
		}
	}
}
