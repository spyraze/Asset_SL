using System;
using System.Collections.Generic;
using InventorySystem.Items.Firearms.ShotEvents;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Extensions
{
	public abstract class ShootingEffectsExtensionBase : MixedExtension
	{
		[Serializable]
		protected struct ParticleCollection
		{
			public ParticleSystem[] ParticleSystems;

			public readonly void Play()
			{
			}

			public readonly void ConvertLights()
			{
			}
		}

		private static readonly HashSet<ShootingEffectsExtensionBase> Instances;

		private bool _standbyMode;

		protected virtual void OnEnable()
		{
		}

		protected virtual void OnDisable()
		{
		}

		protected virtual void Awake()
		{
		}

		protected virtual void OnDestroy()
		{
		}

		protected abstract void PlayEffects(ShotEvent ev);

		[RuntimeInitializeOnLoadMethod]
		private static void Init()
		{
		}

		public static void Play(ShotEvent ev)
		{
		}
	}
}
