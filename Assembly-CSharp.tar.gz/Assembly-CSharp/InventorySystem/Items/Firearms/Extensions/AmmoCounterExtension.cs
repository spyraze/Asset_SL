using System;
using InventorySystem.Items.Firearms.Modules;
using TMPro;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Extensions
{
	[PresetPrefabExtension("Ammo Counter Canvas", false)]
	[PresetPrefabExtension("Ammo Counter Canvas", true)]
	public class AmmoCounterExtension : MixedExtension
	{
		[SerializeField]
		private TMP_Text _targetText;

		[SerializeField]
		private int _digits;

		private string _toStringFormat;

		private Func<DisplayAmmoValues> _fetcher;

		private int _lastTotal;

		private void Start()
		{
		}

		private void LateUpdate()
		{
		}

		public override void InitViewmodel(AnimatedFirearmViewmodel viewmodel)
		{
		}

		public override void SetupWorldmodel(FirearmWorldmodel worldmodel)
		{
		}
	}
}
