using UnityEngine;

namespace InventorySystem.Items.Firearms.Extensions
{
	[PresetPrefabExtension("Laser Viewmodel", false)]
	public class ViewmodelLaserExtension : MonoBehaviour, IViewmodelExtension, IDestroyExtensionReceiver
	{
		private Light _lightSource;

		private Transform _selfTr;

		private Transform _viewmodelTr;

		private Firearm _firearm;

		private BarrelTipExtension _barrelTip;

		private Color _laserColor;

		private Vector3 _localPos;

		private bool _hasBarrelTip;

		private float _distanceFromWall;

		private float _unlockBlend;

		private const float MinDistanceFromWall = 0.2f;

		private const float MaxDistanceFromWall = 15f;

		private const float AdsMultiplier = 2.5f;

		private const float UnlockSpeed = 5f;

		private const float AngularSnapMin = 2.8f;

		private const float AngularSnapMax = 20f;

		private float ClientAds => 0f;

		private Vector3 BarrelForward => default(Vector3);

		private bool WantsToUnlock => false;

		private void LateUpdate()
		{
		}

		private void OnCenterRaycastMissed()
		{
		}

		private void OnCenterRaycastHit(RaycastHit hit)
		{
		}

		public void InitViewmodel(AnimatedFirearmViewmodel viewmodel)
		{
		}

		public void OnDestroyExtension()
		{
		}
	}
}
