using InventorySystem.Items.Firearms.ShotEvents;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Extensions
{
	public class DisruptorMuzzleExtension : ShootingEffectsExtensionBase
	{
		[SerializeField]
		private ParticleCollection _singleShotEffects;

		[SerializeField]
		private ParticleCollection _rapidFireEffects;

		protected override void PlayEffects(ShotEvent ev)
		{
		}
	}
}
