namespace InventorySystem.Items.Firearms.Extensions
{
	public interface IWorldmodelExtension
	{
		void SetupWorldmodel(FirearmWorldmodel worldmodel);
	}
}
