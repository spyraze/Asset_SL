namespace InventorySystem.Items.Firearms.Extensions
{
	public interface IDestroyExtensionReceiver
	{
		void OnDestroyExtension();
	}
}
