using System;
using InventorySystem.Items.Firearms.Attachments;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Extensions
{
	public class BarrelTipExtension : MixedExtension
	{
		[Serializable]
		private class TipPosition
		{
			public AttachmentLink Attachment;

			public Vector3 Position;
		}

		private const float OffsetScale = 0.001f;

		[SerializeField]
		private Vector3 _localDirection;

		[SerializeField]
		private Vector3 _baselineOffset;

		[SerializeField]
		private TipPosition[] _attachmentOffsets;

		[SerializeField]
		[Header("These transforms will always be at the barrel tip position.")]
		private Transform[] _followers;

		private uint[] _cachedFilters;

		private Vector3 _curTipPosition;

		private Transform _cachedTr;

		private bool _transformCacheSet;

		public Vector3 WorldspaceDirection => default(Vector3);

		public Vector3 WorldspacePosition => default(Vector3);

		private Transform CachedTr => null;

		public static bool TryFindWorldmodelBarrelTip(ushort serial, out BarrelTipExtension foundExtension)
		{
			foundExtension = null;
			return false;
		}

		public override void SetupWorldmodel(FirearmWorldmodel worldmodel)
		{
		}

		public override void InitViewmodel(AnimatedFirearmViewmodel viewmodel)
		{
		}

		private void UpdateViewmodel()
		{
		}

		private void ValidateCache()
		{
		}

		private void SetAttachments(uint attCode)
		{
		}
	}
}
