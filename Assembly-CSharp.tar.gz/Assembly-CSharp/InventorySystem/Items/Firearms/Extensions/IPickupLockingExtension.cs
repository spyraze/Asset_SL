namespace InventorySystem.Items.Firearms.Extensions
{
	public interface IPickupLockingExtension
	{
		bool LockPrefab { get; }
	}
}
