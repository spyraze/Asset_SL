namespace InventorySystem.Items.Firearms.Extensions
{
	public interface IViewmodelExtension
	{
		void InitViewmodel(AnimatedFirearmViewmodel viewmodel);
	}
}
