using InventorySystem.Items.Firearms.Modules.Misc;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Extensions
{
	public class ViewmodelRecoilLayerScalerExtension : MonoBehaviour, IViewmodelExtension
	{
		private Firearm _fa;

		private AnimatedViewmodelBase _viewmodel;

		private float _lastShotBonus;

		private SubsequentShotsCounter _shotsCounter;

		[SerializeField]
		private AnimatorLayerMask _recoilLayers;

		[SerializeField]
		private float _postShotReturnSpeed;

		[SerializeField]
		private AnimationCurve _weightOverScale;

		public void InitViewmodel(AnimatedFirearmViewmodel viewmodel)
		{
		}

		private void Update()
		{
		}
	}
}
