using UnityEngine;

namespace InventorySystem.Items.Firearms.Extensions
{
	public class OverheatSmokeExtension : OverheatExtensionBase
	{
		[SerializeField]
		private float _temperatureThreshold;

		[SerializeField]
		private ParticleSystem _particleSystem;

		private bool _lastExceeded;

		public override void SetupAny()
		{
		}

		protected override void OnTemperatureChanged(float temp)
		{
		}

		private void UpdateParticleSystem(float curTemp, bool forceUpdate)
		{
		}
	}
}
