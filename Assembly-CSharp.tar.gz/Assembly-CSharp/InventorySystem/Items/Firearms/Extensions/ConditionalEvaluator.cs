using System;
using InventorySystem.Items.Firearms.Attachments;
using InventorySystem.Items.Firearms.Modules;

namespace InventorySystem.Items.Firearms.Extensions
{
	[Serializable]
	public class ConditionalEvaluator
	{
		[Serializable]
		public struct AttachmentStatusPair
		{
			public AttachmentLink Link;

			public AttachmentStatus DesiredStatus;
		}

		public enum AttachmentStatus
		{
			Disabled = 0,
			Enabled = 1,
			EnabledAndReady = 2,
			EnabledAndNotReady = 3
		}

		public enum OtherCondition
		{
			Equipped = 0,
			Firstperson = 1,
			Pickup = 2,
			Thirdperson = 3
		}

		public AttachmentStatusPair[] AttachmentConditions;

		public OtherCondition[] OtherConditions;

		public bool Any;

		private bool _worldmodelMode;

		private bool _hasSetter;

		private AnimatorStateSetterModule _setterModule;

		private Firearm _firearm;

		private FirearmWorldmodel _worldmodel;

		public bool Evaluate()
		{
			return false;
		}

		public void InitInstance(Firearm instance)
		{
		}

		public void InitWorldmodel(FirearmWorldmodel worldmodel)
		{
		}

		private bool EvaluateAttachmentCondition(AttachmentStatusPair pair)
		{
			return false;
		}

		private bool EvaluateModuleCondition(OtherCondition cond)
		{
			return false;
		}

		private bool? EvaluateArray<T>(T[] arr, Predicate<T> evaluator)
		{
			return null;
		}
	}
}
