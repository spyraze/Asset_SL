using System;
using CustomRendering;
using InventorySystem.Items.Firearms.Modules;
using UnityEngine;
using UnityEngine.Rendering;

namespace InventorySystem.Items.Firearms.Extensions
{
	public class DisruptorGlitchExtension : MonoBehaviour, IViewmodelExtension
	{
		[Serializable]
		private struct GlitchSettings
		{
			public AnimationCurve AmountOverAmmo;

			public AnimationCurve NoiseOverAmmo;
		}

		[SerializeField]
		private Volume _postProcessVolume;

		[SerializeField]
		private GlitchSettings _hipGlitchSettings;

		[SerializeField]
		private GlitchSettings _adsGlichSettings;

		[SerializeField]
		private float _vfxAdjustSpeed;

		private MagazineModule _magModule;

		private DisruptorAdsModule _adsModule;

		private Glitch _glitchVfx;

		private float? _ammoWeighted;

		private static VolumeProfile _profileCopy;

		private VolumeProfile GlobalProfile => null;

		public void InitViewmodel(AnimatedFirearmViewmodel viewmodel)
		{
		}

		private void LateUpdate()
		{
		}
	}
}
