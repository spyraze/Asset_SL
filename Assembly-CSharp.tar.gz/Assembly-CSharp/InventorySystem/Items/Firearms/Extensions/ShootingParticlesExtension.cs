using InventorySystem.Items.Firearms.ShotEvents;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Extensions
{
	public class ShootingParticlesExtension : ShootingEffectsExtensionBase
	{
		[SerializeField]
		private ParticleCollection[] _systemsPerBarrel;

		protected override void Awake()
		{
		}

		protected override void PlayEffects(ShotEvent ev)
		{
		}
	}
}
