using UnityEngine;

namespace InventorySystem.Items.Firearms.Extensions
{
	[PresetPrefabExtension("Flashlight Viewmodel", false)]
	[PresetPrefabExtension("Flashlight Worldmodel", true)]
	public class FlashlightExtension : MixedExtension, IDestroyExtensionReceiver
	{
		private const float ThirdpersonRange = 22f;

		private const float PickupRange = 3.5f;

		[SerializeField]
		private Light _lightSource;

		[SerializeField]
		private Renderer[] _renderers;

		[SerializeField]
		private Material _enabledMaterial;

		[SerializeField]
		private Material _disabledMaterial;

		private bool _updateEveryFrame;

		private bool _eventAssigned;

		private bool? _prevState;

		public override void InitViewmodel(AnimatedFirearmViewmodel viewmodel)
		{
		}

		public override void SetupWorldmodel(FirearmWorldmodel worldmodel)
		{
		}

		public void OnDestroyExtension()
		{
		}

		private void UpdateState()
		{
		}

		private void Update()
		{
		}
	}
}
