using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using InventorySystem.Items.Firearms.Modules;
using InventorySystem.Items.Firearms.ShotEvents;
using MEC;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Extensions
{
	public class DisruptorDualCamExtension : ViewmodelDualCamExtension
	{
		[Serializable]
		private struct IconDefinition
		{
			public IconType Type;

			public GameObject Root;
		}

		private enum IconType
		{
			None = 0,
			DesintegratorMode = 1,
			BurstMode = 2,
			CriticalWarn = 3,
			CrashWarn = 4
		}

		[CompilerGenerated]
		private sealed class _003CAnimateDisintegratorMode_003Ed__14 : IEnumerator<float>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private float _003C_003E2__current;

			public DisruptorDualCamExtension _003C_003E4__this;

			float IEnumerator<float>.Current
			{
				[DebuggerHidden]
				get
				{
					return 0f;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CAnimateDisintegratorMode_003Ed__14(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CAnimateBurstMode_003Ed__15 : IEnumerator<float>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private float _003C_003E2__current;

			public DisruptorDualCamExtension _003C_003E4__this;

			private int _003Ci_003E5__2;

			float IEnumerator<float>.Current
			{
				[DebuggerHidden]
				get
				{
					return 0f;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CAnimateBurstMode_003Ed__15(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CAnimateCriticalWarn_003Ed__16 : IEnumerator<float>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private float _003C_003E2__current;

			public DisruptorDualCamExtension _003C_003E4__this;

			private int _003Ci_003E5__2;

			float IEnumerator<float>.Current
			{
				[DebuggerHidden]
				get
				{
					return 0f;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CAnimateCriticalWarn_003Ed__16(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[CompilerGenerated]
		private sealed class _003CAnimateCrash_003Ed__17 : IEnumerator<float>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private float _003C_003E2__current;

			public DisruptorDualCamExtension _003C_003E4__this;

			private int _003Ci_003E5__2;

			float IEnumerator<float>.Current
			{
				[DebuggerHidden]
				get
				{
					return 0f;
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CAnimateCrash_003Ed__17(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}
		}

		[SerializeField]
		private Transform _root;

		[SerializeField]
		private IconDefinition[] _icons;

		private IconType _selectedIcon;

		private CoroutineHandle _lastHandle;

		private ItemIdentifier _itemId;

		private MagazineModule _magModule;

		private DisruptorModeSelector _selectorModule;

		public override void InitViewmodel(AnimatedFirearmViewmodel viewmodel)
		{
		}

		protected override void LateUpdate()
		{
		}

		private void OnDestroy()
		{
		}

		private void OnDisable()
		{
		}

		private void SetIcon(IconType newIcon)
		{
		}

		private void PlayAnimation(IconType icon)
		{
		}

		private void RunCoroutine(IEnumerator<float> coroutine)
		{
		}

		[IteratorStateMachine(typeof(_003CAnimateDisintegratorMode_003Ed__14))]
		private IEnumerator<float> AnimateDisintegratorMode()
		{
			return null;
		}

		[IteratorStateMachine(typeof(_003CAnimateBurstMode_003Ed__15))]
		private IEnumerator<float> AnimateBurstMode()
		{
			return null;
		}

		[IteratorStateMachine(typeof(_003CAnimateCriticalWarn_003Ed__16))]
		private IEnumerator<float> AnimateCriticalWarn()
		{
			return null;
		}

		[IteratorStateMachine(typeof(_003CAnimateCrash_003Ed__17))]
		private IEnumerator<float> AnimateCrash()
		{
			return null;
		}

		private void OnShot(ShotEvent shotEvent)
		{
		}

		private void OnAnimationRequested()
		{
		}
	}
}
