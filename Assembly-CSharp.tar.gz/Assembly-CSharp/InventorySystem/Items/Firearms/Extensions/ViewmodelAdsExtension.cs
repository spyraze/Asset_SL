using System;
using InventorySystem.Items.Firearms.Attachments;
using InventorySystem.Items.Firearms.Modules;
using InventorySystem.Items.Firearms.Modules.Misc;
using InventorySystem.Items.SwayControllers;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Extensions
{
	public class ViewmodelAdsExtension : MonoBehaviour, IViewmodelExtension
	{
		[Serializable]
		private struct RandomizerSettings
		{
			public bool Randomize;

			public int TotalSights;
		}

		[Serializable]
		private class OffsetSettings
		{
			public float AdsFov;

			public Vector3 HipPosition;

			public Vector3 AdsPosition;

			public Vector3 AdsRotation;

			public Vector2 AdsSpeedMultiplierOffset;

			public float ShotAnimIntensity;

			public void Combine(OffsetSettings toCombine)
			{
			}

			public void SetFrom(OffsetSettings source)
			{
			}
		}

		[Serializable]
		private class AdsAttachmentOffset
		{
			public AttachmentLink TargetAttachment;

			public OffsetSettings OffsetSettings;

			public bool OverridePrevious;
		}

		private static readonly AnimationCurve CorrectionCurve;

		private const float OverallAdsAnimSpeedMultiplier = 5f;

		private readonly OffsetSettings _combinedSettings;

		private AnimatedFirearmViewmodel _viewmodel;

		private Transform _viewmodelTr;

		private Firearm _firearm;

		private IAdsModule _adsModule;

		private float _animationTime;

		private bool _prevAdsTarget;

		private float _prevAdsAmount;

		private bool _initialized;

		private bool _returnAnimation;

		private bool _wasTransitioning;

		[SerializeField]
		[Tooltip("Weight of AdsShotBlend at which the weapon does not move when firing.")]
		private float _noShootingAnimBlendWeight;

		[SerializeField]
		private bool _enableShootingAnimReduction;

		[SerializeField]
		private AnimatorLayerMask _adsAnimsLayer;

		[SerializeField]
		private OffsetSettings _defaultOffset;

		[SerializeField]
		private AdsAttachmentOffset[] _attachmentOffsets;

		[SerializeField]
		private AudioClip _adsInSound;

		[SerializeField]
		private AudioClip _adsOutSound;

		[SerializeField]
		private float _adsInAnimationSpeed;

		[SerializeField]
		private float _adsOutAnimationSpeed;

		[SerializeField]
		private RandomizerSettings _randomizerSettings;

		[field: SerializeField]
		public GoopSway.GoopSwaySettings AdsSway { get; private set; }

		public void InitViewmodel(AnimatedFirearmViewmodel viewmodel)
		{
		}

		private void RefreshAttachments()
		{
		}

		private void OnValidate()
		{
		}

		private void Update()
		{
		}

		private void UpdateOffset()
		{
		}

		private void UpdateSounds()
		{
		}

		private void UpdateAnims(int layer)
		{
		}

		private void Randomize()
		{
		}
	}
}
