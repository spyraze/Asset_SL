using System;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Extensions
{
	[Serializable]
	public class BipolarTransform
	{
		public Transform TargetTransform;

		[Space(15f)]
		public Offset TruePole;

		public Offset FalsePole;

		private bool _polarity;

		public bool Polarity
		{
			get
			{
				return false;
			}
			set
			{
			}
		}
	}
}
