using System.Collections.Generic;
using InventorySystem.Items.Firearms.Modules;
using PlayerRoles.FirstPersonControl;
using UnityEngine;
using UnityEngine.UI;

namespace InventorySystem.Items.Firearms.Extensions
{
	public class DisruptorScopeTrackerExtension : MonoBehaviour, IViewmodelExtension
	{
		private struct TargetIndicator
		{
			public GameObject GameObject;

			public RectTransform Transform;

			public Image Image;

			public uint NetId;

			public double CreationTime;

			public readonly float ActiveElapsed => 0f;

			public TargetIndicator(RectTransform newInstance, uint netId)
			{
				GameObject = null;
				Transform = null;
				Image = null;
				NetId = 0u;
				CreationTime = 0.0;
			}

			public TargetIndicator(TargetIndicator other, uint newNetId)
			{
				GameObject = null;
				Transform = null;
				Image = null;
				NetId = 0u;
				CreationTime = 0.0;
			}
		}

		private static readonly CachedLayerMask LineOfSightBlockMask;

		private static readonly CachedLayerMask HitboxMask;

		[SerializeField]
		private Camera _mainCamera;

		[SerializeField]
		private AnimationCurve _opacityOverFog;

		[SerializeField]
		private AnimationCurve _sizeOverDistance;

		[SerializeField]
		private AnimationCurve _opacityOverDistance;

		[SerializeField]
		private float _friendlyOpacity;

		[SerializeField]
		private float _enemyOpacity;

		[SerializeField]
		private RectTransform _targetIndicatorTemplate;

		[SerializeField]
		private Vector2 _canvasScale;

		[SerializeField]
		private float _extraFogRange;

		private ReferenceHub _owner;

		private IAdsModule _adsModule;

		private readonly List<TargetIndicator> _activeIndicators;

		private readonly Queue<TargetIndicator> _indicatorPool;

		private readonly HashSet<uint> _detectedNetIds;

		public void InitViewmodel(AnimatedFirearmViewmodel viewmodel)
		{
		}

		private void LateUpdate()
		{
		}

		private void UpdateIndicator(Vector3 viewportPos, ReferenceHub target)
		{
		}

		private TargetIndicator GetIndicatorForPlayer(uint netId)
		{
			return default(TargetIndicator);
		}

		private void RePoolUnusedIndicators()
		{
		}

		private bool TryGetBestPos(Vector3 mainCamPos, uint netId, FirstPersonMovementModule fpc, out Vector3 pos)
		{
			pos = default(Vector3);
			return false;
		}

		private bool CheckLineOfSight(Vector3 origin, Vector3 pos, uint netId)
		{
			return false;
		}
	}
}
