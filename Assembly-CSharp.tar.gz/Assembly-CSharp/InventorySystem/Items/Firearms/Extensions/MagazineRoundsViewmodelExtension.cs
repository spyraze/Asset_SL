using System.Diagnostics;
using InventorySystem.Items.Firearms.ShotEvents;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Extensions
{
	public class MagazineRoundsViewmodelExtension : MonoBehaviour, IViewmodelExtension
	{
		[SerializeField]
		private GameObject[] _rounds;

		[SerializeField]
		private Transform _visibilityBeacon;

		[SerializeField]
		private int _onShotOffset;

		[SerializeField]
		private float _onShotSustain;

		private Firearm _fa;

		private ItemIdentifier _itemId;

		private bool _magRefilled;

		private readonly Stopwatch _onShotSw;

		private int DisplayedAmount => 0;

		public void RemoveOffsets()
		{
		}

		public void InitViewmodel(AnimatedFirearmViewmodel viewmodel)
		{
		}

		private void OnShot(ShotEvent shotEvent)
		{
		}

		private void Awake()
		{
		}

		private void OnDestroy()
		{
		}

		private void Update()
		{
		}

		private void SetAmmo(int ammo)
		{
		}
	}
}
