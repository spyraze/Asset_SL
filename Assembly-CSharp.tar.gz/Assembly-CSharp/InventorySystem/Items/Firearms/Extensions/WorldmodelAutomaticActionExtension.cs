using UnityEngine;

namespace InventorySystem.Items.Firearms.Extensions
{
	public class WorldmodelAutomaticActionExtension : MonoBehaviour, IWorldmodelExtension
	{
		private ushort _lastSerial;

		[SerializeField]
		private BipolarTransform[] _anyChambered;

		[SerializeField]
		private BipolarTransform[] _boltLocked;

		[SerializeField]
		private BipolarTransform[] _cocked;

		public void SetupWorldmodel(FirearmWorldmodel worldmodel)
		{
		}

		private void UpdateAllPolarity()
		{
		}

		private void UpdatePolarity(BipolarTransform[] arr, bool polarity)
		{
		}

		[RuntimeInitializeOnLoadMethod]
		private static void Init()
		{
		}
	}
}
