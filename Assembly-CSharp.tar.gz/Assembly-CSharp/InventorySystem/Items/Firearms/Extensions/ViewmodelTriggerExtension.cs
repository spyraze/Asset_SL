using InventorySystem.Items.Firearms.Modules.Misc;
using InventorySystem.Items.Firearms.ShotEvents;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Extensions
{
	public class ViewmodelTriggerExtension : MonoBehaviour, IViewmodelExtension
	{
		private AnimatedFirearmViewmodel _viewmodel;

		private Firearm _firearm;

		private float _lastShotTime;

		private float _weight;

		private bool _released;

		private const float DefaultPullSpeed = 15f;

		private const float DefaultReleaseSpeed = 6.5f;

		[SerializeField]
		[Range(0f, 1f)]
		private float _triggerVisualReleaseRate;

		[SerializeField]
		private float _pullSpeed;

		[SerializeField]
		private float _releaseSpeed;

		[SerializeField]
		private AnimatorLayerMask _triggerOverrideLayer;

		[SerializeField]
		private AudioClip _triggerSound;

		private bool TriggerHeld => false;

		public void InitViewmodel(AnimatedFirearmViewmodel viewmodel)
		{
		}

		private void Awake()
		{
		}

		private void OnDestroy()
		{
		}

		private void OnShot(ShotEvent ev)
		{
		}

		private void Update()
		{
		}
	}
}
