using System.Collections.Generic;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Extensions
{
	public abstract class OverheatExtensionBase : MixedExtension, IDestroyExtensionReceiver
	{
		private static readonly Queue<OverheatExtensionBase> WorldmodelUpdateQueue;

		private static readonly HashSet<OverheatExtensionBase> WorldmodelInstances;

		private bool _worldmodelSetup;

		public override void SetupWorldmodel(FirearmWorldmodel worldmodel)
		{
		}

		public virtual void OnDestroyExtension()
		{
		}

		protected abstract void OnTemperatureChanged(float temp);

		protected virtual void Update()
		{
		}

		private void UpdateInstance()
		{
		}

		[RuntimeInitializeOnLoadMethod]
		private static void Init()
		{
		}

		private static void OnTemperatureSet(ItemIdentifier id)
		{
		}

		private static void UpdateWorldmodels()
		{
		}
	}
}
