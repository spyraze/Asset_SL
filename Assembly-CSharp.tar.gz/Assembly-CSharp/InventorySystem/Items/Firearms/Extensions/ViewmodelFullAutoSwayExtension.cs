using InventorySystem.Items.Firearms.Modules.Misc;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Extensions
{
	public class ViewmodelFullAutoSwayExtension : MonoBehaviour, IViewmodelExtension
	{
		private const float TriggerIncreaseWeightSpeed = 10f;

		private const float TriggerDecreaseWeightSpeed = 5f;

		private const float RecentlyFiredIncreaseWeightSpeed = 10f;

		private const float RecentlyFiredDecreaseWeightSpeed = 1.5f;

		private const float LoadedIncreaseWeightSpeed = 1.5f;

		private const float LoadedDecreaseWeightSpeed = 5f;

		private const float DefaultAdsMuliplier = 0.1f;

		private const float DefaultHipMuliplier = 1f;

		private SubsequentShotsCounter _shotsCounter;

		private AnimatedFirearmViewmodel _viewmodel;

		private Firearm _firearm;

		[SerializeField]
		private AnimatorLayerMask _recoilLayers;

		[SerializeField]
		private float _adsMultiplier;

		[SerializeField]
		private float _hipMultiplier;

		private AnimatorStateInfo[] _statesByLayer;

		private float _elapsed;

		private float _weightTrigger;

		private float _weightRecentlyFired;

		private float _weightLoaded;

		public void InitViewmodel(AnimatedFirearmViewmodel viewmodel)
		{
		}

		private void LateUpdate()
		{
		}

		private void UpdateWeight(ref float weight, bool targetIncrease, float increaseSpeed, float decreaseSpeed)
		{
		}

		private void UpdateLayer(int layerId, AnimatorStateInfo state, float weight)
		{
		}
	}
}
