using System;
using InventorySystem.Items.Firearms.Attachments;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Extensions
{
	public class WorldmodelMagazineExtension : MonoBehaviour, IWorldmodelExtension
	{
		[Serializable]
		private class Magazine
		{
			private uint? _filter;

			private bool? _lastIsActive;

			public GameObject Target;

			public AttachmentLink[] Attachments;

			public void UpdateState(WorldmodelMagazineExtension extRef, bool magInserted)
			{
			}

			private void SetVisibility(RemovalMode removalMode, bool isActive)
			{
			}

			private void SetFilter(ItemIdentifier id)
			{
			}
		}

		private enum RemovalMode
		{
			DeactivateObject = 0,
			SetScaleZero = 1
		}

		private ItemIdentifier _lastId;

		private uint _lastAttCode;

		private bool _forceInserted;

		[SerializeField]
		private Magazine[] _magazines;

		[SerializeField]
		private RemovalMode _removalMode;

		public void SetupWorldmodel(FirearmWorldmodel worldmodel)
		{
		}

		private void UpdateAllMags()
		{
		}

		[RuntimeInitializeOnLoadMethod]
		private static void Init()
		{
		}
	}
}
