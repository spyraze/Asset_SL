using InventorySystem.Items.Firearms.Attachments.Components;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Extensions
{
	[PresetPrefabExtension("Holo Sight Renderer", false)]
	public class ViewmodelReflexSightExtension : MonoBehaviour, IViewmodelExtension
	{
		private static readonly int HashTexture;

		private static readonly int HashColor;

		private static readonly int HashSize;

		private static readonly GameObject[] RelativesNonAlloc;

		private static Material _materialInstance;

		private Firearm _firearm;

		private ReflexSightAttachment _sightAtt;

		private Color _targetColor;

		private float? _prevAds;

		private bool _initialized;

		[SerializeField]
		private Renderer _targetRenderer;

		private void LateUpdate()
		{
		}

		private void OnEnable()
		{
		}

		private void UpdateValues()
		{
		}

		private void SetMaterial(Texture texture, float size, Color color, float brigthness)
		{
		}

		private void FindSightAttachment(AnimatedFirearmViewmodel viewmodel)
		{
		}

		public void InitViewmodel(AnimatedFirearmViewmodel viewmodel)
		{
		}
	}
}
