using System.Collections.Generic;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Extensions
{
	[PresetPrefabExtension("Sniper Scope Screen Viewmodel", false)]
	[PresetPrefabExtension("NV Scope Screen Viewmodel", false)]
	public class ViewmodelDualCamExtension : MonoBehaviour, IViewmodelExtension
	{
		private static readonly Dictionary<Material, Material> MaterialInstances;

		private static readonly int RenderTexHash;

		private static readonly int AdsHash;

		[SerializeField]
		private Renderer _targetRenderer;

		[SerializeField]
		private GameObject _cameraSetupRoot;

		[SerializeField]
		private float _zoomAmount;

		[SerializeField]
		private Transform _topPointTr;

		[SerializeField]
		private Transform _bottomPointTr;

		private Camera _fovCamera;

		private Firearm _firearm;

		private Material _matInstance;

		private Transform _cameraTr;

		public bool TryGetVerticalScreenOccupation(out float verticalScreenOccupation)
		{
			verticalScreenOccupation = default(float);
			return false;
		}

		public virtual void InitViewmodel(AnimatedFirearmViewmodel viewmodel)
		{
		}

		protected virtual void LateUpdate()
		{
		}
	}
}
