using System;
using InventorySystem.Items.Firearms.Modules;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Extensions
{
	public class ExternalRoundsExtension : MixedExtension
	{
		[SerializeField]
		private GameObject[] _rounds;

		[SerializeField]
		private bool _countChamberedRounds;

		[SerializeField]
		private bool _countMagazineRounds;

		private Func<DisplayAmmoValues> _fetcher;

		private int? _prevValue;

		private void Update()
		{
		}

		public override void InitViewmodel(AnimatedFirearmViewmodel viewmodel)
		{
		}

		public override void SetupWorldmodel(FirearmWorldmodel worldmodel)
		{
		}
	}
}
