using UnityEngine;

namespace InventorySystem.Items.Firearms.BasicMessages
{
	public static class DamageIndicatorMessageProcessor
	{
		[RuntimeInitializeOnLoadMethod]
		private static void Init()
		{
		}

		private static void RegisterHandlers()
		{
		}
	}
}
