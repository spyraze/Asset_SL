using Mirror;

namespace InventorySystem.Items.Firearms.Attachments.Components
{
	public readonly struct ReflexSightSyncData
	{
		private readonly int _colorHue;

		private readonly int _colorBrightness;

		private readonly int _size;

		private readonly int _iconIndex;

		public ReflexSightSyncData(int colorHue, int colorBrightness, int size, int iconIndex)
		{
			_colorHue = 0;
			_colorBrightness = 0;
			_size = 0;
			_iconIndex = 0;
		}

		public ReflexSightSyncData(ReflexSightAttachment attachment)
		{
			_colorHue = 0;
			_colorBrightness = 0;
			_size = 0;
			_iconIndex = 0;
		}

		public ReflexSightSyncData(NetworkReader reader)
		{
			_colorHue = 0;
			_colorBrightness = 0;
			_size = 0;
			_iconIndex = 0;
		}

		public void Write(NetworkWriter writer)
		{
		}

		public void Apply(ReflexSightAttachment att)
		{
		}
	}
}
