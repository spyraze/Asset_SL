using UnityEngine;

namespace InventorySystem.Items.Firearms.Attachments.Components
{
	public class SerializableAttachment : Attachment, IDisplayableAttachment
	{
		[SerializeField]
		private AttachmentName _name;

		[SerializeField]
		private AttachmentSlot _slot;

		[SerializeField]
		[Space]
		private float _weight;

		[SerializeField]
		private float _length;

		[Space]
		[SerializeField]
		private AttachmentDescriptiveAdvantages _extraPros;

		[SerializeField]
		private AttachmentDescriptiveDownsides _extraCons;

		[Space]
		[SerializeField]
		private Texture2D _icon;

		[SerializeField]
		private Vector2 _iconOffset;

		[SerializeField]
		private int _parentId;

		[SerializeField]
		private Vector2 _parentOffset;

		[Space]
		[SerializeField]
		private AttachmentParameterValuePair[] _params;

		public override AttachmentName Name => default(AttachmentName);

		public override AttachmentSlot Slot => default(AttachmentSlot);

		public override float Weight => 0f;

		public override float Length => 0f;

		public override AttachmentDescriptiveAdvantages DescriptivePros => default(AttachmentDescriptiveAdvantages);

		public override AttachmentDescriptiveDownsides DescriptiveCons => default(AttachmentDescriptiveDownsides);

		public Texture2D Icon
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		public Vector2 IconOffset
		{
			get
			{
				return default(Vector2);
			}
			set
			{
			}
		}

		public int ParentId => 0;

		public Vector2 ParentOffset => default(Vector2);

		protected virtual void Awake()
		{
		}

		protected void SetDefaultParameters()
		{
		}

		protected virtual void Reset()
		{
		}
	}
}
