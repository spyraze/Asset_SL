using System;
using System.Collections.Generic;
using Mirror;
using PlayerRoles;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Attachments.Components
{
	public class ReflexSightAttachment : SerializableAttachment, ICustomizableAttachment
	{
		private static readonly Dictionary<ushort, Dictionary<byte, ReflexSightSyncData>> SyncData;

		public static readonly float[] Sizes;

		public static readonly float[] BrightnessLevels;

		public static readonly Color32[] Colors;

		public Action OnValuesChanged;

		public ReflexSightReticlePack TextureOptions;

		private const int DefaultSize = 4;

		private const int DefaultBrightness = 0;

		private const int UnnamedPresetIndex = 0;

		private const string TexturePrefsKey = "Texture";

		private const string ColorPrefsKey = "Color";

		private const string SizePrefsKey = "Size";

		private const string BrightnessPrefsKey = "Brightness";

		private bool _serverPrefsReceived;

		[SerializeField]
		private int _defaultColorId;

		[SerializeField]
		private int _defaultReticle;

		[SerializeField]
		private Vector2 _configIconOffset;

		[SerializeField]
		private float _configIconSize;

		[SerializeField]
		private AttachmentConfigWindow _configWindow;

		public Vector2 ConfigIconOffset => default(Vector2);

		public AttachmentConfigWindow ConfigWindow => null;

		public float ConfigIconScale => 0f;

		public override bool AllowCmdsWhileHolstered => false;

		public int CurTextureIndex { get; set; }

		public int CurSizeIndex { get; set; }

		public int CurColorIndex { get; set; }

		public int CurBrightnessIndex { get; set; }

		public void SetValues(int texture, int color, int size, int brightness)
		{
		}

		public void ModifyValues(int? texture = null, int? color = null, int? size = null, int? brightness = null)
		{
		}

		public void SaveValues()
		{
		}

		public override void ClientProcessRpcTemplate(NetworkReader reader, ushort serial)
		{
		}

		public override void ClientProcessRpcInstance(NetworkReader reader)
		{
		}

		public override void ServerProcessCmd(NetworkReader reader)
		{
		}

		internal override void OnAdded()
		{
		}

		internal override void SpectatorInit()
		{
		}

		internal override void OnEquipped()
		{
		}

		internal override void OnClientReady()
		{
		}

		protected override void Awake()
		{
		}

		private void OnDestroy()
		{
		}

		private void OnRoleChanged(ReferenceHub userHub, PlayerRoleBase prevRole, PlayerRoleBase newRole)
		{
		}

		private void ServerSendData(ReflexSightSyncData data, bool onlySpectators)
		{
		}

		private void SetDatabaseEntry(ReflexSightSyncData data, ushort? serial = null)
		{
		}

		private bool TryGetFromDatabase(out ReflexSightSyncData data)
		{
			data = default(ReflexSightSyncData);
			return false;
		}

		private string GetPrefsKey(int preset, string setting)
		{
			return null;
		}

		private void SendUserPrefs(bool changeRequest)
		{
		}

		private void LoadFromPreset()
		{
		}

		private void ResetToDefault()
		{
		}
	}
}
