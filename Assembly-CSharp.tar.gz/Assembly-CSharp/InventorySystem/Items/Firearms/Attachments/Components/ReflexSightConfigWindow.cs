using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace InventorySystem.Items.Firearms.Attachments.Components
{
	public class ReflexSightConfigWindow : AttachmentConfigWindow
	{
		[SerializeField]
		private RectTransform _shapeTemplate;

		[SerializeField]
		private RectTransform _colorTemplate;

		[SerializeField]
		private RectTransform _brightnessTemplate;

		[SerializeField]
		private RectTransform _buttonReduce;

		[SerializeField]
		private RectTransform _buttonEnlarge;

		[SerializeField]
		private RectTransform[] _ignoreRaycastRects;

		[SerializeField]
		private TextMeshProUGUI _textPercent;

		[SerializeField]
		private Color _selectedColor;

		[SerializeField]
		private Color _normalColor;

		private Image[] _shapeInstances;

		private Image[] _colorInstances;

		private Image[] _brightnessInstances;

		private static Color32[] _colorsByHue;

		public override void Setup(AttachmentSelectorBase selector, Attachment attachment, RectTransform toFit)
		{
		}

		protected override void OnDestroy()
		{
		}

		private void UpdateValues()
		{
		}

		private Image[] GenerateOptions<T>(T[] array, RectTransform template, Action<int> onClick, Action<RectTransform, int> setupMethod)
		{
			return null;
		}

		private int TranslateIndex(Color32[] fromArray, Color32[] toArray, int index, int fallback = -1)
		{
			return 0;
		}
	}
}
