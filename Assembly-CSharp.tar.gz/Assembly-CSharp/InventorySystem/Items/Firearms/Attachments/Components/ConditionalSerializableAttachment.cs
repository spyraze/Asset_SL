using System;
using InventorySystem.Items.Firearms.Extensions;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Attachments.Components
{
	public class ConditionalSerializableAttachment : SerializableAttachment
	{
		[Serializable]
		private struct ConditionalOverride
		{
			public ConditionalEvaluator Condition;

			public AttachmentDescriptiveAdvantages ExtraPros;

			public AttachmentDescriptiveDownsides ExtraCons;

			public AttachmentParameterValuePair[] Params;
		}

		private int? _lastAppliedOverride;

		private bool _initialized;

		private bool _needsRefreshing;

		[SerializeField]
		private ConditionalOverride[] _overrides;

		private ConditionalOverride? LastOverride => null;

		public override AttachmentDescriptiveAdvantages DescriptivePros => default(AttachmentDescriptiveAdvantages);

		public override AttachmentDescriptiveDownsides DescriptiveCons => default(AttachmentDescriptiveDownsides);

		protected override void OnInit()
		{
		}

		internal override void OnAttachmentsApplied()
		{
		}

		private void RefreshOverrides()
		{
		}

		private void ApplyOverride(int? index)
		{
		}
	}
}
