namespace InventorySystem.Items.Firearms.Attachments.Components
{
	public class NightVisionScopeAttachment : SerializableAttachment, ILightEmittingItem
	{
		private const float AdsThreshold = 0.6f;

		public bool IsEmittingLight => false;
	}
}
