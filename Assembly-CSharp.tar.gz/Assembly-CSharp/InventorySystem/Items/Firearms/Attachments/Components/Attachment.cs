namespace InventorySystem.Items.Firearms.Attachments.Components
{
	public abstract class Attachment : FirearmSubcomponentBase
	{
		private AttachmentParamState[] _parameterStates;

		private float[] _parameterValues;

		private bool _arraysInitialized;

		private const string AttNamesFilename = "AttachmentNames";

		public abstract AttachmentName Name { get; }

		public abstract AttachmentSlot Slot { get; }

		public abstract float Weight { get; }

		public abstract float Length { get; }

		public abstract AttachmentDescriptiveAdvantages DescriptivePros { get; }

		public abstract AttachmentDescriptiveDownsides DescriptiveCons { get; }

		public byte Index { get; private set; }

		public virtual bool IsEnabled { get; set; }

		private void SetupArrays()
		{
		}

		protected override void OnInit()
		{
		}

		protected virtual void EnabledEquipUpdate()
		{
		}

		protected void SetParameter(AttachmentParameterValuePair pair)
		{
		}

		protected void SetParameter(int param, float val, AttachmentParamState state)
		{
		}

		protected void ClearParameter(AttachmentParam param)
		{
		}

		protected void ClearAllParameters()
		{
		}

		public void GetParameterData(int param, out float val, out AttachmentParamState state)
		{
			val = default(float);
			state = default(AttachmentParamState);
		}

		public bool TryGetActiveValue(AttachmentParam param, out float val)
		{
			val = default(float);
			return false;
		}

		public bool TryGetDisplayValue(AttachmentParam param, out float val)
		{
			val = default(float);
			return false;
		}

		public void GetNameAndDescription(out string n, out string d)
		{
			n = null;
			d = null;
		}

		internal sealed override void EquipUpdate()
		{
		}
	}
}
