using Mirror;

namespace InventorySystem.Items.Firearms.Attachments
{
	public struct AttachmentsSetupPreference : NetworkMessage
	{
		public ItemType Weapon;

		public uint AttachmentsCode;

		public AttachmentsSetupPreference(NetworkReader reader)
		{
			Weapon = default(ItemType);
			AttachmentsCode = 0u;
		}

		public readonly void Serialize(NetworkWriter writer)
		{
		}
	}
}
