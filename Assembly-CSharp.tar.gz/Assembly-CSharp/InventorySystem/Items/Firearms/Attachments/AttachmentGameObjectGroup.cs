using System;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Attachments
{
	[Serializable]
	public struct AttachmentGameObjectGroup
	{
		public GameObject[] Group;

		public readonly void SetActive(bool state)
		{
		}
	}
}
