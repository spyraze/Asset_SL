using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using Mirror;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Attachments
{
	public static class AttachmentCodeSync
	{
		public readonly struct AttachmentCodeMessage : NetworkMessage
		{
			public readonly ushort WeaponSerial;

			public readonly uint AttachmentCode;

			public AttachmentCodeMessage(NetworkReader reader)
			{
				WeaponSerial = 0;
				AttachmentCode = 0u;
			}

			public AttachmentCodeMessage(ushort serial, uint attCode)
			{
				WeaponSerial = 0;
				AttachmentCode = 0u;
			}

			public void Serialize(NetworkWriter writer)
			{
			}

			public void Apply()
			{
			}
		}

		[StructLayout((LayoutKind)0, Size = 1)]
		public readonly struct AttachmentCodePackMessage : NetworkMessage
		{
			private static readonly List<AttachmentCodeMessage> LastDeserialized;

			public AttachmentCodePackMessage(NetworkReader reader)
			{
			}

			public void Serialize(NetworkWriter writer)
			{
			}

			public void Apply()
			{
			}
		}

		private static readonly Dictionary<ushort, uint> ReceivedCodes;

		public static event Action<ushort, uint> OnReceived
		{
			[CompilerGenerated]
			add
			{
			}
			[CompilerGenerated]
			remove
			{
			}
		}

		[RuntimeInitializeOnLoadMethod]
		private static void Init()
		{
		}

		private static void OnClientReady()
		{
		}

		private static void OnNewPlayerAdded(ReferenceHub hub)
		{
		}

		public static bool TryGet(ushort serial, out uint code)
		{
			code = default(uint);
			return false;
		}

		public static void ServerSetCode(ushort serial, uint code)
		{
		}

		public static void ServerResendAttachmentCode(this Firearm firearm)
		{
		}

		public static void WriteAttachmentCodeMessage(this NetworkWriter writer, AttachmentCodeMessage value)
		{
		}

		public static AttachmentCodeMessage ReadAttachmentCodeMessage(this NetworkReader reader)
		{
			return default(AttachmentCodeMessage);
		}

		public static void WriteAttachmentCodePackMessage(this NetworkWriter writer, AttachmentCodePackMessage value)
		{
		}

		public static AttachmentCodePackMessage ReadAttachmentCodePackMessage(this NetworkReader reader)
		{
			return default(AttachmentCodePackMessage);
		}
	}
}
