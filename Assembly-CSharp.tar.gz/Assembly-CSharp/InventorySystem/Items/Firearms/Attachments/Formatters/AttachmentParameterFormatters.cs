using System.Collections.Generic;

namespace InventorySystem.Items.Firearms.Attachments.Formatters
{
	public static class AttachmentParameterFormatters
	{
		public static readonly Dictionary<AttachmentParam, IAttachmentsParameterFormatter> Formatters;
	}
}
