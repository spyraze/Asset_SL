using System;
using System.Runtime.CompilerServices;
using InventorySystem.Items.Firearms.Attachments.Components;

namespace InventorySystem.Items.Firearms.Attachments
{
	public static class AttachmentsUtils
	{
		private static int _paramNumberCache;

		private static AttachmentParameterDefinition[] _cachedDefitionons;

		private static bool[] _readyMixingModes;

		private static bool _mixingModesCacheSet;

		public static int TotalNumberOfParams => 0;

		public static event Action<Firearm> OnAttachmentsApplied
		{
			[CompilerGenerated]
			add
			{
			}
			[CompilerGenerated]
			remove
			{
			}
		}

		public static uint GetCurrentAttachmentsCode(this Firearm firearm)
		{
			return 0u;
		}

		public static uint GetRandomAttachmentsCode(ItemType firearmType)
		{
			return 0u;
		}

		public static bool TryGetAttachmentWithId(this Firearm firearm, int id, out Attachment att)
		{
			att = null;
			return false;
		}

		public static float AttachmentsValue(this Firearm firearm, AttachmentParam param)
		{
			return 0f;
		}

		public static float ProcessValue(this Firearm firearm, float value, AttachmentParam param)
		{
			return 0f;
		}

		public static bool HasAdvantageFlag(this Firearm firearm, AttachmentDescriptiveAdvantages flag)
		{
			return false;
		}

		public static bool HasDownsideFlag(this Firearm firearm, AttachmentDescriptiveDownsides flag)
		{
			return false;
		}

		public static float MixValue(float originalValue, float modifierValue, ParameterMixingMode mixMode)
		{
			return 0f;
		}

		private static float ClampValue(float f, AttachmentParameterDefinition definition)
		{
			return 0f;
		}

		private static AttachmentParameterDefinition GetDefinitionOfParam(AttachmentParam param)
		{
			return default(AttachmentParameterDefinition);
		}

		public static void ApplyAttachmentsCode(this Firearm firearm, uint code, bool reValidate)
		{
		}

		public static uint ValidateAttachmentsCode(this Firearm firearm, uint code)
		{
			return 0u;
		}

		public static void GetDefaultLengthAndWeight(this Firearm fa, out float length, out float weight)
		{
			length = default(float);
			weight = default(float);
		}

		public static bool HasFlagFast(this AttachmentDescriptiveAdvantages flags, AttachmentDescriptiveAdvantages flag)
		{
			return false;
		}

		public static bool HasFlagFast(this AttachmentDescriptiveDownsides flags, AttachmentDescriptiveDownsides flag)
		{
			return false;
		}
	}
}
