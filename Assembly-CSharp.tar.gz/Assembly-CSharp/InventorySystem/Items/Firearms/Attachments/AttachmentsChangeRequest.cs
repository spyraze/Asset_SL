using Mirror;

namespace InventorySystem.Items.Firearms.Attachments
{
	public struct AttachmentsChangeRequest : NetworkMessage
	{
		public ushort WeaponSerial;

		public uint AttachmentsCode;

		public AttachmentsChangeRequest(NetworkReader reader)
		{
			WeaponSerial = 0;
			AttachmentsCode = 0u;
		}

		public readonly void Serialize(NetworkWriter writer)
		{
		}
	}
}
