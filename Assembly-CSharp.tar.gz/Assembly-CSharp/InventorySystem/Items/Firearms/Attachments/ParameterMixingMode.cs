namespace InventorySystem.Items.Firearms.Attachments
{
	public enum ParameterMixingMode
	{
		Override = 0,
		Additive = 1,
		Percent = 2
	}
}
