using System.Collections.Generic;
using Mirror;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Attachments
{
	public static class AttachmentsServerHandler
	{
		public static readonly Dictionary<ReferenceHub, Dictionary<ItemType, uint>> PlayerPreferences;

		public static uint ServerGetReceivedPlayerPreference(Firearm firearmInstance)
		{
			return 0u;
		}

		public static bool AnyWorkstationsNearby(ReferenceHub ply)
		{
			return false;
		}

		[RuntimeInitializeOnLoadMethod]
		private static void Init()
		{
		}

		private static void OnServerStarted()
		{
		}

		private static void ServerReceiveChangeRequest(NetworkConnection conn, AttachmentsChangeRequest msg)
		{
		}

		private static void ServerReceivePreference(NetworkConnection conn, AttachmentsSetupPreference msg)
		{
		}

		private static void ServerApplyPreference(ReferenceHub hub, ItemType weapon, uint attCode)
		{
		}
	}
}
