using Mirror;

namespace InventorySystem.Items.Firearms.Attachments
{
	public static class AttachmentsMessageSerializers
	{
		public static void WriteAttachmentsChangeRequest(this NetworkWriter writer, AttachmentsChangeRequest value)
		{
		}

		public static AttachmentsChangeRequest ReadAttachmentsChangeRequest(this NetworkReader reader)
		{
			return default(AttachmentsChangeRequest);
		}

		public static void WriteAttachmentsSetupPreference(this NetworkWriter writer, AttachmentsSetupPreference value)
		{
		}

		public static AttachmentsSetupPreference ReadAttachmentsSetupPreference(this NetworkReader reader)
		{
			return default(AttachmentsSetupPreference);
		}
	}
}
