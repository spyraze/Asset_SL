namespace InventorySystem.Items.Firearms.Attachments
{
	public static class AttachmentPreview
	{
		private static readonly Firearm[] Instances;

		private static readonly bool[] HasInstances;

		public static Firearm Get(ItemType id, uint attachmentsCode, bool reValidate = false)
		{
			return null;
		}

		public static Firearm Get(ItemIdentifier id, bool reValidate = false)
		{
			return null;
		}

		public static bool TryGet(ItemType id, uint attachmentsCode, bool reValidate, out Firearm result)
		{
			result = null;
			return false;
		}

		public static bool TryGet(ItemIdentifier id, bool reValidate, out Firearm result)
		{
			result = null;
			return false;
		}

		private static bool TryGetOrAddInstance(ItemType id, out Firearm instance)
		{
			instance = null;
			return false;
		}
	}
}
