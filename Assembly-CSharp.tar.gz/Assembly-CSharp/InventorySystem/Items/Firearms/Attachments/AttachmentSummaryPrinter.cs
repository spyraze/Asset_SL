using System;
using System.Collections.Generic;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Attachments
{
	public class AttachmentSummaryPrinter : MonoBehaviour
	{
		private class ComparableStat
		{
			private readonly Func<Firearm, float> _fetcher;

			private readonly Func<bool> _validator;

			private readonly bool _moreIsBetter;

			private readonly string _unit;

			private readonly string _translationKey;

			private readonly int _translationIndex;

			public string Label => null;

			public bool Ignored => false;

			private float Round(float f)
			{
				return 0f;
			}

			public string CompareTo(AttachmentSummaryPrinter printer, Firearm fa, float otherValue)
			{
				return null;
			}

			public float GetValue(Firearm fa)
			{
				return 0f;
			}

			public ComparableStat(Func<Firearm, float> fetcher, string unit, bool moreIsBetter, string translationKey, int translationIndex, Func<bool> validator = null)
			{
			}

			public ComparableStat(Func<Firearm, float> fetcher, string unit, bool moreIsBetter, AttachmentParam param, Func<bool> validator = null)
			{
			}
		}

		[Serializable]
		private readonly struct ComparableConfiguration
		{
			public readonly string ConfigurationName;

			public readonly uint Code;

			public ComparableConfiguration(ItemType weapon, string label, uint code)
			{
				ConfigurationName = null;
				Code = 0u;
			}
		}

		private const string InventoryTranslationKey = "InventoryGUI";

		private const float InchesToCm = 2.54f;

		private const float KilogramsToLbs = 2.20462f;

		private const float DegreesToMOAs = 60f;

		private static readonly ComparableStat[] StatsToCompare;

		private static readonly List<string>[] ComparisonResults;

		private static readonly float[] OriginalDataNonAlloc;

		private readonly Queue<AttachmentSummaryEntry> _entryPool;

		private readonly HashSet<AttachmentSummaryEntry> _spawnedEntires;

		private readonly HashSet<uint> _displayedCodes;

		private readonly List<ComparableConfiguration> _displayedConfigurations;

		private Firearm _prevFirearm;

		[SerializeField]
		private AttachmentSelectorBase _selectorReference;

		[SerializeField]
		private AttachmentSummaryEntry _tableHeader;

		[SerializeField]
		private AttachmentSummaryEntry _entryTemplate;

		[SerializeField]
		private int _displayedPresets;

		[SerializeField]
		private string _goodColor;

		[SerializeField]
		private string _badColor;

		[SerializeField]
		private Color _oddEntryColor;

		private Firearm Firearm => null;

		private static float GetStatSafe<T>(Firearm fa, Func<T, float> selector, float fallback = 0f)
		{
			return 0f;
		}

		private static bool UsesImperial()
		{
			return false;
		}

		private static bool UsesMetric()
		{
			return false;
		}

		private static bool UsesDispersionMode()
		{
			return false;
		}

		private static bool UsesEffectiveRangeMode()
		{
			return false;
		}

		private void OnEnable()
		{
		}

		private void Update()
		{
		}

		private void Refresh()
		{
		}

		private void UpdateComparableData(int indexToCompare)
		{
		}

		private void PrepareConfigurations(uint initial)
		{
		}

		private void AddConfiguration(uint attachmentCode, string label, bool forceAdd = false)
		{
		}
	}
}
