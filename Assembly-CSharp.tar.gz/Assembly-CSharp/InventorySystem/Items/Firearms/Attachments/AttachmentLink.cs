using System;
using InventorySystem.Items.Firearms.Attachments.Components;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Attachments
{
	[Serializable]
	public class AttachmentLink
	{
		private bool _instanceSet;

		private Attachment _cachedInstance;

		private bool _filterSet;

		private uint _cachedFilter;

		[SerializeField]
		public int Id;

		public Attachment Instance => null;

		public uint Filter => 0u;

		public void InitCache(Firearm fa)
		{
		}

		public void InitCache(ItemType firearmType)
		{
		}

		public Attachment GetAttachment(Firearm instance)
		{
			return null;
		}

		public bool TryGetAttachment(Firearm instance, out Attachment att)
		{
			att = null;
			return false;
		}

		public bool TryGetIndex(ItemType weaponType, out int index)
		{
			index = default(int);
			return false;
		}

		public bool TryGetFilter(ItemType weaponType, out uint filter)
		{
			filter = default(uint);
			return false;
		}

		public uint GetFilter(Firearm firearm)
		{
			return 0u;
		}
	}
}
