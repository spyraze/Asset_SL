using CameraShaking;
using InventorySystem.Items.Firearms.Modules.Misc;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules
{
	public class RecoilPatternModule : ModuleBase, IDisplayableRecoilProviderModule
	{
		private SubsequentShotsCounter _counter;

		[field: SerializeField]
		public RecoilSettings BaseRecoil { get; private set; }

		[field: SerializeField]
		public float AdsRecoilScale { get; private set; }

		[field: SerializeField]
		public AnimationCurve ZAxisScale { get; private set; }

		[field: SerializeField]
		public AnimationCurve FovKickScale { get; private set; }

		[field: SerializeField]
		public AnimationCurve HorizontalKickScale { get; private set; }

		[field: SerializeField]
		public AnimationCurve VerticalKickScale { get; private set; }

		public float DisplayHipRecoilDegrees => 0f;

		public float DisplayAdsRecoilDegrees => 0f;

		public virtual RecoilSettings Evaluate(int numberOfShots, float scale = 1f)
		{
			return default(RecoilSettings);
		}

		internal override void OnAdded()
		{
		}

		private float HipToAds(float hip)
		{
			return 0f;
		}

		private void OnShot()
		{
		}

		private void Update()
		{
		}

		private void OnDestroy()
		{
		}
	}
}
