using System.Collections.Generic;
using Mirror;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules
{
	public class SimpleTriggerModule : ModuleBase, ITriggerControllerModule
	{
		internal class ReceivedData
		{
			public bool IsHeld => false;

			public double PressTime { get; private set; }

			public double ReleaseTime { get; private set; }

			public void Set(bool isHeld)
			{
			}
		}

		private static readonly Dictionary<ushort, ReceivedData> SyncData;

		private readonly ReceivedData _clientData;

		[field: SerializeField]
		public ModuleBase[] IgnoredBusyModules { get; private set; }

		public double LastTriggerPress => 0.0;

		public double LastTriggerRelease => 0.0;

		public bool TriggerHeld => false;

		private ReceivedData SelfData => null;

		private bool KeyHeld => false;

		private bool PreventHoldingTrigger => false;

		internal override void EquipUpdate()
		{
		}

		internal override void OnClientReady()
		{
		}

		public override void ServerProcessCmd(NetworkReader reader)
		{
		}

		public override void ClientProcessRpcTemplate(NetworkReader reader, ushort serial)
		{
		}

		internal static ReceivedData GetData(ushort serial)
		{
			return null;
		}
	}
}
