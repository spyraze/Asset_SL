using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules
{
	public class A7BurnEffectModule : ModuleBase
	{
		[SerializeField]
		private int _maxDuration;

		[SerializeField]
		private int _perShotDuration;

		[SerializeField]
		private float _forwardOffset;

		[SerializeField]
		private float _radius;

		protected override void OnInit()
		{
		}

		private void OnFired()
		{
		}
	}
}
