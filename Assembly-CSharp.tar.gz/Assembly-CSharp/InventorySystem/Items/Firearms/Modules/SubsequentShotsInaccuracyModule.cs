using System.Collections.Generic;
using InventorySystem.Items.Firearms.Modules.Misc;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules
{
	public class SubsequentShotsInaccuracyModule : ModuleBase, IInaccuracyProviderModule
	{
		private class InaccuracySettings
		{
			public float TargetDeviation;

			public int ShotsToReach;

			public int Offset;

			public InaccuracySettings(float targetDeviation, int shotsToReach, int offset)
			{
			}
		}

		private static readonly InaccuracySettings DefaultSettings;

		private static readonly Dictionary<FirearmCategory, InaccuracySettings> SettingsByCategory;

		private SubsequentShotsCounter _shotsCounter;

		private float _inaccuracyNextFrame;

		[SerializeField]
		private StatModifier _optionalModifier;

		public float Inaccuracy { get; private set; }

		private void Update()
		{
		}

		private void OnDestroy()
		{
		}

		internal override void OnAdded()
		{
		}
	}
}
