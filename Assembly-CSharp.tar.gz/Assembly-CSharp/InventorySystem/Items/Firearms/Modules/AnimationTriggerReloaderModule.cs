namespace InventorySystem.Items.Firearms.Modules
{
	public class AnimationTriggerReloaderModule : AnimatorReloaderModuleBase
	{
		protected override void StartReloading()
		{
		}

		protected override void StartUnloading()
		{
		}
	}
}
