namespace InventorySystem.Items.Firearms.Modules
{
	public abstract class ModuleBase : FirearmSubcomponentBase
	{
		public bool IsSubmodule { get; private set; }

		internal void MarkAsSubmodule()
		{
		}

		protected virtual void Reset()
		{
		}
	}
}
