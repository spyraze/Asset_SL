using System.Collections.Generic;
using InventorySystem.Items.Firearms.Extensions;
using InventorySystem.Items.Firearms.ShotEvents;
using InventorySystem.Items.ThrowableProjectiles;
using Mirror;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules
{
	public class DisruptorHitregModule : HitscanHitregModuleBase
	{
		private static readonly RaycastHit[] NonAllocHits;

		private static readonly List<RaycastHit> SortedByDistanceHits;

		private const float ExplosionOffset = 0.15f;

		private bool _hasOwner;

		private DisruptorShotEvent _templateShotData;

		private Ray _lastShotRay;

		private int _serverPenetrations;

		[SerializeField]
		[Header("Single Shot Settings")]
		private float _singleShotBaseDamage;

		[SerializeField]
		private float _singleShotFalloffDistance;

		[SerializeField]
		private float _singleShotDivisionPerTarget;

		[SerializeField]
		private float _singleShotThickness;

		[SerializeField]
		private ExplosionGrenade _singleShotExplosionSettings;

		[SerializeField]
		[Header("Rapid Fire Settings (per shot)")]
		private float _rapidFireBaseDamage;

		[SerializeField]
		private float _rapidFireFalloffDistance;

		public override float BaseDamage
		{
			get
			{
				return 0f;
			}
			protected set
			{
			}
		}

		public override float DamageFalloffDistance
		{
			get
			{
				return 0f;
			}
			protected set
			{
			}
		}

		public override bool UseHitboxMultipliers => false;

		public DisruptorActionModule.FiringState LastFiringState => default(DisruptorActionModule.FiringState);

		private DisruptorShotEvent DisruptorShotData => null;

		internal override void OnAdded()
		{
		}

		public override void ClientProcessRpcTemplate(NetworkReader reader, ushort serial)
		{
		}

		protected override void Fire()
		{
		}

		protected override float ServerProcessObstacleHit(RaycastHit hitInfo)
		{
			return 0f;
		}

		protected override float ServerProcessTargetHit(IDestructible dest, RaycastHit hitInfo)
		{
			return 0f;
		}

		protected override bool ValidateTarget(IDestructible target)
		{
			return false;
		}

		private void ServerPerformSingle(Ray ray, out float targetDamage)
		{
			targetDamage = default(float);
		}

		public static void TemplateSimulateShot(DisruptorShotEvent data, BarrelTipExtension barrelTip)
		{
		}
	}
}
