namespace InventorySystem.Items.Firearms.Modules
{
	[UniqueModule]
	public interface IEquipperModule
	{
		float DisplayBaseEquipTime { get; }

		bool IsEquipped { get; }

		float GetDisplayEffectiveEquipTime(Firearm fa)
		{
			return 0f;
		}
	}
}
