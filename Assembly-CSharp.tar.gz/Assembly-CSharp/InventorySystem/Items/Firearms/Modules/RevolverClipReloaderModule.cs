using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using InventorySystem.Items.Autosync;
using InventorySystem.Items.Firearms.Modules.Misc;
using Mirror;

namespace InventorySystem.Items.Firearms.Modules
{
	public class RevolverClipReloaderModule : AnimatorReloaderModuleBase
	{
		private static readonly Dictionary<ushort, int> SyncWithheld;

		private int _serverWithheld;

		private int _clientWithheld;

		private bool _withheldDirty;

		public int WithheldAmmo => 0;

		private IPrimaryAmmoContainerModule AmmoContainer => null;

		private int ServerWithheld
		{
			get
			{
				return 0;
			}
			set
			{
			}
		}

		public event Action<int> OnAmmoInserted
		{
			[CompilerGenerated]
			add
			{
			}
			[CompilerGenerated]
			remove
			{
			}
		}

		public event Action OnWithheld
		{
			[CompilerGenerated]
			add
			{
			}
			[CompilerGenerated]
			remove
			{
			}
		}

		[ExposedFirearmEvent]
		public void ServerWithholdAmmo()
		{
		}

		[ExposedFirearmEvent]
		public void InsertAmmoFromClip()
		{
		}

		internal override void EquipUpdate()
		{
		}

		internal override void OnHolstered()
		{
		}

		internal override void OnClientReady()
		{
		}

		protected override void OnInit()
		{
		}

		internal override void OnEquipped()
		{
		}

		protected override MessageInterceptionResult InterceptMessage(NetworkReader reader, ushort serial, ReloaderMessageHeader header, AutosyncMessageType scenario)
		{
			return default(MessageInterceptionResult);
		}

		protected override void StartReloading()
		{
		}

		protected override void StartUnloading()
		{
		}

		private void ClientFetchWithheld()
		{
		}

		private void ServerResetWithheldAmmo()
		{
		}

		private void DecockAndPlayAnim(int hash)
		{
		}
	}
}
