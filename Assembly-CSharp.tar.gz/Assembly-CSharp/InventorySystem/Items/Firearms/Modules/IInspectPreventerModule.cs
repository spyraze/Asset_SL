namespace InventorySystem.Items.Firearms.Modules
{
	public interface IInspectPreventerModule
	{
		bool InspectionAllowed { get; }
	}
}
