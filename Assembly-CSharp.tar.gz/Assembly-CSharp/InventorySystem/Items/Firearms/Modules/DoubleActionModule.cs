using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using InventorySystem.Items.Firearms.Modules.Misc;
using Mirror;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules
{
	public class DoubleActionModule : ModuleBase, IActionModule, IBusyIndicatorModule, IInspectPreventerModule
	{
		private enum MessageType : byte
		{
			RpcNewPlayerResync = 0,
			RpcSetCockedTrue = 1,
			RpcSetCockedFalse = 2,
			RpcFire = 3,
			RpcDryFire = 4,
			CmdUpdatePulling = 5,
			CmdShoot = 6,
			StartPulling = 7,
			StartCocking = 8
		}

		private class TriggerPull
		{
			private double _pullStartTime;

			private double _pullEndTime;

			private double InverseLerpTime => 0.0;

			public float PullProgress => 0f;

			public bool IsPulling { get; private set; }

			public void Pull(float durationSeconds)
			{
			}

			public void Reset()
			{
			}
		}

		private static readonly HashSet<ushort> CockedHashes;

		private const float CockingKeyMaxHoldTime = 0.5f;

		[SerializeField]
		private float _baseDoubleActionTime;

		[SerializeField]
		private float _basePostShotCooldown;

		[SerializeField]
		private AudioClip[] _fireClips;

		[SerializeField]
		private AudioClip _dryFireClip;

		[SerializeField]
		private AudioClip _doubleActionClip;

		[SerializeField]
		private AudioClip _cockingClip;

		[SerializeField]
		private AudioClip _decockingClip;

		private float _cockingKeyHoldTime;

		private int? _afterDecockTrigger;

		private bool _cockingBusy;

		private bool _serverPullTokenUsed;

		private ClientPredictedValue<bool> _clientCocked;

		private AudioModule _audioModule;

		private CylinderAmmoModule _cylinderModule;

		private IHitregModule _hitregModule;

		private readonly TriggerPull _triggerPull;

		private readonly ClientRequestTimer _cockRequestTimer;

		private readonly FullAutoRateLimiter _clientShotCooldown;

		private readonly FullAutoRateLimiter _serverShotCooldown;

		public bool IsBusy => false;

		public bool InspectionAllowed => false;

		public bool Cocked
		{
			get
			{
				return false;
			}
			private set
			{
			}
		}

		public float TriggerPullProgress => 0f;

		public float DisplayCyclicRate => 0f;

		public bool IsLoaded => false;

		private float DoubleActionTime => 0f;

		private float TimeBetweenShots => 0f;

		private bool OnCooldown => false;

		private bool IsCocking => false;

		public static event Action<ushort, bool> OnCockedChanged
		{
			[CompilerGenerated]
			add
			{
			}
			[CompilerGenerated]
			remove
			{
			}
		}

		public static bool GetCocked(ushort serial)
		{
			return false;
		}

		public void TriggerDecocking(int? nextTriggerHash = null)
		{
		}

		public void TriggerCocking()
		{
		}

		[ExposedFirearmEvent]
		public void SetCocked(bool value)
		{
		}

		[ExposedFirearmEvent]
		public void OnDecockingAnimComplete()
		{
		}

		[ExposedFirearmEvent]
		public void OnCockingAnimComplete()
		{
		}

		public override void ClientProcessRpcTemplate(NetworkReader reader, ushort serial)
		{
		}

		public override void ClientProcessRpcInstance(NetworkReader reader)
		{
		}

		public override void ServerProcessCmd(NetworkReader reader)
		{
		}

		protected override void OnInit()
		{
		}

		internal override void OnClientReady()
		{
		}

		internal override void ServerOnPlayerConnected(ReferenceHub hub, bool firstModule)
		{
		}

		internal override void OnHolstered()
		{
		}

		internal override void OnEquipped()
		{
		}

		internal override void EquipUpdate()
		{
		}

		private void UpdateInputs()
		{
		}

		private void Fire(NetworkReader extraData)
		{
		}

		private void FireLive(CylinderAmmoModule.Chamber chamber, NetworkReader extraData)
		{
		}

		private void FireDry()
		{
		}

		private void PlayFireAnims(int hash)
		{
		}

		private MessageType DecodeHeader(NetworkReader reader)
		{
			return default(MessageType);
		}

		private void SendRpc(MessageType header, Action<NetworkWriter> writerFunc = null, bool toAll = true)
		{
		}

		private void SendCmd(MessageType header, Action<NetworkWriter> writerFunc = null)
		{
		}
	}
}
