using System.Collections.Generic;
using InventorySystem.Items.Firearms.Attachments;
using InventorySystem.Items.Firearms.Modules.Misc;
using Mirror;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules
{
	public class GripControllerModule : ModuleBase
	{
		private static readonly HashSet<ushort> SyncEnabledGrips;

		[SerializeField]
		private AttachmentLink _gripAttachmentLink;

		[SerializeField]
		private AnimatorLayerMask _layers;

		private float _lastWeight;

		private float _adjustSpeed;

		private int? _activeSafeguard;

		private FirearmEvent _safeguardEvent;

		private float _safeguardDuration;

		private bool SkippingForward => false;

		[ExposedFirearmEvent]
		public void EnableGripLayer(float transitionDurationFrames)
		{
		}

		[ExposedFirearmEvent]
		public void DisableGripLayer(float transitionDurationFrames)
		{
		}

		[ExposedFirearmEvent]
		public void SetSafeguards(float transitionDurationFrames)
		{
		}

		internal override void SpectatorPostprocessSkip()
		{
		}

		internal override void EquipUpdate()
		{
		}

		protected override void OnInit()
		{
		}

		internal override void OnHolstered()
		{
		}

		internal override void OnClientReady()
		{
		}

		internal override void ServerOnPlayerConnected(ReferenceHub hub, bool firstModule)
		{
		}

		public override void ClientProcessRpcTemplate(NetworkReader reader, ushort serial)
		{
		}

		private void ModifyGripSpeed(float transitionDurationFrames, bool targetEnable)
		{
		}

		private void ForceWeight(float weight)
		{
		}

		private void UpdateWeight()
		{
		}

		private void UpdateSafeguard()
		{
		}
	}
}
