using System;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules.Misc
{
	[Serializable]
	public class AnimatorConditionalOverride
	{
		[SerializeField]
		private AnimatorLayerMask _mask;

		[SerializeField]
		private float _enableSpeed;

		[SerializeField]
		private float _disableSpeed;

		[SerializeField]
		private bool _disableWhenHandling;

		private float _weight;

		private float _handlingElapsed;

		private bool _wasReloading;

		private const float HandlingTransitionCompensation = 0.2f;

		private static readonly int HandlingTag;

		private bool IsReloading(Firearm firearm)
		{
			return false;
		}

		private bool IsHandling(Firearm firearm)
		{
			return false;
		}

		public void Update(Firearm firearm, bool enabled)
		{
		}
	}
}
