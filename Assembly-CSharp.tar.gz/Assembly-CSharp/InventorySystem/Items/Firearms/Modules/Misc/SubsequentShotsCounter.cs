using System;
using System.Runtime.CompilerServices;
using InventorySystem.Items.Firearms.ShotEvents;

namespace InventorySystem.Items.Firearms.Modules.Misc
{
	public class SubsequentShotsCounter
	{
		private bool _destructed;

		private float _counter;

		private float _decaySpeed;

		private float _remainingSustain;

		private readonly Firearm _firearm;

		private readonly float _sustainMultiplier;

		private readonly float _sustainAddition;

		private readonly float _decayTime;

		public int SubsequentShots
		{
			get
			{
				return 0;
			}
			private set
			{
			}
		}

		public event Action OnShotRecorded
		{
			[CompilerGenerated]
			add
			{
			}
			[CompilerGenerated]
			remove
			{
			}
		}

		public event Action OnReset
		{
			[CompilerGenerated]
			add
			{
			}
			[CompilerGenerated]
			remove
			{
			}
		}

		private void OnShot(ShotEvent ev)
		{
		}

		public void Update()
		{
		}

		public void Destruct()
		{
		}

		public SubsequentShotsCounter(Firearm firearm, float sustainCycleTimeMultiplier = 1f, float sustainAdditionSeconds = 0.1f, float decayTimeSeconds = 0.4f)
		{
		}

		~SubsequentShotsCounter()
		{
		}
	}
}
