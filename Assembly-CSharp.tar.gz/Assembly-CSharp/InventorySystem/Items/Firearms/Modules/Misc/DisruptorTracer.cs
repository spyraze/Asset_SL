using System;
using System.Diagnostics;
using Mirror;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules.Misc
{
	public class DisruptorTracer : TracerBase
	{
		[Serializable]
		private class EffectsPair
		{
			private const float DistanceToSpeed = 100f;

			public ParticleSystem[] Particles;

			public BulletWhizzHandler WhizzHandler;

			public float WhizzTriggerRangeSqr;

			public void Play(float distance)
			{
			}
		}

		private const float RecycleTime = 5f;

		private const float MinLength = 0.5f;

		private const float MaxLength = 35f;

		[SerializeField]
		private EffectsPair _singleShotEffects;

		[SerializeField]
		private EffectsPair _rapidFireEffects;

		private Transform _tr;

		private Stopwatch _stopwatch;

		protected override bool IsBusy => false;

		protected override void OnCreated()
		{
		}

		protected override void OnDequeued()
		{
		}

		protected override void OnFired(NetworkReader reader)
		{
		}

		public override void ServerWriteExtraData(Firearm firearm, NetworkWriter writer)
		{
		}
	}
}
