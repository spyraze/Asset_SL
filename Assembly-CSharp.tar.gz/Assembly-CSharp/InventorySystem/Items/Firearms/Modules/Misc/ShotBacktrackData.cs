using System;
using Mirror;
using RelativePositioning;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules.Misc
{
	public readonly struct ShotBacktrackData
	{
		private static readonly RelativePosition DefaultPos;

		public readonly RelativePosition RelativeOwnerPosition;

		public readonly Quaternion RelativeOwnerRotation;

		public readonly bool HasPrimaryTarget;

		public readonly ReferenceHub PrimaryTargetHub;

		public readonly RelativePosition PrimaryTargetRelativePosition;

		public readonly double CreationTimestamp;

		public double Age => 0.0;

		public void WriteSelf(NetworkWriter writer)
		{
		}

		public void ProcessShot(Firearm firearm, Action<ReferenceHub> processingMethod)
		{
		}

		public ShotBacktrackData(NetworkReader reader)
		{
			RelativeOwnerPosition = default(RelativePosition);
			RelativeOwnerRotation = default(Quaternion);
			HasPrimaryTarget = false;
			PrimaryTargetHub = null;
			PrimaryTargetRelativePosition = default(RelativePosition);
			CreationTimestamp = 0.0;
		}

		public ShotBacktrackData(Firearm firearm)
		{
			RelativeOwnerPosition = default(RelativePosition);
			RelativeOwnerRotation = default(Quaternion);
			HasPrimaryTarget = false;
			PrimaryTargetHub = null;
			PrimaryTargetRelativePosition = default(RelativePosition);
			CreationTimestamp = 0.0;
		}

		private static bool TryGetPrimaryTarget(Firearm firearm, out HitboxIdentity bestHitbox)
		{
			bestHitbox = null;
			return false;
		}
	}
}
