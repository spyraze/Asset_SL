using System;

namespace InventorySystem.Items.Firearms.Modules.Misc
{
	public class ClientPredictedValue<T>
	{
		private readonly Func<T> _fetcher;

		private readonly ClientRequestTimer _predictionTimeout;

		private T _predicted;

		public T Value
		{
			get
			{
				return default(T);
			}
			set
			{
			}
		}

		public void ForceResync()
		{
		}

		public ClientPredictedValue(Func<T> serverSyncvarFetcher)
		{
		}
	}
}
