using System.Collections.Generic;
using Mirror;
using RelativePositioning;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules.Misc
{
	public abstract class TracerBase : MonoBehaviour
	{
		private Queue<TracerBase> _instancesPool;

		private bool _isInstance;

		private Vector3? _origin;

		private Vector3 _fallbackOrigin;

		public Vector3 OriginPosition => default(Vector3);

		public RelativePosition RelativeHitPosition { get; private set; }

		public ushort Serial { get; private set; }

		public Firearm Template { get; private set; }

		protected abstract bool IsBusy { get; }

		protected virtual void OnCreated()
		{
		}

		protected virtual void OnDequeued()
		{
		}

		protected abstract void OnFired(NetworkReader extraData);

		public virtual void ServerWriteExtraData(Firearm firearm, NetworkWriter writer)
		{
		}

		public void Fire(RelativePosition hitPosition, ushort serial, Vector3 fallbackOriginPosition, NetworkReader extraData, Firearm template)
		{
		}

		public TracerBase GetFromPool()
		{
			return null;
		}
	}
}
