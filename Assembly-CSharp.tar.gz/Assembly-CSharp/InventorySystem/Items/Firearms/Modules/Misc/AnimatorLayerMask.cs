using System;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules.Misc
{
	[Serializable]
	public class AnimatorLayerMask
	{
		[SerializeField]
		private int _maskValue;

		private int _cachedMaskValue;

		private int[] _cachedMaskArray;

		public int[] Layers
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		public void SetLayer(int layerIndex, bool state)
		{
		}

		public bool GetLayer(int layerIndex)
		{
			return false;
		}

		public void SetWeight(Animator anim, float weight)
		{
		}

		public void SetWeight(Action<int, float> setter, float weight)
		{
		}
	}
}
