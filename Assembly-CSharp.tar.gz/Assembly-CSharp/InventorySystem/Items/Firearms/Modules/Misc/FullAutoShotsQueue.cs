using System;
using System.Collections.Generic;

namespace InventorySystem.Items.Firearms.Modules.Misc
{
	public class FullAutoShotsQueue<T> : FullAutoRateLimiter
	{
		private const float NetworkShootRequestTimeout = 0.15f;

		public Action<T> OnRequestRejected;

		private readonly Queue<T> _queuedShots;

		private readonly Func<T, ShotBacktrackData> _dataSelector;

		public bool Idle => false;

		public void Enqueue(T item)
		{
		}

		public bool TryDequeue(out T dequeued)
		{
			dequeued = default(T);
			return false;
		}

		public FullAutoShotsQueue(Func<T, ShotBacktrackData> backtrackDataSelector)
		{
		}
	}
}
