using System.Diagnostics;
using RelativePositioning;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules.Misc
{
	public class BulletWhizzHandler : MonoBehaviour
	{
		private AudioSource _src;

		private RelativePosition _midpoint;

		private Vector3 _dir;

		private Transform _srcTr;

		private bool _wasPlaying;

		private readonly Stopwatch _sw;

		[field: SerializeField]
		public AudioClip[] Clips { get; private set; }

		[field: SerializeField]
		public float SourceRange { get; private set; }

		[field: SerializeField]
		public float MidpointTime { get; private set; }

		[field: SerializeField]
		public float TravelDistance { get; private set; }

		public bool IsPlaying => false;

		private AudioSource Source => null;

		public void Play(Vector3 dir, Vector3 midpoint)
		{
		}

		private void Update()
		{
		}
	}
}
