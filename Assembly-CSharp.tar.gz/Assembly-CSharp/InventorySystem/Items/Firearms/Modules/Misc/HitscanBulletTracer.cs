using System.Collections.Generic;
using System.Diagnostics;
using Mirror;
using UnityEngine;
using UnityEngine.VFX;

namespace InventorySystem.Items.Firearms.Modules.Misc
{
	public class HitscanBulletTracer : TracerBase
	{
		private const float MinLength = 1f;

		private const float MaxLength = 15f;

		private const float RandomMaxChanceDot = 0.08f;

		private const float RandomNoChanceDot = 0.35f;

		private const float WhizzTriggerRangeSqr = 25f;

		private const float RandomFriendlyFireMultiplier = 0.5f;

		private static readonly int TracerOriginHash;

		private static readonly int TracerFriendlyHash;

		private static readonly Dictionary<FirearmCategory, float> CategoryMultipliers;

		[SerializeField]
		private VisualEffect _vfx;

		[SerializeField]
		private float _minimalDuration;

		private Transform _tr;

		private BulletWhizzHandler _whizzHandler;

		private bool _supportsWhizz;

		private Stopwatch _stopwatch;

		protected override bool IsBusy => false;

		public override void ServerWriteExtraData(Firearm firearm, NetworkWriter writer)
		{
		}

		protected override void OnCreated()
		{
		}

		protected override void OnDequeued()
		{
		}

		protected override void OnFired(NetworkReader reader)
		{
		}

		private static bool ValidateRandom(float verticalDot, bool isFriendly, FirearmCategory cat)
		{
			return false;
		}
	}
}
