using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules.Misc
{
	public readonly struct EventInvocationDetails
	{
		public readonly bool EverInvoked;

		public readonly float StateSpeed;

		public readonly float ParamSpeed;

		public readonly int Layer;

		public readonly Animator RawAnimator;

		public float TotalSpeedMultiplier => 0f;

		public EventInvocationDetails(AnimatorStateInfo stateInfo, Animator sourceAnimator, int callerLayer)
		{
			EverInvoked = false;
			StateSpeed = 0f;
			ParamSpeed = 0f;
			Layer = 0;
			RawAnimator = null;
		}

		public EventInvocationDetails(bool everInvoked, float stateSpeed, float paramSpeed, int layer, Animator rawAnimator)
		{
			EverInvoked = false;
			StateSpeed = 0f;
			ParamSpeed = 0f;
			Layer = 0;
			RawAnimator = null;
		}
	}
}
