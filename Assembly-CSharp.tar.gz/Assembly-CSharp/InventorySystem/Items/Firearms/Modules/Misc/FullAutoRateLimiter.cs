namespace InventorySystem.Items.Firearms.Modules.Misc
{
	public class FullAutoRateLimiter
	{
		private bool _lastWasReady;

		private float _remainingCooldown;

		public bool Ready => false;

		public void Update()
		{
		}

		public void Clear()
		{
		}

		public void Trigger(float cooldown)
		{
		}
	}
}
