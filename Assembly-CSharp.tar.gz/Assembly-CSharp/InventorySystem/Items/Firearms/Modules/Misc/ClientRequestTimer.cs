using System.Diagnostics;

namespace InventorySystem.Items.Firearms.Modules.Misc
{
	public class ClientRequestTimer
	{
		private const float AdditionalTimeout = 0.25f;

		private Stopwatch _stopwatch;

		private double _timeoutDuration;

		public bool Sent { get; private set; }

		public bool Busy => false;

		public bool TimedOut => false;

		public void Trigger()
		{
		}

		public void Reset()
		{
		}
	}
}
