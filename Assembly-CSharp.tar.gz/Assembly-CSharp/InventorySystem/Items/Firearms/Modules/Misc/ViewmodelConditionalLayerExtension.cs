using InventorySystem.Items.Firearms.Extensions;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules.Misc
{
	public class ViewmodelConditionalLayerExtension : MonoBehaviour, IViewmodelExtension
	{
		private Firearm _firearm;

		[SerializeField]
		private ConditionalEvaluator _condition;

		[SerializeField]
		private AnimatorConditionalOverride _layer;

		public void InitViewmodel(AnimatedFirearmViewmodel viewmodel)
		{
		}

		private void LateUpdate()
		{
		}
	}
}
