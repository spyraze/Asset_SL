using System.Collections.Generic;
using InventorySystem.Items.Autosync;
using Mirror;

namespace InventorySystem.Items.Firearms.Modules
{
	public class AnimationToggleableReloaderModule : AnimatorReloaderModuleBase
	{
		private enum RpcType
		{
			LoadableAmmoSync = 0,
			StopAnimations = 1
		}

		private static readonly ActionName[] CancelActions;

		private static readonly Dictionary<ushort, int> SyncLoadableAmmo;

		private readonly RateLimiter _postCancelLimiter;

		private int _prevLoadableAmmo;

		private int ServerLoadableAmmo => 0;

		internal override void EquipUpdate()
		{
		}

		internal override void OnEquipped()
		{
		}

		protected override MessageInterceptionResult InterceptMessage(NetworkReader reader, ushort serial, ReloaderMessageHeader header, AutosyncMessageType scenario)
		{
			return default(MessageInterceptionResult);
		}

		protected override void StartReloading()
		{
		}

		protected override void StartUnloading()
		{
		}

		protected override void OnStopReloadingAndUnloading()
		{
		}

		private void ProcessCustomRpc(NetworkReader reader, ushort serial, RpcType rpc, AutosyncMessageType messageType)
		{
		}

		private void StopAnimations()
		{
		}

		private void UpdateLocalPlayer()
		{
		}

		private void UpdateServer()
		{
		}

		private void ServerSendLoadableAmmo()
		{
		}
	}
}
