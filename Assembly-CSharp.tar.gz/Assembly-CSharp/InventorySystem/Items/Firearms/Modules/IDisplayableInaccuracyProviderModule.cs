namespace InventorySystem.Items.Firearms.Modules
{
	public interface IDisplayableInaccuracyProviderModule : IInaccuracyProviderModule
	{
		DisplayInaccuracyValues DisplayInaccuracy { get; }

		static DisplayInaccuracyValues GetCombinedDisplayInaccuracy(Firearm firearm, bool addBulletToRest = false)
		{
			return default(DisplayInaccuracyValues);
		}

		static float GetDisplayAccurateRange(float dispersionDegrees, bool imperial, bool rounded)
		{
			return 0f;
		}
	}
}
