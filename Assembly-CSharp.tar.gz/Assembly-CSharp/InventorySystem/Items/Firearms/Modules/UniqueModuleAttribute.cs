using System;

namespace InventorySystem.Items.Firearms.Modules
{
	[AttributeUsage(AttributeTargets.Interface)]
	public class UniqueModuleAttribute : Attribute
	{
	}
}
