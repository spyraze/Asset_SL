using System;
using System.Collections.Generic;
using InventorySystem.Items.Firearms.Modules.Misc;
using Mirror;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules
{
	public class PumpActionModule : ModuleBase, IActionModule, IAmmoContainerModule, IBusyIndicatorModule, ITriggerPressPreventerModule, IReloadUnloadValidatorModule, IDisplayableAmmoProviderModule, IInspectPreventerModule
	{
		private enum RpcType
		{
			ResyncOne = 0,
			ResyncAll = 1,
			Shoot = 2,
			SchedulePump = 3
		}

		private static readonly Dictionary<ushort, byte> ChamberedBySerial;

		private static readonly Dictionary<ushort, byte> CockedBySerial;

		private static readonly int PumpTriggerHash;

		private readonly FullAutoShotsQueue<ShotBacktrackData> _serverQueuedShots;

		private readonly FullAutoRateLimiter _clientRateLimiter;

		private readonly FullAutoRateLimiter _pumpingDelayTimer;

		private readonly FullAutoRateLimiter _pumpingRemaining;

		private ClientPredictedValue<int> _clientChambered;

		private ClientPredictedValue<int> _clientCocked;

		private ClientPredictedValue<int> _clientMagazine;

		private bool _pumpingScheduled;

		[SerializeField]
		private int _numberOfBarrels;

		[SerializeField]
		private int _baseShotsPerTriggerPull;

		[SerializeField]
		private float _basePumpingDuration;

		[SerializeField]
		private float _baseCooldownAfterShot;

		[SerializeField]
		private AudioClip _dryFireClip;

		[SerializeField]
		private AudioClip[] _shotClipPerBarrelIndex;

		private float PumpingDuration => 0f;

		private bool PumpIdle => false;

		private float CooldownAfterShot => 0f;

		private int ShotsPerTriggerPull => 0;

		private int MagazineAmmo => 0;

		private int SyncChambered
		{
			get
			{
				return 0;
			}
			set
			{
			}
		}

		private int SyncCocked
		{
			get
			{
				return 0;
			}
			set
			{
			}
		}

		public float DisplayCyclicRate => 0f;

		public int AmmoStored => 0;

		public int AmmoMax => 0;

		public bool IsBusy => false;

		public bool ClientBlockTrigger => false;

		public IReloadUnloadValidatorModule.Authorization ReloadAuthorization => default(IReloadUnloadValidatorModule.Authorization);

		public IReloadUnloadValidatorModule.Authorization UnloadAuthorization => default(IReloadUnloadValidatorModule.Authorization);

		public DisplayAmmoValues PredictedDisplayAmmo => default(DisplayAmmoValues);

		public bool InspectionAllowed => false;

		public bool IsLoaded => false;

		internal override void OnEquipped()
		{
		}

		internal override void OnHolstered()
		{
		}

		protected override void OnInit()
		{
		}

		internal override void EquipUpdate()
		{
		}

		internal override void ServerOnPlayerConnected(ReferenceHub hub, bool firstModule)
		{
		}

		internal override void OnClientReady()
		{
		}

		public override void ServerProcessCmd(NetworkReader reader)
		{
		}

		public override void ClientProcessRpcTemplate(NetworkReader reader, ushort serial)
		{
		}

		public override void ClientProcessRpcInstance(NetworkReader reader)
		{
		}

		public void Pump()
		{
		}

		public DisplayAmmoValues GetDisplayAmmoForSerial(ushort serial)
		{
			return default(DisplayAmmoValues);
		}

		public int GetAmmoStoredForSerial(ushort serial)
		{
			return 0;
		}

		private void SchedulePumping(int shotsFired)
		{
		}

		private void UpdateClient()
		{
		}

		private void PullTrigger(bool clientside, out int shotsFired)
		{
			shotsFired = default(int);
		}

		private bool ShootOneBarrel(bool clientside)
		{
			return false;
		}

		private void PlaySound(Action<AudioModule> method, bool clientside)
		{
		}

		private void UpdateServer()
		{
		}

		private void ServerProcessShot(ReferenceHub primaryTarget)
		{
		}

		private void ServerResync()
		{
		}

		private void SetSyncValue(Dictionary<ushort, byte> syncDictionary, int value)
		{
		}

		private int GetSyncValue(Dictionary<ushort, byte> syncDictionary)
		{
			return 0;
		}

		private static int GetSyncValue(ushort serial, Dictionary<ushort, byte> syncDictionary)
		{
			return 0;
		}

		public static int GetChamberedCount(ushort serial)
		{
			return 0;
		}

		public static int GetCockedCount(ushort serial)
		{
			return 0;
		}
	}
}
