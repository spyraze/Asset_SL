using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using AudioPooling;
using InventorySystem.Items.Firearms.Modules.Misc;
using Mirror;
using PlayerRoles;
using UnityEngine;
using UnityEngine.Events;

namespace InventorySystem.Items.Firearms.Modules
{
	public class AudioModule : ModuleBase
	{
		private const float SyncMinPitch = 0.3f;

		private const float SyncMaxPitch = 3f;

		private const float NearRange = 5f;

		private const float MidRange = 12f;

		private const float MaxHeightLoudnessSqr = 5000f;

		private const float SendDistanceBuffer = 20f;

		private const float SyncRangeAccuracy = 20f;

		[SerializeField]
		private float _gunshotSoundRandomization;

		[SerializeField]
		private AudioClip[] _eventClips;

		private readonly List<AudioClip> _registeredClips;

		private readonly Dictionary<AudioClip, int> _clipToIndex;

		[field: SerializeField]
		public float BaseGunshotRange { get; private set; }

		public float FinalGunshotRange => 0f;

		private float RandomPitch => 0f;

		public static event Action<ItemIdentifier, PlayerRoleBase, PooledAudioSource> OnSoundPlayed
		{
			[CompilerGenerated]
			add
			{
			}
			[CompilerGenerated]
			remove
			{
			}
		}

		public override void ClientProcessRpcTemplate(NetworkReader reader, ushort serial)
		{
		}

		[ExposedFirearmEvent(UnityEventCallState.EditorAndRuntime)]
		public void PlayQuiet(AudioClip clip)
		{
		}

		[ExposedFirearmEvent(UnityEventCallState.EditorAndRuntime)]
		public void PlayNormal(AudioClip clip)
		{
		}

		[ExposedFirearmEvent(UnityEventCallState.EditorAndRuntime)]
		public void PlayClientside(AudioClip clip)
		{
		}

		public void PlayGunshot(AudioClip clip)
		{
		}

		internal void RegisterClip(AudioClip clip)
		{
		}

		protected override void OnInit()
		{
		}

		private void ProcessEvent(AudioClip clip, MixerChannel mixerChannel, float audioRange, bool sync, bool applyPitch)
		{
		}

		private void ServerSendToNearbyPlayers(int index, MixerChannel channel, float audioRange, float pitch)
		{
		}

		private void ServerSend(NetworkWriter writer, int index, float pitch, MixerChannel channel, float range, Vector3 shooterPosition, bool shooterVisible)
		{
		}

		private void ClientReceiveThirdperson(ushort serial, PlayerRoleBase shooter, NetworkReader reader)
		{
		}

		private Transform GetAudioSourceParent(MixerChannel mixerChannel, PlayerRoleBase shooter)
		{
			return null;
		}
	}
}
