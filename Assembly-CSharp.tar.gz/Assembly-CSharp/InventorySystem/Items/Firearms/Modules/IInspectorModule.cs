namespace InventorySystem.Items.Firearms.Modules
{
	public interface IInspectorModule
	{
		bool DisplayInspecting { get; }
	}
}
