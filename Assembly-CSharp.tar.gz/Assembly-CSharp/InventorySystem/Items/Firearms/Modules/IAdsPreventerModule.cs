namespace InventorySystem.Items.Firearms.Modules
{
	public interface IAdsPreventerModule
	{
		bool AdsAllowed { get; }
	}
}
