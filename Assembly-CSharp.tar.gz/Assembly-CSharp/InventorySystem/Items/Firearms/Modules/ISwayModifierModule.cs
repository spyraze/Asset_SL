namespace InventorySystem.Items.Firearms.Modules
{
	public interface ISwayModifierModule
	{
		float WalkSwayScale => 0f;

		float JumpSwayScale => 0f;

		float BobbingSwayScale => 0f;
	}
}
