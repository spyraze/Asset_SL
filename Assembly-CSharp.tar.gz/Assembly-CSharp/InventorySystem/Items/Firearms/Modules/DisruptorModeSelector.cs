using System;
using System.Runtime.CompilerServices;
using InventorySystem.Items.Firearms.Modules.Misc;
using Mirror;
using PlayerRoles.Subroutines;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules
{
	public class DisruptorModeSelector : ModuleBase, IRecoilScalingModule
	{
		private const float SwitchCooldown = 0.4f;

		private readonly TolerantAbilityCooldown _switchCooldown;

		private AudioModule _audioModule;

		[SerializeField]
		private AudioClip _singleClip;

		[SerializeField]
		private AudioClip _rapidClip;

		[SerializeField]
		private float _singleRecoilScale;

		public bool SingleShotSelected { get; private set; }

		public float RecoilMultiplier => 0f;

		public event Action OnAnimationRequested
		{
			[CompilerGenerated]
			add
			{
			}
			[CompilerGenerated]
			remove
			{
			}
		}

		[ExposedFirearmEvent]
		public void RequestAnimation()
		{
		}

		protected override void OnInit()
		{
		}

		internal override void EquipUpdate()
		{
		}

		public override void ServerProcessCmd(NetworkReader reader)
		{
		}

		public override void ClientProcessRpcInstance(NetworkReader reader)
		{
		}
	}
}
