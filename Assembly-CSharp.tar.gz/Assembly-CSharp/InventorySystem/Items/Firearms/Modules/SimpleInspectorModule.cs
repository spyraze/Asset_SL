using System.Collections.Generic;
using AudioPooling;
using InventorySystem.Items.Firearms.Modules.Misc;
using Mirror;
using PlayerRoles;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules
{
	public class SimpleInspectorModule : ModuleBase, ITriggerPressPreventerModule, ISwayModifierModule, IInspectorModule
	{
		private static readonly HashSet<ushort> SpectatorInspectingFirearms;

		private const float MinimalIdleTime = 0.15f;

		private const float MaxTransitionTime = 0.365f;

		private const float SwayAdjustSpeed = 5f;

		private const float ClipStoppingSpeed = 10f;

		private float _idleElapsed;

		private bool _isInspecting;

		private bool _eventListenerSet;

		private readonly List<AudioPoolSession> _capturedClips;

		[Tooltip("Layer that contains the inspect animation. It must contain an idle state with 'Idle' tag, to which the animation returns when ends.")]
		[SerializeField]
		private AnimatorLayerMask _inspectLayer;

		[SerializeField]
		[Tooltip("Scale of hip-fire bobbing when inspecting.")]
		private float _bobbingScale;

		[SerializeField]
		[Tooltip("Scale of runnin sway when inspecting")]
		private float _walkSwayScale;

		[SerializeField]
		[Tooltip("Scale of runnin sway when inspecting")]
		private float _jumpSwayScale;

		[SerializeField]
		[Tooltip("List of clips produced by audio manager that will be automatically stopped when the inspection is interrupted.")]
		private AudioClip[] _clipsToStopOnInterrupt;

		private bool ValidateStart => false;

		private bool ValidateUpdate => false;

		public bool ClientBlockTrigger { get; private set; }

		public float WalkSwayScale { get; private set; }

		public float JumpSwayScale { get; private set; }

		public float BobbingSwayScale { get; private set; }

		public bool DisplayInspecting => false;

		private void SetInspecting(bool val)
		{
		}

		private void UpdateSwayScale()
		{
		}

		private void InterceptNewSound(ItemIdentifier id, PlayerRoleBase role, PooledAudioSource src)
		{
		}

		private void StopInspectSounds()
		{
		}

		private void OnDestroy()
		{
		}

		internal override void EquipUpdate()
		{
		}

		internal override void OnEquipped()
		{
		}

		internal override void OnHolstered()
		{
		}

		internal override void OnClientReady()
		{
		}

		internal override void SpectatorInit()
		{
		}

		protected override void OnInit()
		{
		}

		public override void ServerProcessCmd(NetworkReader reader)
		{
		}

		public override void ClientProcessRpcInstance(NetworkReader reader)
		{
		}

		public override void ClientProcessRpcTemplate(NetworkReader reader, ushort serial)
		{
		}

		[ExposedFirearmEvent]
		public void BlockTrigger()
		{
		}

		[ExposedFirearmEvent]
		public void ReleaseTriggerLock()
		{
		}
	}
}
