namespace InventorySystem.Items.Firearms.Modules
{
	public readonly struct DisplayInaccuracyValues
	{
		public readonly float HipDeg;

		public readonly float AdsDeg;

		public readonly float RunningDeg;

		public readonly float BulletDeg;

		public float GetHipAccurateRange(bool imperial, bool rounded)
		{
			return 0f;
		}

		public float GetAdsAccurateRange(bool imperial, bool rounded)
		{
			return 0f;
		}

		public float GetRunningAccurateRange(bool imperial, bool rounded)
		{
			return 0f;
		}

		public DisplayInaccuracyValues(float hip = 0f, float ads = 0f, float running = 0f, float bullet = 0f)
		{
			HipDeg = 0f;
			AdsDeg = 0f;
			RunningDeg = 0f;
			BulletDeg = 0f;
		}
	}
}
