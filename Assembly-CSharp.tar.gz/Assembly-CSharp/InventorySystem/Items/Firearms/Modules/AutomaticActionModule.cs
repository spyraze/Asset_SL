using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using InventorySystem.Items.Firearms.Modules.Misc;
using Mirror;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules
{
	public class AutomaticActionModule : ModuleBase, IActionModule, IAmmoContainerModule, IBusyIndicatorModule, IDisplayableAmmoProviderModule, IInspectPreventerModule
	{
		private enum MessageHeader
		{
			CmdShoot = 0,
			RpcPublicSync = 1,
			RpcResponse = 2,
			RpcFire = 3,
			RpcDryFire = 4,
			RpcNewPlayerSync = 5
		}

		[Flags]
		private enum SyncDataFlags : byte
		{
			None = 0,
			AmmoChamberedBit0 = 1,
			AmmoChamberedBit1 = 2,
			AmmoChamberedBit2 = 4,
			AmmoChamberedBit3 = 8,
			Cocked = 0x10,
			BoltLocked = 0x20,
			AmmoChamberedFilter = 0xF
		}

		private readonly struct ShotRequest
		{
			public readonly int PredictedReserve;

			public readonly ShotBacktrackData BacktrackData;

			public ShotRequest(AutomaticActionModule mod)
			{
				PredictedReserve = 0;
				BacktrackData = default(ShotBacktrackData);
			}

			public ShotRequest(NetworkReader reader)
			{
				PredictedReserve = 0;
				BacktrackData = default(ShotBacktrackData);
			}

			public void Write(NetworkWriter writer)
			{
			}
		}

		[Serializable]
		private struct GunshotDefinition
		{
			public AudioClip[] RandomSounds;

			[Tooltip("Value provided in ShotClipIdOverride. Zero if no attachments.")]
			public int ClipId;

			[Tooltip("This gunshot sound will only be used if number of chambers fired is greater or equal to this amount.")]
			[Range(1f, 16f)]
			public int MinChamberedRounds;

			[Range(1f, 16f)]
			[Tooltip("This gunshot sound will only be used if number of chambers fired is less or equal to this amount.")]
			public int MaxChamberedRounds;
		}

		private static readonly Dictionary<ushort, SyncDataFlags> ReceivedFlags;

		private const int MaxChambers = 16;

		private readonly Stopwatch _totalTimeStopwatch;

		private readonly FullAutoShotsQueue<ShotRequest> _serverQueuedRequests;

		private readonly Queue<float> _clientQueuedShots;

		private readonly FullAutoRateLimiter _clientRateLimiter;

		private ClientPredictedValue<int> _clientChambered;

		private ClientPredictedValue<int> _clientAmmo;

		private ClientPredictedValue<bool> _clientCocked;

		private ClientPredictedValue<bool> _clientBoltLock;

		private int _serverChambered;

		private bool _serverCocked;

		private bool _serverBoltLocked;

		[SerializeField]
		private GunshotDefinition[] _gunshotSounds;

		[SerializeField]
		private AudioClip _dryfireSound;

		[SerializeField]
		private AnimatorConditionalOverride _boltLockOverrideLayers;

		[field: SerializeField]
		public float BaseFireRate { get; private set; }

		[field: SerializeField]
		public float BoltTravelTime { get; private set; }

		[field: SerializeField]
		public bool MagLocksBolt { get; private set; }

		[field: SerializeField]
		public bool OpenBolt { get; private set; }

		[field: Range(1f, 16f)]
		[field: SerializeField]
		public int ChamberSize { get; private set; }

		public bool Cocked
		{
			get
			{
				return false;
			}
			private set
			{
			}
		}

		public bool BoltLocked
		{
			get
			{
				return false;
			}
			private set
			{
			}
		}

		public int AmmoStored
		{
			get
			{
				return 0;
			}
			private set
			{
			}
		}

		public bool IsBusy => false;

		public float DisplayCyclicRate => 0f;

		public int AmmoMax => 0;

		public DisplayAmmoValues PredictedDisplayAmmo => default(DisplayAmmoValues);

		public bool InspectionAllowed => false;

		public bool IsLoaded => false;

		private float TimeBetweenShots => 0f;

		private float CurTime => 0f;

		private SyncDataFlags CurSyncFlags => default(SyncDataFlags);

		private int SyncAmmoChambered => 0;

		private bool SyncBoltLocked => false;

		private bool SyncCocked => false;

		private bool MagInserted => false;

		private IPrimaryAmmoContainerModule PrimaryAmmoContainer => null;

		public static event Action<ushort> OnSyncDataReceived
		{
			[CompilerGenerated]
			add
			{
			}
			[CompilerGenerated]
			remove
			{
			}
		}

		public static void DecodeSyncFlags(ushort serial, out int ammoChambered, out bool boltLocked, out bool cocked)
		{
			ammoChambered = default(int);
			boltLocked = default(bool);
			cocked = default(bool);
		}

		[ExposedFirearmEvent]
		public void ServerCycleAction()
		{
		}

		[ExposedFirearmEvent]
		public void ServerUnloadChambered()
		{
		}

		public void ServerLockBolt()
		{
		}

		public override void ServerProcessCmd(NetworkReader reader)
		{
		}

		public override void ClientProcessRpcInstance(NetworkReader reader)
		{
		}

		public override void ClientProcessRpcTemplate(NetworkReader reader, ushort serial)
		{
		}

		internal override void OnClientReady()
		{
		}

		protected override void OnInit()
		{
		}

		internal override void OnAdded()
		{
		}

		internal override void OnHolstered()
		{
		}

		internal override void EquipUpdate()
		{
		}

		internal override void ServerOnPlayerConnected(ReferenceHub hub, bool firstModule)
		{
		}

		private void ProcessInput()
		{
		}

		private void ProcessClientShots()
		{
		}

		private void UpdateServer()
		{
		}

		private void ServerSendResponse(ShotRequest request)
		{
		}

		private void ServerShoot(ReferenceHub primaryTarget)
		{
		}

		private void ServerResync()
		{
		}

		private void PlayDryFire()
		{
		}

		private void PlayFire(int chambersFired)
		{
		}

		private void PlayFireAnims(bool dryFire)
		{
		}

		public int GetAmmoStoredForSerial(ushort serial)
		{
			return 0;
		}

		public DisplayAmmoValues GetDisplayAmmoForSerial(ushort serial)
		{
			return default(DisplayAmmoValues);
		}
	}
}
