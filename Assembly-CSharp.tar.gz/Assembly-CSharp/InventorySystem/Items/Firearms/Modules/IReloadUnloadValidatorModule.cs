using System;

namespace InventorySystem.Items.Firearms.Modules
{
	public interface IReloadUnloadValidatorModule
	{
		public enum Authorization
		{
			Idle = 0,
			Allowed = 1,
			Vetoed = 2
		}

		Authorization ReloadAuthorization { get; }

		Authorization UnloadAuthorization { get; }

		static bool ValidateReload(Firearm firearm)
		{
			return false;
		}

		static bool ValidateUnload(Firearm firearm)
		{
			return false;
		}

		private static bool ValidateAny(Firearm firearm, Func<IReloadUnloadValidatorModule, Authorization> authorizationFetcher)
		{
			return false;
		}
	}
}
