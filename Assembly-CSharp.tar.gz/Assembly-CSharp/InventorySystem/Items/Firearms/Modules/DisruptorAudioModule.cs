using System;
using System.Collections.Generic;
using AudioPooling;
using InventorySystem.Items.Autosync;
using PlayerRoles;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules
{
	public class DisruptorAudioModule : AudioModule
	{
		private readonly struct TrackedSource
		{
			public readonly AudioPoolSession Session;

			public readonly ushort Serial;

			public TrackedSource(PooledAudioSource src, ushort serial)
			{
				Session = default(AudioPoolSession);
				Serial = 0;
			}
		}

		[Serializable]
		public struct FiringModeAudio
		{
			public const int TotalClips = 4;

			public AudioClip ClipActionNormal;

			public AudioClip ClipActionLast;

			public AudioClip ClipFiringNormal;

			public AudioClip ClipFiringLast;

			public readonly void Cache(int startIndex)
			{
			}

			public readonly void Play(AudioModule audioModule, bool last)
			{
			}
		}

		private static readonly Queue<TrackedSource> TrackedSources;

		private static AudioClip[] _allClipsGlobalCache;

		private ItemType _disruptorType;

		[SerializeField]
		private FiringModeAudio _singleShotAudio;

		[SerializeField]
		private FiringModeAudio _rapidFireAudio;

		private AudioClip[] AllClips => null;

		private void ProcessSound(ItemIdentifier id, PlayerRoleBase role, PooledAudioSource newSource)
		{
		}

		private void TrackOwner(TrackedSource trackedSource)
		{
		}

		protected override void OnInit()
		{
		}

		internal override void OnTemplateReloaded(ModularAutosyncItem template, bool wasEverLoaded)
		{
		}

		internal override void TemplateUpdate()
		{
		}

		public void PlayDisruptorShot(bool single, bool last)
		{
		}
	}
}
