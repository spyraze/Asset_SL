using System;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules
{
	public class MultiBarrelHitscan : HitscanHitregModuleBase
	{
		[Serializable]
		private struct BarrelOffset
		{
			public float RightPosition;

			public float TopPosition;

			public float RightDirection;

			public float TopDirection;
		}

		private Ray? _lastRay;

		[SerializeField]
		private BarrelOffset[] _barrels;

		internal override void EquipUpdate()
		{
		}

		protected override void Fire()
		{
		}

		private void ShootOffset(BarrelOffset offset, out float dmgDealt)
		{
			dmgDealt = default(float);
		}
	}
}
