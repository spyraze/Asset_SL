using InventorySystem.Items.Firearms.Modules.Misc;
using Mirror;

namespace InventorySystem.Items.Firearms.Modules
{
	public class RevolverRouletteModule : ModuleBase, IBusyIndicatorModule, IAdsPreventerModule
	{
		private readonly ClientRequestTimer _requestTimer;

		private CylinderAmmoModule _cylinderModule;

		private DoubleActionModule _doubleActionModule;

		private float _keyHoldTime;

		private bool _busy;

		public bool IsBusy => false;

		public bool AdsAllowed => false;

		protected override void OnInit()
		{
		}

		internal override void OnHolstered()
		{
		}

		internal override void EquipUpdate()
		{
		}

		public override void ServerProcessCmd(NetworkReader reader)
		{
		}

		public override void ClientProcessRpcInstance(NetworkReader reader)
		{
		}

		[ExposedFirearmEvent]
		public void ServerRandomize()
		{
		}

		[ExposedFirearmEvent]
		public void EndSpin()
		{
		}
	}
}
