using System.Collections.Generic;
using InventorySystem.Items.Firearms.Modules.Misc;
using Mirror;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules
{
	public class EventBasedEquipperModule : ModuleBase, IEquipperModule, IBusyIndicatorModule
	{
		private enum RpcType
		{
			SeedSync = 0,
			FirstTimeTrue = 1,
			FirstTimeFalse = 2,
			ResyncAllFirstTime = 3
		}

		private static readonly HashSet<ushort> ClientAlreadyEquippedSerials;

		private static readonly HashSet<ushort> SyncFirstEquips;

		private static readonly Dictionary<ushort, ushort> NextSeeds;

		[field: SerializeField]
		public float DisplayBaseEquipTime { get; private set; }

		[field: SerializeField]
		public bool RandomizeOnEquip { get; private set; }

		public bool IsBusy => false;

		public bool IsEquipped { get; private set; }

		public override bool AllowCmdsWhileHolstered => false;

		internal override void OnEquipped()
		{
		}

		internal override void SpectatorInit()
		{
		}

		internal override void OnAdded()
		{
		}

		internal override void OnHolstered()
		{
		}

		internal override void OnClientReady()
		{
		}

		internal override void ServerOnPlayerConnected(ReferenceHub hub, bool firstModule)
		{
		}

		public override void ServerProcessCmd(NetworkReader reader)
		{
		}

		public override void ClientProcessRpcTemplate(NetworkReader reader, ushort serial)
		{
		}

		private void ServerUpdateSeed()
		{
		}

		private void Randomize()
		{
		}

		private void ApplyFirstTimeAnims()
		{
		}

		[ExposedFirearmEvent]
		public void Equip()
		{
		}
	}
}
