using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using InventorySystem.Items.Firearms.Modules.Misc;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules
{
	public class EventManagerModule : ModuleBase
	{
		private class AnimatorEventProcessor
		{
			private readonly int[] _layers;

			private readonly Animator _animator;

			private readonly LayerEventProcessor[] _currentLayers;

			private readonly LayerEventProcessor[] _nextLayers;

			private readonly Dictionary<int, float>[] _continuationTimes;

			private readonly EventManagerModule _eventManager;

			public AnimatorEventProcessor(EventManagerModule eventManager, Animator animator)
			{
			}

			public void ProcessAll()
			{
			}
		}

		private class LayerEventProcessor
		{
			private readonly EventManagerModule _eventManager;

			private readonly bool _isCurrent;

			private readonly Animator _anim;

			private readonly int _layerIndex;

			private List<int> _prevEvents;

			private int _curHash;

			private float _lastFrame;

			private bool _hasEvents;

			public LayerEventProcessor(EventManagerModule eventManager, bool isCurrent, int layerIndex, Animator anim)
			{
			}

			public void Process(AnimatorStateInfo stateInfo, Dictionary<int, float> continuationTimes)
			{
			}
		}

		private static readonly Dictionary<ItemType, Dictionary<int, List<int>>> FirearmsToNameHashesToIndexes;

		public List<FirearmEvent> Events;

		public AnimatorLayerMask AffectedLayers;

		private Dictionary<int, List<int>> _nameHashesToIndexes;

		private AnimatorEventProcessor _serverProcessor;

		private AnimatorEventProcessor _viewmodelProcessor;

		public bool SkippingForward { get; private set; }

		public event Action<int> OnEventRelayed
		{
			[CompilerGenerated]
			add
			{
			}
			[CompilerGenerated]
			remove
			{
			}
		}

		public void AddEventsForClip(int hash, List<FirearmEvent> list)
		{
		}

		[ExposedFirearmEvent]
		public void RelayEvent(int guid)
		{
		}

		internal override void OnAdded()
		{
		}

		internal override void SpectatorInit()
		{
		}

		private void CacheIndexes()
		{
		}

		private void InitServer()
		{
		}

		private void InitViewmodel()
		{
		}

		private void LateUpdate()
		{
		}

		[ContextMenu("Clear event cache")]
		private void ClearCache()
		{
		}
	}
}
