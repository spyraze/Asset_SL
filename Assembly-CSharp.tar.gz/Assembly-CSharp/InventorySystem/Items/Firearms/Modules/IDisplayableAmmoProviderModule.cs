namespace InventorySystem.Items.Firearms.Modules
{
	public interface IDisplayableAmmoProviderModule
	{
		DisplayAmmoValues PredictedDisplayAmmo { get; }

		DisplayAmmoValues GetDisplayAmmoForSerial(ushort serial);

		static DisplayAmmoValues GetCombinedDisplayAmmo(Firearm firearm)
		{
			return default(DisplayAmmoValues);
		}

		static DisplayAmmoValues GetCombinedDisplayAmmo(ItemIdentifier id)
		{
			return default(DisplayAmmoValues);
		}
	}
}
