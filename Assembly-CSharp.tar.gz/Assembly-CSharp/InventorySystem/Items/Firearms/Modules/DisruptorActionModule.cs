using System.Collections.Generic;
using InventorySystem.Items.Firearms.Modules.Misc;
using InventorySystem.Items.Pickups;
using Mirror;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules
{
	public class DisruptorActionModule : ModuleBase, IReloaderModule, IActionModule, IBusyIndicatorModule
	{
		private enum MessageType
		{
			RpcRequireReloadTrue = 0,
			RpcRequireReloadFalse = 1,
			RpcRequireReloadFullResync = 2,
			RpcStartFiring = 3,
			RpcOnShot = 4,
			CmdRequestStartFiring = 5,
			CmdConfirmDischarge = 6
		}

		public enum FiringState
		{
			None = 0,
			FiringRapid = 1,
			FiringSingle = 2
		}

		private const float ShotTicketTimeout = 0.07f;

		private static readonly int FireSingleNormalHash;

		private static readonly int FireSingleLastHash;

		private static readonly int FireRapidNormalHash;

		private static readonly int FireRapidLastHash;

		private static readonly HashSet<ushort> ReloadRequiredSerials;

		private readonly FullAutoShotsQueue<ShotBacktrackData> _receivedShots;

		private readonly Queue<double> _shotTickets;

		private MagazineModule _magModule;

		private DisruptorModeSelector _modeSelector;

		private DisruptorAudioModule _audioModule;

		private FiringState _curFiringState;

		private FiringState _lastActiveFiringState;

		private float _firingElapsed;

		[SerializeField]
		private float[] _singleShotTimes;

		[SerializeField]
		private float[] _rapidShotTimes;

		public FiringState CurFiringState
		{
			get
			{
				return default(FiringState);
			}
			private set
			{
			}
		}

		public bool IsFiring => false;

		public bool IsReloading => false;

		public bool IsUnloading => false;

		public bool IsLoaded => false;

		public bool IsBusy => false;

		[field: SerializeField]
		public float DisplayCyclicRate { get; private set; }

		[ExposedFirearmEvent]
		public void EndShootingAnimation()
		{
		}

		[ExposedFirearmEvent]
		public void FinishReloading()
		{
		}

		public bool GetDisplayReloadingOrUnloading(ushort serial)
		{
			return false;
		}

		public override void ClientProcessRpcTemplate(NetworkReader reader, ushort serial)
		{
		}

		public override void ClientProcessRpcInstance(NetworkReader reader)
		{
		}

		public override void ServerProcessCmd(NetworkReader reader)
		{
		}

		protected override void OnInit()
		{
		}

		internal override void EquipUpdate()
		{
		}

		internal override void OnClientReady()
		{
		}

		internal override void ServerOnPlayerConnected(ReferenceHub hub, bool firstModule)
		{
		}

		internal override void OnRemoved(ItemPickupBase pickupBase)
		{
		}

		private void UpdateAction()
		{
		}

		private bool TryGetCurStateTimes(out float[] times)
		{
			times = null;
			return false;
		}

		private void TriggerFire()
		{
		}

		private void ServerUpdateShotRequests()
		{
		}

		private void ServerProcessStartCmd(bool ads)
		{
		}

		private void ServerFire(ReferenceHub primaryTarget)
		{
		}

		private void ClientUpdate()
		{
		}

		private void StartFiring(bool singleMode, bool last)
		{
		}
	}
}
