using System.Collections.Generic;
using InventorySystem.Items.Autosync;
using InventorySystem.Items.Firearms.Modules.Misc;
using Mirror;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules
{
	public abstract class AnimatorReloaderModuleBase : ModuleBase, IReloaderModule, IBusyIndicatorModule
	{
		private class LastRpcInfo
		{
			public ReloaderMessageHeader Header;

			public double NetTime;
		}

		protected enum ReloaderMessageHeader : byte
		{
			Reload = 0,
			Unload = 1,
			Stop = 2,
			RequestRejected = 3,
			Custom = 4
		}

		public const float UnloadHoldTime = 1f;

		[SerializeField]
		private bool _randomize;

		private int? _targetLayer;

		private float _keyHoldTime;

		private bool _isHoldingKey;

		private readonly ClientRequestTimer _requestTimer;

		private static readonly Dictionary<ushort, LastRpcInfo> LastReceivedRpcs;

		public virtual bool IsBusy => false;

		public bool IsReloading { get; protected set; }

		public bool IsUnloading { get; protected set; }

		[ExposedFirearmEvent]
		public void StopReloadingAndUnloading()
		{
		}

		public bool GetDisplayReloadingOrUnloading(ushort serial)
		{
			return false;
		}

		public override void ServerProcessCmd(NetworkReader reader)
		{
		}

		public override void ClientProcessRpcInstance(NetworkReader reader)
		{
		}

		public override void ClientProcessRpcTemplate(NetworkReader reader, ushort serial)
		{
		}

		internal override void OnClientReady()
		{
		}

		internal override void EquipUpdate()
		{
		}

		internal override void OnHolstered()
		{
		}

		protected abstract void StartReloading();

		protected abstract void StartUnloading();

		protected virtual void OnStopReloadingAndUnloading()
		{
		}

		protected virtual void Randomize(byte randomByte)
		{
		}

		protected virtual MessageInterceptionResult InterceptMessage(NetworkReader reader, ushort serial, ReloaderMessageHeader header, AutosyncMessageType scenario)
		{
			return default(MessageInterceptionResult);
		}

		protected virtual void ClientOnRequestSent()
		{
		}

		protected virtual void OnAnimEndDetected()
		{
		}

		private bool TryContinueDeserialization(NetworkReader reader, ushort serial, ReloaderMessageHeader header, AutosyncMessageType scenario)
		{
			return false;
		}

		private void ClientTryReload()
		{
		}

		private void ClientTryUnload()
		{
		}

		private void DetectEnd()
		{
		}
	}
}
