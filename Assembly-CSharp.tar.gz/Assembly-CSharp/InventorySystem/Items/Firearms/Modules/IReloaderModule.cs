namespace InventorySystem.Items.Firearms.Modules
{
	[UniqueModule]
	public interface IReloaderModule
	{
		bool IsReloading { get; }

		bool IsUnloading { get; }

		bool IsReloadingOrUnloading => false;

		bool GetDisplayReloadingOrUnloading(ushort serial);
	}
}
