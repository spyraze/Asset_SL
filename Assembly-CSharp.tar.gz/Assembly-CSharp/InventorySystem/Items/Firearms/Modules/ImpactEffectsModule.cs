using System;
using Decals;
using InventorySystem.Items.Firearms.Attachments;
using InventorySystem.Items.Firearms.Attachments.Components;
using InventorySystem.Items.Firearms.Modules.Misc;
using Mirror;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules
{
	public class ImpactEffectsModule : ModuleBase
	{
		private enum RpcType
		{
			ImpactDecal = 0,
			TracerDefault = 1,
			TracerOverride = 2,
			PlayerHit = 3
		}

		[Serializable]
		public class ImpactEffectsSettings
		{
			private bool? _disableTracers;

			public DecalPoolType BulletholeDecal;

			public DecalPoolType GlassCrackDecal;

			public bool DisableBleeding;

			public TracerBase TracerPrefab;

			public bool DisableTracers => false;
		}

		[Serializable]
		public class ImpactEffectsAttachmentOverride
		{
			private Attachment _attInstance;

			private bool _attSet;

			[field: SerializeField]
			public AttachmentLink Attachment { get; private set; }

			[field: SerializeField]
			public ImpactEffectsSettings Settings { get; private set; }

			public bool GetEnabled(Firearm firearm)
			{
				return false;
			}
		}

		private static readonly CachedLayerMask ReceivingLayers;

		private const float TracerServerHeightOffset = 0.6f;

		private const float ClientSurfaceSeekerRange = 8f;

		private const int GlassLayer = 14;

		[field: SerializeField]
		public ImpactEffectsSettings BaseSettings { get; private set; }

		[field: SerializeField]
		public ImpactEffectsAttachmentOverride[] AttachmentOverrides { get; private set; }

		public override void ClientProcessRpcTemplate(NetworkReader reader, ushort serial)
		{
		}

		public void ServerProcessHit(RaycastHit hit, Vector3 origin, bool anyDamageDealt)
		{
		}

		private void ServerSendTracer(RaycastHit hit, Vector3 origin, int? overrideId, TracerBase tracerPrefab)
		{
		}

		private void ClientReadTracer(NetworkReader reader, ushort serial, int? overrideId)
		{
		}

		private void ServerSendImpactDecal(RaycastHit hit, Vector3 origin, DecalPoolType decalType)
		{
		}

		private void ClientReadImpactDecal(NetworkReader reader)
		{
		}

		private void ServerSendPlayerHit(RaycastHit hit, Vector3 origin, HitboxIdentity hitbox)
		{
		}

		private void ClientReadPlayerHit(NetworkReader reader)
		{
		}

		private void ClientSpawnDecal(Vector3 raycastOrigin, Vector3 raycastDirection, DecalPoolType decalType)
		{
		}

		private ImpactEffectsSettings GetSettings(int? overrideId)
		{
			return null;
		}
	}
}
