namespace InventorySystem.Items.Firearms.Modules
{
	public interface IBusyIndicatorModule
	{
		bool IsBusy { get; }
	}
}
