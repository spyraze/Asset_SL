namespace InventorySystem.Items.Firearms.Modules
{
	public interface IRecoilScalingModule
	{
		float RecoilMultiplier { get; }
	}
}
