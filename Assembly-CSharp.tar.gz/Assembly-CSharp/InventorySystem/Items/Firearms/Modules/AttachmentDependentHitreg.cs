using System;
using System.Runtime.CompilerServices;
using InventorySystem.Crosshairs;
using InventorySystem.Items.Firearms.Attachments.Components;
using InventorySystem.Items.Firearms.ShotEvents;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules
{
	public class AttachmentDependentHitreg : ModuleBase, IHitregModule, ICustomCrosshairItem, IDisplayableInaccuracyProviderModule, IInaccuracyProviderModule
	{
		[Serializable]
		private class AttachmentOverride
		{
			[SerializeField]
			private Attachment _attachment;

			[SerializeField]
			private ModuleBase _module;

			public IHitregModule Hitreg { get; private set; }

			public bool IsEnabled => false;

			public void Init()
			{
			}
		}

		[SerializeField]
		private ModuleBase _primaryHitreg;

		[SerializeField]
		private AttachmentOverride[] _overrideHitregs;

		private bool _targetCacheSet;

		private IHitregModule _cachedTargetModule;

		public float DisplayDamage => 0f;

		public float DisplayPenetration => 0f;

		public Type CrosshairType => null;

		public DisplayInaccuracyValues DisplayInaccuracy => default(DisplayInaccuracyValues);

		public float Inaccuracy => 0f;

		private IHitregModule TargetModule => null;

		public event Action ServerOnFired
		{
			[CompilerGenerated]
			add
			{
			}
			[CompilerGenerated]
			remove
			{
			}
		}

		public void Fire(ReferenceHub primaryTarget, ShotEvent shotData)
		{
		}

		protected override void OnInit()
		{
		}

		internal override void OnAttachmentsApplied()
		{
		}
	}
}
