using System;
using System.Collections.Generic;
using InventorySystem.Items.Firearms.Modules.Misc;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules
{
	public class BuckshotHitreg : HitscanHitregModuleBase
	{
		private readonly Dictionary<IDestructible, int> _hitCounter;

		[field: SerializeField]
		public BuckshotSettings BasePattern { get; private set; }

		public override Type CrosshairType => null;

		public float BuckshotScale => 0f;

		public override bool UseHitboxMultipliers => false;

		private BuckshotSettings ActivePattern => default(BuckshotSettings);

		protected override void Fire()
		{
		}

		protected override float DamageAtDistance(float dist)
		{
			return 0f;
		}

		protected override float ServerProcessTargetHit(IDestructible dest, RaycastHit hitInfo)
		{
			return 0f;
		}

		private Vector3 GetPelletDirection(Vector2 pelletVector, float scale, float randomness, Vector3 fwdDirection)
		{
			return default(Vector3);
		}
	}
}
