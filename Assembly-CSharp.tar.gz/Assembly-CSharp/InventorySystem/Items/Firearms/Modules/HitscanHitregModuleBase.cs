using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using InventorySystem.Crosshairs;
using InventorySystem.Items.Firearms.ShotEvents;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules
{
	public abstract class HitscanHitregModuleBase : ModuleBase, IHitregModule, ICustomCrosshairItem, IDisplayableInaccuracyProviderModule, IInaccuracyProviderModule
	{
		public static readonly CachedLayerMask HitregMask;

		protected readonly HashSet<IDestructible> ServerLastDamagedTargets;

		[field: SerializeField]
		public virtual float BaseDamage { get; protected set; }

		[field: Range(0f, 1f)]
		[field: SerializeField]
		public virtual float BasePenetration { get; protected set; }

		[field: SerializeField]
		public virtual float FullDamageDistance { get; protected set; }

		[field: SerializeField]
		public virtual float DamageFalloffDistance { get; protected set; }

		[field: SerializeField]
		public float BaseBulletInaccuracy { get; private set; }

		public virtual float DisplayDamage => 0f;

		public virtual float DisplayPenetration => 0f;

		public virtual float HitmarkerSize => 0f;

		public virtual bool UseHitboxMultipliers => false;

		public virtual Type CrosshairType => null;

		public virtual float Inaccuracy => 0f;

		public virtual DisplayInaccuracyValues DisplayInaccuracy => default(DisplayInaccuracyValues);

		protected ReferenceHub PrimaryTarget { get; private set; }

		protected ShotEvent LastShotEvent { get; private set; }

		protected Ray ForwardRay => default(Ray);

		protected float CurrentInaccuracy => 0f;

		private ReferenceHub Owner => null;

		private float EffectiveDamage => 0f;

		private float EffectivePenetration => 0f;

		public event Action ServerOnFired
		{
			[CompilerGenerated]
			add
			{
			}
			[CompilerGenerated]
			remove
			{
			}
		}

		public void Fire(ReferenceHub primaryTarget, ShotEvent shotEvent)
		{
		}

		protected abstract void Fire();

		protected Ray RandomizeRay(Ray ray, float angle)
		{
			return default(Ray);
		}

		protected virtual float DamageAtDistance(float dist)
		{
			return 0f;
		}

		protected void SendDamageIndicator(ReferenceHub receiver, float dmgDealt)
		{
		}

		protected void SendDamageIndicator(ReferenceHub receiver, float dmgDealt, Vector3 position)
		{
		}

		protected bool ServerPerformHitscan(Ray targetRay, out float targetDamage)
		{
			targetDamage = default(float);
			return false;
		}

		protected virtual float ServerProcessObstacleHit(RaycastHit hitInfo)
		{
			return 0f;
		}

		protected virtual float ServerProcessTargetHit(IDestructible dest, RaycastHit hitInfo)
		{
			return 0f;
		}

		protected virtual void SendHitmarker(float damageDealt)
		{
		}

		protected virtual bool ValidateTarget(IDestructible target)
		{
			return false;
		}

		protected void EnableSelfDamageProtection()
		{
		}

		protected void RestoreHitboxes()
		{
		}

		private void SetHitboxes(bool restore)
		{
		}

		private static void ToggleColliders(ReferenceHub target, bool state)
		{
		}
	}
}
