using System.Collections.Generic;
using InventorySystem.Items.Firearms.Attachments;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules
{
	public class MovementInaccuracyModule : ModuleBase, IDisplayableInaccuracyProviderModule, IInaccuracyProviderModule
	{
		public readonly struct MovementInaccuracyDefinition
		{
			public readonly Firearm Template;

			private readonly float _minInaccuracy;

			private readonly float _maxInaccuracy;

			private readonly float _lightest;

			private readonly float _shortest;

			private readonly float _heaviest;

			private readonly float _longest;

			public MovementInaccuracyDefinition(Firearm template, float minInaccuracy, float maxInaccuracy)
			{
				Template = null;
				_minInaccuracy = 0f;
				_maxInaccuracy = 0f;
				_lightest = 0f;
				_shortest = 0f;
				_heaviest = 0f;
				_longest = 0f;
			}

			public float Evaluate(Firearm firearm)
			{
				return 0f;
			}

			private static void GetFirearmRamapValues(Firearm firearm, out float lightest, out float shortest, out float heaviest, out float longest)
			{
				lightest = default(float);
				shortest = default(float);
				heaviest = default(float);
				longest = default(float);
			}

			private static bool TryGetSlotRamapValues(Firearm firearm, AttachmentSlot slot, out float lightest, out float shortest, out float heaviest, out float longest)
			{
				lightest = default(float);
				shortest = default(float);
				heaviest = default(float);
				longest = default(float);
				return false;
			}
		}

		private static readonly Dictionary<ItemType, MovementInaccuracyDefinition> CachedDefinitions;

		private const float JumpingPenalty = 3f;

		[field: SerializeField]
		public float MinPenalty { get; private set; }

		[field: SerializeField]
		public float MaxPenalty { get; private set; }

		public DisplayInaccuracyValues DisplayInaccuracy => default(DisplayInaccuracyValues);

		public float Inaccuracy => 0f;

		private float TargetRunningInaccuracy => 0f;

		[ContextMenu("Clear Cache")]
		private void ClearCache()
		{
		}
	}
}
