using InventorySystem.Items.Firearms.Modules.Misc;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules
{
	public class DisruptorAdsModule : LinearAdsModule, ILightEmittingItem
	{
		private const float NightVisionThreshold = 0.6f;

		private DisruptorActionModule _disruptorAction;

		private bool _preventAds;

		[SerializeField]
		private float _zoomAmount;

		[SerializeField]
		private float _sensitivtyScale;

		[SerializeField]
		private float _inaccuracyScale;

		protected override bool AllowAds => false;

		public override float BaseZoomAmount => 0f;

		public override float AdditionalSensitivityModifier => 0f;

		public override float BaseAdsInaccuracy => 0f;

		public override float BaseHipInaccuracy => 0f;

		public bool IsEmittingLight => false;

		protected override void OnInit()
		{
		}

		[ExposedFirearmEvent]
		public void ForceExitAds()
		{
		}
	}
}
