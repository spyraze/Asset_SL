using System.Collections.Generic;
using System.Diagnostics;
using Mirror;
using PlayerRoles;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules
{
	public class AnimatorSpectatorSyncModule : ModuleBase, ISpectatorSyncModule
	{
		private class SyncAnimData
		{
			public Stopwatch LastReceived;

			public AnimLayerSnapshot[] Snapshots;

			public SyncAnimData(int layers)
			{
			}
		}

		private class AnimLayerSnapshot
		{
			public int TagHash;

			public float NormalizedTime;

			public bool Loop;
		}

		private const int MaxUpdatesPerFrame = 3;

		private static readonly Dictionary<ushort, SyncAnimData> ReceivedData;

		private static readonly Queue<AnimatorSpectatorSyncModule> UpdateQueue;

		private bool _enqueued;

		private AnimLayerSnapshot[] _lastSnapshots;

		[SerializeField]
		[HideInInspector]
		private int[] _layers;

		public void SetupViewmodel(AnimatedFirearmViewmodel viewmodel, float defaultSkipTime)
		{
		}

		public override void ClientProcessRpcTemplate(NetworkReader reader, ushort serial)
		{
		}

		internal override void OnEquipped()
		{
		}

		protected override void OnInit()
		{
		}

		internal override void OnClientReady()
		{
		}

		public override void OnFirearmValidate(Firearm fa)
		{
		}

		private void ServerUpdateInstance()
		{
		}

		private void ServerWriteAnimator(NetworkWriter writer)
		{
		}

		[RuntimeInitializeOnLoadMethod]
		private static void InitOnLoad()
		{
		}

		private static void OnServerRoleSet(ReferenceHub userHub, RoleTypeId newRole, RoleChangeReason reason)
		{
		}

		private static void UpdateInstances()
		{
		}
	}
}
