namespace InventorySystem.Items.Firearms.Modules
{
	public interface ITriggerPressPreventerModule
	{
		bool ClientBlockTrigger { get; }
	}
}
