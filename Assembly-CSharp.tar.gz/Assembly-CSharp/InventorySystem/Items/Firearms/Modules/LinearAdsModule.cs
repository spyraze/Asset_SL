using System.Collections.Generic;
using System.Diagnostics;
using Mirror;
using PlayerRoles.FirstPersonControl;
using UserSettings;

namespace InventorySystem.Items.Firearms.Modules
{
	public class LinearAdsModule : ModuleBase, IAdsModule, IDisplayableInaccuracyProviderModule, IInaccuracyProviderModule, IZoomModifyingItem, IInspectPreventerModule, IMovementSpeedModifier, IStaminaModifier, ISwayModifierModule
	{
		private class AdsData
		{
			private float _adjustSpeed;

			private float _lastOffset;

			private readonly Stopwatch _lastUpdate;

			public bool AdsTarget { get; private set; }

			public float AdsAmount => 0f;

			public void Update(bool target, float speed, out bool targetChanged, out bool speedChanged)
			{
				targetChanged = default(bool);
				speedChanged = default(bool);
			}

			public void DecodeData(NetworkReader reader)
			{
			}

			public void Reset()
			{
			}
		}

		private const float FallbackAdsZoom = 1.15f;

		private const float FallbackAdsInaccuracy = 0.17f;

		private const float FallbackHipInaccuracy = 2f;

		private const float FallbackTimeToTransition = 0.2f;

		private const float TransitioningPenaltyDegrees = 3f;

		private const float AdsJumpSwayMultiplier = 0.3f;

		private static readonly Remap MovementLimitRemap;

		private static readonly Dictionary<FirearmCategory, float> HipInaccuracyByCategory;

		private static readonly Dictionary<FirearmCategory, float> AdsInaccuracyByCategory;

		private static readonly Dictionary<FirearmCategory, float> TimeToTransitionByCategory;

		private static readonly ToggleOrHoldInput AdsInput;

		private static readonly Dictionary<ushort, AdsData> SyncData;

		private bool _userInput;

		private bool _hasZoomOptions;

		private readonly AdsData _clientData;

		private float EffectiveHipInaccuracy => 0f;

		private float EffectiveAdsInaccuracy => 0f;

		protected virtual bool AllowAds => false;

		protected virtual bool ForceAdsInput => false;

		public DisplayInaccuracyValues DisplayInaccuracy => default(DisplayInaccuracyValues);

		public bool AdsTarget => false;

		public float AdsAmount => 0f;

		public float Inaccuracy => 0f;

		public bool InspectionAllowed => false;

		public virtual float BaseHipInaccuracy => 0f;

		public virtual float BaseAdsInaccuracy => 0f;

		public virtual float BaseTimeToTransition => 0f;

		public virtual float BaseZoomAmount => 0f;

		public virtual float ZoomAmount => 0f;

		public virtual float AdditionalSensitivityModifier => 0f;

		public virtual float SensitivityScale => 0f;

		public bool IsTransitioning => false;

		public bool MovementModifierActive => false;

		public float MovementSpeedMultiplier => 0f;

		public float MovementSpeedLimit => 0f;

		public bool StaminaModifierActive => false;

		public bool SprintingDisabled => false;

		public float WalkSwayScale => 0f;

		public float JumpSwayScale => 0f;

		protected virtual void OnAdsChanged(bool newTarget, float newSpeed, bool targetChanged, bool speedChanged)
		{
		}

		internal override void OnClientReady()
		{
		}

		internal override void EquipUpdate()
		{
		}

		protected override void OnInit()
		{
		}

		internal override void OnHolstered()
		{
		}

		public override void ServerProcessCmd(NetworkReader reader)
		{
		}

		public override void ClientProcessRpcTemplate(NetworkReader reader, ushort serial)
		{
		}

		public void GetDisplayAdsValues(ushort serial, out bool adsTarget, out float adsAmount)
		{
			adsTarget = default(bool);
			adsAmount = default(float);
		}

		public static bool GetAdsTargetForSerial(ushort serial)
		{
			return false;
		}

		public static float GetAdsAmountForSerial(ushort serial)
		{
			return 0f;
		}
	}
}
