namespace InventorySystem.Items.Firearms.Modules
{
	public static class ModulesUtils
	{
		public static bool AnyModuleBusy(this Firearm firearm, ModuleBase ignoredModule = null)
		{
			return false;
		}

		public static int GetTotalStoredAmmo(ItemIdentifier id)
		{
			return 0;
		}

		public static int GetTotalStoredAmmo(this Firearm firearm)
		{
			return 0;
		}

		public static int GetTotalMaxAmmo(this Firearm firearm)
		{
			return 0;
		}

		public static void GetAmmoContainerData(this Firearm firearm, out int totalStored, out int totalMax)
		{
			totalStored = default(int);
			totalMax = default(int);
		}

		public static bool TryGetModuleWithId<T>(this Firearm firearm, int id, out T module)
		{
			module = default(T);
			return false;
		}

		public static bool TryGetModule<T>(this Firearm firearm, out T module, bool ignoreSubmodules = true)
		{
			module = default(T);
			return false;
		}

		public static bool TryGetModules<T1, T2>(this Firearm firearm, out T1 m1, out T2 m2)
		{
			m1 = default(T1);
			m2 = default(T2);
			return false;
		}

		public static bool TryGetModules<T1, T2, T3>(this Firearm firearm, out T1 m1, out T2 m2, out T3 m3)
		{
			m1 = default(T1);
			m2 = default(T2);
			m3 = default(T3);
			return false;
		}

		public static bool TryGetModules<T1, T2, T3, T4>(this Firearm firearm, out T1 m1, out T2 m2, out T3 m3, out T4 m4)
		{
			m1 = default(T1);
			m2 = default(T2);
			m3 = default(T3);
			m4 = default(T4);
			return false;
		}

		public static bool TryGetModuleTemplate<T>(ItemType itemType, out T module)
		{
			module = default(T);
			return false;
		}
	}
}
