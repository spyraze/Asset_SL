using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using InventorySystem.Items.Firearms.Modules.Misc;
using InventorySystem.Items.Pickups;
using Mirror;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules
{
	public class CylinderAmmoModule : ModuleBase, IPrimaryAmmoContainerModule, IAmmoContainerModule, IReloadUnloadValidatorModule, IAmmoDropPreventer
	{
		public class Chamber
		{
			private readonly ClientPredictedValue<ChamberState> _predictedState;

			public ChamberState ServerSyncState;

			public ChamberState PredictedState
			{
				get
				{
					return default(ChamberState);
				}
				set
				{
				}
			}

			public ChamberState ContextState
			{
				get
				{
					return default(ChamberState);
				}
				set
				{
				}
			}

			public byte ToByte(int offset)
			{
				return 0;
			}

			public void FromByte(byte b, int offset)
			{
			}
		}

		public enum ChamberState : byte
		{
			Empty = 0,
			Live = 1,
			Discharged = 2
		}

		private static readonly Dictionary<ushort, Chamber[]> ChambersCache;

		private static ChamberState[] _rotationBuffer;

		private const int ChambersPerByte = 4;

		private const int BitsPerChamber = 2;

		[SerializeField]
		private int _defaultCapacity;

		[SerializeField]
		private int _ammoInsertionOffset;

		private int? _lastAmmoMax;

		private bool _needsResyncing;

		[field: SerializeField]
		public ItemType AmmoType { get; private set; }

		public int AmmoMax => 0;

		public int AmmoStored => 0;

		public ReadOnlySpan<Chamber> Chambers => default(ReadOnlySpan<Chamber>);

		public IReloadUnloadValidatorModule.Authorization ReloadAuthorization => default(IReloadUnloadValidatorModule.Authorization);

		public IReloadUnloadValidatorModule.Authorization UnloadAuthorization => default(IReloadUnloadValidatorModule.Authorization);

		private bool AllChambersEmpty => false;

		public static event Action<ushort> OnChambersModified
		{
			[CompilerGenerated]
			add
			{
			}
			[CompilerGenerated]
			remove
			{
			}
		}

		public bool ValidateAmmoDrop(ItemType id)
		{
			return false;
		}

		public void ServerModifyAmmo(int amt)
		{
		}

		public void ModifyAmmo(int amt)
		{
		}

		[ExposedFirearmEvent]
		public void RotateCylinder(int rotations)
		{
		}

		public void ServerResync()
		{
		}

		public void ClientHoldPrediction()
		{
		}

		[ExposedFirearmEvent]
		public void UnloadAllChambers()
		{
		}

		internal override void OnAdded()
		{
		}

		public override void ClientProcessRpcTemplate(NetworkReader reader, ushort serial)
		{
		}

		internal override void EquipUpdate()
		{
		}

		internal override void OnClientReady()
		{
		}

		internal override void OnAttachmentsApplied()
		{
		}

		public int GetAmmoStoredForSerial(ushort serial)
		{
			return 0;
		}

		internal override void OnEquipped()
		{
		}

		internal override void ServerProcessMapgenDistribution(ItemPickupBase pickupBase)
		{
		}

		internal override void ServerOnPlayerConnected(ReferenceHub hub, bool firstModule)
		{
		}

		private void LateUpdate()
		{
		}

		public static Chamber[] GetChambersArrayForSerial(ushort serial, int minLength)
		{
			return null;
		}

		private static void ServerPrepareNewChambers(ushort serial, int ammoLoaded)
		{
		}

		private static void ServerWriteChambers(NetworkWriter writer, Chamber[] chambers)
		{
		}
	}
}
