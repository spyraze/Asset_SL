using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using InventorySystem.Items.Firearms.Modules.Misc;
using InventorySystem.Items.Pickups;
using Mirror;
using Scp914;
using UnityEngine;

namespace InventorySystem.Items.Firearms.Modules
{
	public class MagazineModule : ModuleBase, IReloadUnloadValidatorModule, IMagazineControllerModule, IPrimaryAmmoContainerModule, IAmmoContainerModule, IDisplayableAmmoProviderModule, IAmmoDropPreventer
	{
		private static readonly Dictionary<ushort, int> SyncData;

		[SerializeField]
		private int _defaultCapacity;

		[SerializeField]
		private ItemType _ammoType;

		[SerializeField]
		private AnimatorConditionalOverride _magazineRemovedOverrideLayers;

		public ItemType AmmoType => default(ItemType);

		public IReloadUnloadValidatorModule.Authorization ReloadAuthorization => default(IReloadUnloadValidatorModule.Authorization);

		public IReloadUnloadValidatorModule.Authorization UnloadAuthorization => default(IReloadUnloadValidatorModule.Authorization);

		public int AmmoMax => 0;

		public int AmmoStored
		{
			get
			{
				return 0;
			}
			private set
			{
			}
		}

		public bool MagazineInserted
		{
			get
			{
				return false;
			}
			private set
			{
			}
		}

		public DisplayAmmoValues PredictedDisplayAmmo => default(DisplayAmmoValues);

		private Inventory UserInv => null;

		public static event Action<ushort> OnDataReceived
		{
			[CompilerGenerated]
			add
			{
			}
			[CompilerGenerated]
			remove
			{
			}
		}

		public static bool GetMagazineInserted(ushort serial)
		{
			return false;
		}

		public void ServerSetInstanceAmmo(ushort serial, int amount)
		{
		}

		[ExposedFirearmEvent]
		public void ServerRemoveMagazine()
		{
		}

		[ExposedFirearmEvent]
		public void ServerInsertMagazine()
		{
		}

		[ExposedFirearmEvent]
		public void ServerInsertEmptyMagazine()
		{
		}

		[ExposedFirearmEvent]
		public void ServerLoadAmmoFromInventory(int insertionLimit)
		{
		}

		[ExposedFirearmEvent]
		public void ServerLoadAmmoFromInventory()
		{
		}

		public void ServerResyncData()
		{
		}

		public override void ClientProcessRpcTemplate(NetworkReader reader, ushort serial)
		{
		}

		public void ServerModifyAmmo(int amt)
		{
		}

		public int GetAmmoStoredForSerial(ushort serial)
		{
			return 0;
		}

		public DisplayAmmoValues GetDisplayAmmoForSerial(ushort serial)
		{
			return default(DisplayAmmoValues);
		}

		internal override void ServerOnPlayerConnected(ReferenceHub hub, bool firstModule)
		{
		}

		internal override void EquipUpdate()
		{
		}

		internal override void OnAdded()
		{
		}

		internal override void OnAttachmentsApplied()
		{
		}

		internal override void OnEquipped()
		{
		}

		internal override void ServerProcessMapgenDistribution(ItemPickupBase pickupBase)
		{
		}

		internal override void ServerProcessScp914Creation(ushort serial, Scp914KnobSetting knobSetting, Scp914Result scp914Result, ItemType itemType)
		{
		}

		internal override void OnClientReady()
		{
		}

		public bool ValidateAmmoDrop(ItemType id)
		{
			return false;
		}
	}
}
