namespace InventorySystem.Items.Usables.Scp244
{
	public enum Scp244State : byte
	{
		Idle = 0,
		Active = 1,
		Destroyed = 2,
		PickedUp = 3
	}
}
