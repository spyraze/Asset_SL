using CustomPlayerEffects;

namespace InventorySystem.Items.Usables.Scp244.Hypothermia
{
	public abstract class HypothermiaSubEffectBase : SubEffectBase
	{
		internal virtual void UpdateEffect(float curExposure)
		{
		}
	}
}
