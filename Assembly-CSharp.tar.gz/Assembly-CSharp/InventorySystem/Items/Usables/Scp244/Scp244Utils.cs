using UnityEngine;

namespace InventorySystem.Items.Usables.Scp244
{
	public static class Scp244Utils
	{
		public static bool CheckVisibility(Vector3 observer, Vector3 target)
		{
			return false;
		}

		public static bool IntersectRay(this Scp244DeployablePickup scp244, Vector3 observer, Vector3 target)
		{
			return false;
		}
	}
}
