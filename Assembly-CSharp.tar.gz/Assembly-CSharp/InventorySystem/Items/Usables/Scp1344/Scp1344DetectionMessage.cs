using Mirror;

namespace InventorySystem.Items.Usables.Scp1344
{
	public readonly struct Scp1344DetectionMessage : NetworkMessage
	{
		public readonly uint DetectedNetId;

		public Scp1344DetectionMessage(uint detectedNetId)
		{
			DetectedNetId = 0u;
		}
	}
}
