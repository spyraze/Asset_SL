using InventorySystem.Items.SwayControllers;
using UnityEngine;

namespace InventorySystem.Items.Usables.Scp1344
{
	public class Scp1344Viewmodel : UsableItemViewmodel
	{
		private static readonly FixedSway FixedSway;

		private static readonly int StatusAnimHash;

		private static readonly int InspectAnimHash;

		[SerializeField]
		private AudioClip _wearSound;

		[SerializeField]
		private AudioClip _inspectSound;

		[SerializeField]
		private AudioClip _removeBuildUpSound;

		private AudioSource _audioSource;

		private AudioClip _originalClip;

		private float _originalVolume;

		private Scp1344Status _status;

		public override IItemSwayController SwayController => null;

		public override void InitAny()
		{
		}

		public override void OnUsingStarted()
		{
		}

		protected override void OnDestroy()
		{
		}

		internal override void OnEquipped()
		{
		}

		private void ClientChangeStatus(ushort serial, Scp1344Status status)
		{
		}

		private void Awake()
		{
		}

		private void OnDisable()
		{
		}

		private void PlayClip(AudioClip clip, float volume = 1f)
		{
		}
	}
}
