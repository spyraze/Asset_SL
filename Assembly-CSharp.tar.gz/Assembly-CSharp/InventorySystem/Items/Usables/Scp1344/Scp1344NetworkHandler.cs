using System;
using System.Collections.Generic;
using Mirror;
using UnityEngine;

namespace InventorySystem.Items.Usables.Scp1344
{
	public static class Scp1344NetworkHandler
	{
		private static readonly HashSet<uint> AlreadySyncedJoinNetIds;

		private static readonly Dictionary<ushort, Scp1344Status> ReceivedStatuses;

		public static Action<ushort, Scp1344Status> OnStatusChanged;

		public static Action<ReferenceHub, ReferenceHub> OnPlayerDetected;

		[RuntimeInitializeOnLoadMethod]
		private static void Init()
		{
		}

		public static void ServerSendMessage(Scp1344StatusMessage msg)
		{
		}

		public static Scp1344Status GetSavedStatus(ushort serial)
		{
			return default(Scp1344Status);
		}

		private static void ClientProcessStatusMessage(Scp1344StatusMessage msg)
		{
		}

		private static void ClientProcessDetectionMessage(Scp1344DetectionMessage msg)
		{
		}

		private static void ServerProcessStatusMessage(NetworkConnection conn, Scp1344StatusMessage msg)
		{
		}

		private static void ServerProcessDetectionMessage(NetworkConnection conn, Scp1344DetectionMessage msg)
		{
		}

		private static void TryInspect(ReferenceHub hub)
		{
		}

		private static void SyncAllInstances(NetworkConnection conn)
		{
		}
	}
}
