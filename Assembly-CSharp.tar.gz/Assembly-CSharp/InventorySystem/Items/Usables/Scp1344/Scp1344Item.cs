using CustomPlayerEffects;
using InventorySystem.Drawers;
using InventorySystem.Items.Pickups;
using PlayerStatsSystem;

namespace InventorySystem.Items.Usables.Scp1344
{
	public class Scp1344Item : UsableItem, IWearableItem, IItemProgressbarDrawer, IItemDrawer
	{
		private const ActionName InspectKey = ActionName.InspectItem;

		private const float EquipTime = 1.3f;

		private const float DeactivationTime = 5.1f;

		private const float DeactivationTransitionTime = 0.5f;

		private const float StabTime = 0.065f;

		private const float ActivationTime = 5f;

		private const float ActivationTransitionTime = 1f;

		private const float ActivationItemDeselectionTime = 0.75f;

		private const float InspectionCooldown = 4f;

		private const byte ActivationBlindnessIntensity = 100;

		private const byte LockedBlindnessIntensity = 101;

		private const byte MinBlindnessIntensity = 15;

		private const float BarWidth = 650f;

		private Scp1344Status _status;

		private float _useTime;

		private float _cancelationTime;

		private byte _savedIntensity;

		private double _nextInspectTime;

		public CustomPlayerEffects.Scp1344 Scp1344Effect => null;

		public Blindness BlindnessEffect => null;

		public SeveredEyes SeveredEyesEffect => null;

		public bool IsWorn => false;

		public WearableSlot Slot => default(WearableSlot);

		public override bool CanStartUsing => false;

		public override bool AllowEquip => false;

		public override bool AllowHolster => false;

		public bool AllowInspect => false;

		public bool ProgressbarEnabled => false;

		public float ProgressbarMin => 0f;

		public float ProgressbarMax => 0f;

		public float ProgressbarValue => 0f;

		public float ProgressbarWidth => 0f;

		public Scp1344Status Status
		{
			get
			{
				return default(Scp1344Status);
			}
			set
			{
			}
		}

		public override void ServerOnUsingCompleted()
		{
		}

		public override void OnHolstered()
		{
		}

		public override ItemPickupBase ServerDropItem(bool spawn)
		{
			return null;
		}

		public override void OnEquipped()
		{
		}

		public override void OnUsingStarted()
		{
		}

		public override void EquipUpdate()
		{
		}

		private void OnPlayerDisarmed(ReferenceHub disarmerHub, ReferenceHub targetHub)
		{
		}

		private void OnAnyPlayerDied(ReferenceHub hub, DamageHandlerBase _)
		{
		}

		private void Update()
		{
		}

		private void ServerUpdateTimedStatus(float time, Scp1344Status status)
		{
		}

		private void ServerUpdateActive()
		{
		}

		private void ServerUpdateDeactivating()
		{
		}

		private void ActivateFinalEffects()
		{
		}

		private void Awake()
		{
		}

		private void OnDestroy()
		{
		}

		private void OnStatusChanged(ushort serial, Scp1344Status status)
		{
		}

		private void ServerSetStatus(Scp1344Status status)
		{
		}

		private void ClientChangeStatus(Scp1344Status status)
		{
		}

		private void ServerChangeStatus(Scp1344Status status)
		{
		}
	}
}
