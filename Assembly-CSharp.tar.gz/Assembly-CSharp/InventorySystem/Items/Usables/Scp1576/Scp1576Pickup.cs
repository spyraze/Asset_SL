using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using InventorySystem.Items.Pickups;
using Mirror;
using UnityEngine;

namespace InventorySystem.Items.Usables.Scp1576
{
	public class Scp1576Pickup : CollisionDetectionPickup
	{
		private byte _prevSyncHorn;

		[SyncVar]
		private byte _syncHorn;

		[SerializeField]
		private Transform _horn;

		[SerializeField]
		private Vector3 _posZero;

		[SerializeField]
		private Vector3 _posOne;

		public float HornPos
		{
			get
			{
				return 0f;
			}
			set
			{
			}
		}

		public byte Network_syncHorn
		{
			get
			{
				return 0;
			}
			[param: In]
			set
			{
			}
		}

		public static event Action<ushort, float> OnHornPositionUpdated
		{
			[CompilerGenerated]
			add
			{
			}
			[CompilerGenerated]
			remove
			{
			}
		}

		private void Update()
		{
		}

		public override bool Weaved()
		{
			return false;
		}

		public override void SerializeSyncVars(NetworkWriter writer, bool forceAll)
		{
		}

		public override void DeserializeSyncVars(NetworkReader reader, bool initialState)
		{
		}
	}
}
