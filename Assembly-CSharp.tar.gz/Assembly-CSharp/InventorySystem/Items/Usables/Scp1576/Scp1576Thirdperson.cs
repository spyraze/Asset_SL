using AnimatorLayerManagement;
using UnityEngine;

namespace InventorySystem.Items.Usables.Scp1576
{
	public class Scp1576Thirdperson : VariableGFXUsableItemThirdperson
	{
		[SerializeField]
		private Transform _leftHandIkTarget;

		[SerializeField]
		private LayerRefId _leftHandIkLayer;

		[SerializeField]
		private Pose _leftHandLocalPose;

		[SerializeField]
		private Vector2 _crankingPeriodMinMax;

		[SerializeField]
		private Transform _crankAnchor;

		[SerializeField]
		private Vector3 _crankForward;

		[SerializeField]
		private Vector3 _crankParentUp;

		[SerializeField]
		private float _animEndTime;

		private float _elapsed;

		private Transform _crankTr;

		private Transform _lastInstanceTr;

		private Pose _initialInstPose;

		private Pose _targetInstPose;

		private float _ikBlend;

		private const float IkBlendSpeed = 4f;

		private const float PoseAdjustDuration = 0.2f;

		internal override void OnAnimIK(int layerIndex, float ikScale)
		{
		}

		protected override void SetupLeftHandedInstance(GameObject instance, Transform leftHand)
		{
		}

		protected override void Update()
		{
		}

		private bool Crank()
		{
			return false;
		}

		private void UpdateIdleIK(int layer)
		{
		}

		private void SetIkSmooth(bool targetIsOn)
		{
		}
	}
}
