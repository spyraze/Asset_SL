using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Mirror;
using UnityEngine;

namespace InventorySystem.Items.Usables.Scp330
{
	public static class Scp330NetworkHandler
	{
		public static readonly Dictionary<ushort, CandyKindID> ReceivedSelectedCandies;

		public static event Action<SelectScp330Message> OnClientSelectMessageReceived
		{
			[CompilerGenerated]
			add
			{
			}
			[CompilerGenerated]
			remove
			{
			}
		}

		[RuntimeInitializeOnLoadMethod]
		private static void Init()
		{
		}

		private static void RegisterHandlers()
		{
		}

		private static void ServerSelectMessageReceived(NetworkConnection conn, SelectScp330Message msg)
		{
		}

		private static void ClientSyncMessageReceived(SyncScp330Message msg)
		{
		}

		private static void ClientSelectMessageReceived(SelectScp330Message msg)
		{
		}

		public static void SerializeSyncMessage(this NetworkWriter writer, SyncScp330Message value)
		{
		}

		public static SyncScp330Message DeserializeSyncMessage(this NetworkReader reader)
		{
			return default(SyncScp330Message);
		}

		public static void SerializeSelectMessage(this NetworkWriter writer, SelectScp330Message value)
		{
		}

		public static SelectScp330Message DeserializeSelectMessage(this NetworkReader reader)
		{
			return default(SelectScp330Message);
		}
	}
}
