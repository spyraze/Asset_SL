namespace InventorySystem.Items.Usables.Scp330
{
	public static class Scp330Translations
	{
		public enum Entry
		{
			Candies = 0
		}

		private const int CandiesOffset = 1;

		public static string GetSpecificTranslation(int index, string fallback)
		{
			return null;
		}

		public static string GetEntryTranslation(Entry entry)
		{
			return null;
		}

		public static void GetCandyTranslation(CandyKindID candyKind, out string name, out string desc, out string fx)
		{
			name = null;
			desc = null;
			fx = null;
		}
	}
}
