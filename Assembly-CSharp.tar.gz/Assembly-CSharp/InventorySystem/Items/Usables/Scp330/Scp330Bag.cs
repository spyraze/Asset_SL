using System.Collections.Generic;
using InventorySystem.Items.Pickups;
using InventorySystem.Searching;

namespace InventorySystem.Items.Usables.Scp330
{
	public class Scp330Bag : UsableItem, ICustomSearchCompletorItem, IAcquisitionConfirmationTrigger, IUniqueItem
	{
		public int SelectedCandyId;

		public List<CandyKindID> Candies;

		public const int MaxCandies = 6;

		public override bool CanStartUsing => false;

		public bool AcquisitionAlreadyReceived { get; set; }

		public override ItemDescriptionType DescriptionType => default(ItemDescriptionType);

		public bool IsCandySelected => false;

		public SearchCompletor GetCustomSearchCompletor(ReferenceHub hub, ItemPickupBase ipb, ItemBase ib, double disSqrt)
		{
			return null;
		}

		public override void OnAdded(ItemPickupBase pickup)
		{
		}

		public override void OnRemoved(ItemPickupBase pickup)
		{
		}

		public override void OnEquipped()
		{
		}

		public override void OnHolstered()
		{
		}

		public void ServerConfirmAcqusition()
		{
		}

		public override void ServerOnUsingCompleted()
		{
		}

		public void DropCandy(int index)
		{
		}

		public void SelectCandy(int index)
		{
		}

		public bool TryAddSpecific(CandyKindID kind)
		{
			return false;
		}

		public CandyKindID TryRemove(int index)
		{
			return default(CandyKindID);
		}

		public bool CompareIdentical(ItemBase ib)
		{
			return false;
		}

		public static bool ServerProcessPickup(ReferenceHub ply, Scp330Pickup pickup, out Scp330Bag bag)
		{
			bag = null;
			return false;
		}

		public static bool TryGetBag(ReferenceHub hub, out Scp330Bag bag)
		{
			bag = null;
			return false;
		}

		public static void AddSimpleRegeneration(ReferenceHub hub, float rate, float duration)
		{
		}

		private void SendClientMessage(int candyIdex, bool drop)
		{
		}

		public void ServerRefreshBag()
		{
		}
	}
}
