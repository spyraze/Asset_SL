using System.Collections.Generic;

namespace InventorySystem.Items.Usables.Scp330
{
	public static class Scp330Candies
	{
		public static readonly ICandy[] AllCandies;

		private static bool _dictionarySet;

		private static readonly Dictionary<CandyKindID, ICandy> DictionarizedCandies;

		public static Dictionary<CandyKindID, ICandy> CandiesById => null;

		public static CandyKindID GetRandom(CandyKindID ignoredKind = CandyKindID.None)
		{
			return default(CandyKindID);
		}
	}
}
