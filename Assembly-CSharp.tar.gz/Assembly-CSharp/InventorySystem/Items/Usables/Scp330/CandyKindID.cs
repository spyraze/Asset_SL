namespace InventorySystem.Items.Usables.Scp330
{
	public enum CandyKindID : byte
	{
		None = 0,
		Rainbow = 1,
		Yellow = 2,
		Purple = 3,
		Red = 4,
		Green = 5,
		Blue = 6,
		Pink = 7
	}
}
