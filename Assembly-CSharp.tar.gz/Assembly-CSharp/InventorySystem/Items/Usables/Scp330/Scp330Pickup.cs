using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using InventorySystem.Items.Pickups;
using Mirror;
using UnityEngine;

namespace InventorySystem.Items.Usables.Scp330
{
	public class Scp330Pickup : CollisionDetectionPickup
	{
		[Serializable]
		private struct IndividualCandy
		{
			[SerializeField]
			private CandyKindID _kind;

			[SerializeField]
			private GameObject _candyObject;

			public void Refresh(CandyKindID exposed)
			{
			}
		}

		public List<CandyKindID> StoredCandies;

		[SyncVar]
		public CandyKindID ExposedCandy;

		[SerializeField]
		private IndividualCandy[] _candyTypes;

		private int _prevExposed;

		public CandyKindID NetworkExposedCandy
		{
			get
			{
				return default(CandyKindID);
			}
			[param: In]
			set
			{
			}
		}

		private void Update()
		{
		}

		public override bool Weaved()
		{
			return false;
		}

		public override void SerializeSyncVars(NetworkWriter writer, bool forceAll)
		{
		}

		public override void DeserializeSyncVars(NetworkReader reader, bool initialState)
		{
		}
	}
}
