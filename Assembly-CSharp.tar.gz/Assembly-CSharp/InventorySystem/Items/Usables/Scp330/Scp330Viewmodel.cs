using System;
using CursorManagement;
using InventorySystem.GUI;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace InventorySystem.Items.Usables.Scp330
{
	public class Scp330Viewmodel : UsableItemViewmodel, ICursorOverride
	{
		[Serializable]
		private struct CandyObject
		{
			public CandyKindID KindID;

			public GameObject HandObject;

			public Texture Icon;

			public AudioClip EatingSound;
		}

		[SerializeField]
		private RadialInventory _selector;

		[SerializeField]
		private RawImage[] _selectorSlots;

		[SerializeField]
		private CanvasGroup _selectorGroup;

		[SerializeField]
		private CanvasGroup _descriptionGroup;

		[SerializeField]
		private CandyObject[] _candies;

		[SerializeField]
		private TextMeshProUGUI _title;

		[SerializeField]
		private TextMeshProUGUI _description;

		[SerializeField]
		private TextMeshProUGUI _effects;

		private Scp330Bag _bag;

		private bool _openDelay;

		private bool _cancelled;

		private CandyKindID _displayedCandy;

		public CursorOverrideMode CursorOverride { get; private set; }

		public bool LockMovement => false;

		public override void InitLocal(ItemBase parent)
		{
		}

		public override void InitSpectator(ReferenceHub ply, ItemIdentifier id, bool wasEquipped)
		{
		}

		internal override void OnEquipped()
		{
		}

		protected void Update()
		{
		}

		protected override void LateUpdate()
		{
		}

		private void HandleSelectMessage(SelectScp330Message msg)
		{
		}

		private void OnDisable()
		{
		}

		private void SetCandyModel(CandyKindID id)
		{
		}

		private void DisplaySelector(CandyKindID id)
		{
		}

		private void DisplayDescriptions(CandyKindID candy)
		{
		}

		private bool TryGetCandyObject(CandyKindID id, out CandyObject val)
		{
			val = default(CandyObject);
			return false;
		}

		private void CancelSelector(bool bringBackInventory = false)
		{
		}

		public static AudioClip GetClipForCandy(CandyKindID kind)
		{
			return null;
		}
	}
}
