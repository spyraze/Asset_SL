using PlayerRoles.FirstPersonControl.Thirdperson;

namespace InventorySystem.Items.Thirdperson.LayerProcessors
{
	public class RightHandedLayerProcessor : LayerProcessorBase
	{
		private const float HandEaseout = 0.75f;

		protected override ThirdpersonLayerWeight GetWeightForLayer(AnimItemLayer3p layer)
		{
			return default(ThirdpersonLayerWeight);
		}

		public static float CalculateWeight(AnimatedCharacterModel model, AnimItemLayer3p layer)
		{
			return 0f;
		}
	}
}
