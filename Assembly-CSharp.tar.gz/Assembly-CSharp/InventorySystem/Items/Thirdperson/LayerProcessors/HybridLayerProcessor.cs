namespace InventorySystem.Items.Thirdperson.LayerProcessors
{
	public class HybridLayerProcessor : LayerProcessorBase
	{
		private float _blend;

		public void SetDualHandBlend(float blendAmount)
		{
		}

		protected override ThirdpersonLayerWeight GetWeightForLayer(AnimItemLayer3p layer)
		{
			return default(ThirdpersonLayerWeight);
		}

		private ThirdpersonLayerWeight ZeroBlendWeight(AnimItemLayer3p layer)
		{
			return default(ThirdpersonLayerWeight);
		}

		private ThirdpersonLayerWeight FullBlendWeight(AnimItemLayer3p layer)
		{
			return default(ThirdpersonLayerWeight);
		}
	}
}
