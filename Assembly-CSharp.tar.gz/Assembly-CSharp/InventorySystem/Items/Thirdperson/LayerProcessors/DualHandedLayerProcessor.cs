using PlayerRoles.FirstPersonControl.Thirdperson;

namespace InventorySystem.Items.Thirdperson.LayerProcessors
{
	public class DualHandedLayerProcessor : LayerProcessorBase
	{
		private const float ChestEaseout = 0.3f;

		protected override ThirdpersonLayerWeight GetWeightForLayer(AnimItemLayer3p layer)
		{
			return default(ThirdpersonLayerWeight);
		}

		public static float CalculateWeight(AnimatedCharacterModel model, AnimItemLayer3p layer)
		{
			return 0f;
		}
	}
}
