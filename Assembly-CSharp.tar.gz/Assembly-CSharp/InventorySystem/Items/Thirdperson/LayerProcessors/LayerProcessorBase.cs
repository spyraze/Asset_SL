using PlayerRoles.FirstPersonControl.Thirdperson;
using UnityEngine;

namespace InventorySystem.Items.Thirdperson.LayerProcessors
{
	public abstract class LayerProcessorBase : MonoBehaviour
	{
		private bool _alreadyInit;

		protected ThirdpersonItemBase Source { get; private set; }

		public AnimatedCharacterModel TargetModel => null;

		protected Animator Animator => null;

		protected ReferenceHub OwnerHub => null;

		public ThirdpersonLayerWeight GetWeightForLayer(ThirdpersonItemBase source, AnimItemLayer3p layer)
		{
			return default(ThirdpersonLayerWeight);
		}

		protected virtual void Init(ThirdpersonItemBase source)
		{
		}

		protected abstract ThirdpersonLayerWeight GetWeightForLayer(AnimItemLayer3p layer);
	}
}
