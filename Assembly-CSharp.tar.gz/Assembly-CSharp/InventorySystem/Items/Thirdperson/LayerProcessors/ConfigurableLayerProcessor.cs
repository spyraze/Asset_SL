using UnityEngine;

namespace InventorySystem.Items.Thirdperson.LayerProcessors
{
	public class ConfigurableLayerProcessor : LayerProcessorBase
	{
		[SerializeField]
		private bool _rightHandOnly;

		[SerializeField]
		private float _handStationaryIntensity;

		[SerializeField]
		private float _handWalkIntensity;

		[SerializeField]
		private float _chestStationaryIntensity;

		[SerializeField]
		private float _chestWalkIntensity;

		[SerializeField]
		private AnimItemLayer3p[] _overlayBlockMask;

		private float WalkWeight => 0f;

		protected override ThirdpersonLayerWeight GetWeightForLayer(AnimItemLayer3p layer)
		{
			return default(ThirdpersonLayerWeight);
		}
	}
}
