using UnityEngine;

namespace InventorySystem.Items.ToggleableLights.Flashlight
{
	public class FlashlightEvents : MonoBehaviour
	{
		[SerializeField]
		private ItemViewmodelBase _ivb;

		private void Toggle()
		{
		}
	}
}
