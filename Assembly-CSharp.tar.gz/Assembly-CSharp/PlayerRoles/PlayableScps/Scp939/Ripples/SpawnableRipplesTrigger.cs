namespace PlayerRoles.PlayableScps.Scp939.Ripples
{
	public class SpawnableRipplesTrigger : RippleTriggerBase
	{
		public override void SpawnObject()
		{
		}

		public override void ResetObject()
		{
		}

		private void OnSpawned(SpawnableRipple sr)
		{
		}
	}
}
