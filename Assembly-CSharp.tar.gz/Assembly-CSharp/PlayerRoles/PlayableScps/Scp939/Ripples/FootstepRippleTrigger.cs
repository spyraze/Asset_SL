using Mirror;
using PlayerRoles.FirstPersonControl.Thirdperson;
using PlayerRoles.PlayableScps.Scp1507;
using RelativePositioning;

namespace PlayerRoles.PlayableScps.Scp939.Ripples
{
	public class FootstepRippleTrigger : RippleTriggerBase
	{
		private ReferenceHub _syncPlayer;

		private RelativePosition _syncPos;

		private byte _syncDistance;

		public override void SpawnObject()
		{
		}

		public override void ResetObject()
		{
		}

		private void OnFlamingoStep(Scp1507Model flamingoModel)
		{
		}

		private void OnFootstepPlayed(CharacterModel model, float dis)
		{
		}

		public override void ServerWriteRpc(NetworkWriter writer)
		{
		}

		public override void ClientProcessRpc(NetworkReader reader)
		{
		}
	}
}
