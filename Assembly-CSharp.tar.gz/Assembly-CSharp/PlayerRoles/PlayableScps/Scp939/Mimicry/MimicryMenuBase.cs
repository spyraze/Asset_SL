using UnityEngine;

namespace PlayerRoles.PlayableScps.Scp939.Mimicry
{
	public abstract class MimicryMenuBase : MonoBehaviour
	{
		protected virtual void Awake()
		{
		}

		protected virtual void Setup(Scp939Role role)
		{
		}
	}
}
