using PlayerRoles.FirstPersonControl;
using PlayerRoles.FirstPersonControl.Thirdperson;
using UnityEngine;

namespace PlayerRoles.PlayableScps.Scp049.Zombies
{
	public class ZombieModel : AnimatedCharacterModel
	{
		private const int StrafeLayer = 6;

		private const int ConsumeLayer = 8;

		private const float ConsumeTransitionSpeed = 10f;

		private static readonly int StrafeHash;

		private static readonly int AttackHash;

		private static readonly int ConsumeHash;

		private ZombieAttackAbility _attackAbility;

		private ZombieConsumeAbility _consumeAbility;

		private float _prevConsume;

		[field: SerializeField]
		public Transform HeadObject { get; private set; }

		private void OnAttack()
		{
		}

		protected override void Update()
		{
		}

		public override void Setup(ReferenceHub owner, IFpcRole fpc, Vector3 localPos, Quaternion localRot)
		{
		}

		public override void ResetObject()
		{
		}
	}
}
