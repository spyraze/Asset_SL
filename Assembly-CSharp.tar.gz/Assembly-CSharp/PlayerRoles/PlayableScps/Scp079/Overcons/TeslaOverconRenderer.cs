using PlayerRoles.PlayableScps.Scp079.Cameras;
using UnityEngine;

namespace PlayerRoles.PlayableScps.Scp079.Overcons
{
	public class TeslaOverconRenderer : PooledOverconRenderer
	{
		private static readonly Vector3 Offset;

		internal override void SpawnOvercons(Scp079Camera newCamera)
		{
		}
	}
}
