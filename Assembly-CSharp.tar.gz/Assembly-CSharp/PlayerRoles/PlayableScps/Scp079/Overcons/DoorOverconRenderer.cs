using PlayerRoles.PlayableScps.Scp079.Cameras;

namespace PlayerRoles.PlayableScps.Scp079.Overcons
{
	public class DoorOverconRenderer : PooledOverconRenderer
	{
		private const float DoorHeight = 1.25f;

		internal override void SpawnOvercons(Scp079Camera newCamera)
		{
		}
	}
}
