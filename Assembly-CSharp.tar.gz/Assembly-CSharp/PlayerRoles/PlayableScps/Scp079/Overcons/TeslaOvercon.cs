namespace PlayerRoles.PlayableScps.Scp079.Overcons
{
	public class TeslaOvercon : StandardOvercon
	{
	}
}
