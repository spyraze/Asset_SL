using System.Collections.Generic;
using PlayerRoles.PlayableScps.Scp079.GUI;
using PlayerRoles.Subroutines;
using UnityEngine;

namespace PlayerRoles.PlayableScps.Scp079.Map
{
	public class Scp079TeammateIndicators : Scp079GuiElementBase
	{
		private enum IndicatorType
		{
			Low = 0,
			Medium = 1,
			High = 2
		}

		private const float NonExactCooldown = 1.5f;

		private Scp079TierManager _tierManager;

		private IZoneMap[] _maps;

		private readonly AbilityCooldown _nonExactCooldown;

		private readonly Dictionary<ReferenceHub, RectTransform> _instances;

		[SerializeField]
		private RectTransform _templateLow;

		[SerializeField]
		private RectTransform _templateMid;

		[SerializeField]
		private RectTransform _templateHigh;

		private IndicatorType CurType => default(IndicatorType);

		internal override void Init(Scp079Role role, ReferenceHub owner)
		{
		}

		private void OnDestroy()
		{
		}

		private void OnRoleChanged(ReferenceHub hub, PlayerRoleBase prevRole, PlayerRoleBase newRole)
		{
		}

		private void OnPlayerRemoved(ReferenceHub hub)
		{
		}

		private void RemovePlayerIndicator(ReferenceHub hub)
		{
		}

		private void RefreshPlayerIndicator(ReferenceHub hub)
		{
		}

		private void SetupPlayer(ReferenceHub hub)
		{
		}

		private void Rebuild()
		{
		}

		private void Update()
		{
		}
	}
}
