namespace PlayerRoles.PlayableScps.Scp079.GUI
{
	public enum NotificationSound
	{
		None = -1,
		Standard = 0
	}
}
