using System.Collections.Generic;
using Mirror;
using UnityEngine;

namespace PlayerRoles.FirstPersonControl.Thirdperson.Subcontrollers
{
	public static class WearableSync
	{
		public struct WearableSyncMessage : NetworkMessage
		{
			public uint HubNetId;

			public WearableElements Data;
		}

		private static readonly Dictionary<ReferenceHub, WearableElements> Database;

		public static WearableElements GetWearables(ReferenceHub hub)
		{
			return default(WearableElements);
		}

		public static void OverrideWearables(this ReferenceHub hub, WearableElements newWearables)
		{
		}

		public static void EnableWearables(this ReferenceHub hub, WearableElements toEnable)
		{
		}

		public static void DisableWearables(this ReferenceHub hub, WearableElements toDisable)
		{
		}

		[RuntimeInitializeOnLoadMethod]
		private static void Init()
		{
		}

		private static void OnClientReady()
		{
		}

		private static void ProcessMessage(WearableSyncMessage msg)
		{
		}

		private static void OnHubRemoved(ReferenceHub hub)
		{
		}

		private static void OnHubAdded(ReferenceHub hub)
		{
		}

		private static void OnServerRoleSet(ReferenceHub userHub, RoleTypeId newRole, RoleChangeReason reason)
		{
		}
	}
}
