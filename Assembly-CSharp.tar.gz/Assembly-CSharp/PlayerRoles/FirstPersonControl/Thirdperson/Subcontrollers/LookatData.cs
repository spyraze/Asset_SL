using System;
using UnityEngine;

namespace PlayerRoles.FirstPersonControl.Thirdperson.Subcontrollers
{
	[Serializable]
	public struct LookatData
	{
		public Vector3 LookDir;

		public float GlobalWeight;

		public float BodyWeight;

		public float HeadWeight;

		public LookatData LerpTo(LookatData target, float weight)
		{
			return default(LookatData);
		}
	}
}
