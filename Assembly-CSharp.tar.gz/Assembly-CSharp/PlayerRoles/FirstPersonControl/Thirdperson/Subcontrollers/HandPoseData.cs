using System;

namespace PlayerRoles.FirstPersonControl.Thirdperson.Subcontrollers
{
	[Serializable]
	public struct HandPoseData
	{
		public float LeftHandWeight;

		public float LeftHandPose;

		public float RightHandWeight;

		public float RightHandPose;

		public HandPoseData LerpTo(HandPoseData target, float weight)
		{
			return default(HandPoseData);
		}
	}
}
