using System;
using GameObjectPools;
using UnityEngine;

namespace PlayerRoles.FirstPersonControl.Thirdperson.Subcontrollers
{
	public class WearableSubcontroller : SubcontrollerBehaviour, IPoolResettable
	{
		[Serializable]
		public class DisplayableWearable
		{
			private Vector3 _parentOriginalScale;

			[field: SerializeField]
			public WearableElements Item { get; private set; }

			[field: SerializeField]
			public GameObject TargetObject { get; private set; }

			[field: SerializeField]
			public HumanBodyBones ParentBone { get; private set; }

			public Transform TargetTransform { get; private set; }

			public Vector3 GlobalScale { get; private set; }

			public void SetScale(float scale)
			{
			}

			public void Awake(Animator anim)
			{
			}
		}

		[SerializeField]
		private DisplayableWearable[] _wearables;

		private WearableElements _syncWearable;

		public void ResetObject()
		{
		}

		public override void OnReassigned()
		{
		}

		public override void Init(AnimatedCharacterModel model, int index)
		{
		}

		private void OnVisibilityChanged()
		{
		}

		private void OnFadeChanged()
		{
		}

		private void OnCulllChanged()
		{
		}

		private void SetWearables(WearableElements elements)
		{
		}

		public void ClientReceiveWearables(WearableElements sync)
		{
		}

		public bool TryGetWearable(WearableElements wearable, out DisplayableWearable ret)
		{
			ret = null;
			return false;
		}
	}
}
