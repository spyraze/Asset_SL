using InventorySystem.Items.Thirdperson;
using InventorySystem.Searching;
using Mirror;
using UnityEngine;

namespace PlayerRoles.FirstPersonControl.Thirdperson.Subcontrollers.OverlayAnims
{
	public class SearchCompleteAnimation : OverlayAnimationsBase
	{
		private bool _interacted;

		private double? _startTime;

		private SearchCoordinator _lastSearchCoordinator;

		private const float ClipLength = 1.111f;

		public override bool WantsToPlay => false;

		public override bool Bypassable => false;

		public override AnimationClip Clip => null;

		public override float GetLayerWeight(AnimItemLayer3p layer)
		{
			return 0f;
		}

		public override void OnReassigned()
		{
		}

		public override void OnStarted()
		{
		}

		public override void OnStopped()
		{
		}

		public override void OnReset()
		{
		}

		public override void ProcessRpc(NetworkReader reader)
		{
		}

		private void OnSearchCompleted(SearchCompletor completor)
		{
		}
	}
}
