using GameObjectPools;
using InventorySystem.Items.Thirdperson;
using Mirror;
using UnityEngine;

namespace PlayerRoles.FirstPersonControl.Thirdperson.Subcontrollers.OverlayAnims
{
	public class OverlayAnimationsSubcontroller : SubcontrollerBehaviour, IPoolResettable
	{
		private const float RegularAdjustSpeed = 6.5f;

		private const float DisableOldAdjustSpeed = 11.5f;

		private readonly OverlayAnimationsBase[] _overlayAnimations;

		private OverlayAnimationsBase _lastActive;

		private InventorySubcontroller _inventory;

		private float _leftIkScale;

		private float _rightIkScale;

		[SerializeField]
		private ItemLayerLink[] _layers;

		[SerializeField]
		private AnimationClip _animationToReplace;

		public AnimationClip SearchCompleteClip;

		public AnimationClip FlashedLoopClip;

		public override void OnReassigned()
		{
		}

		public void ResetObject()
		{
		}

		public override void Init(AnimatedCharacterModel model, int index)
		{
		}

		public override void ProcessRpc(NetworkReader reader)
		{
		}

		private void OnAnimatorIK(int layerIndex)
		{
		}

		private void UpdateAll()
		{
		}

		private void UpdateSwitch(OverlayAnimationsBase newMatch)
		{
		}

		private void UpdateActive()
		{
		}

		private float AdjustLayerWeight(ItemLayerLink layer, float target, float speedMultiplier)
		{
			return 0f;
		}

		private void ScaleIk(AvatarIKGoal goal, float multiplier)
		{
		}
	}
}
