using CustomPlayerEffects;
using InventorySystem.Items.Thirdperson;
using UnityEngine;

namespace PlayerRoles.FirstPersonControl.Thirdperson.Subcontrollers.OverlayAnims
{
	public class FlashedAnimation : OverlayAnimationsBase
	{
		private const float DecayDuration = 1.7f;

		private bool _hasEffect;

		private float _remainingSustain;

		private Flashed _effect;

		private bool EffectEnabled => false;

		public override bool WantsToPlay => false;

		public override bool Bypassable => false;

		public override AnimationClip Clip => null;

		public override float GetLayerWeight(AnimItemLayer3p layer)
		{
			return 0f;
		}

		public override void UpdateActive()
		{
		}

		public override void OnStopped()
		{
		}

		public override void OnReassigned()
		{
		}

		public override void OnReset()
		{
		}
	}
}
