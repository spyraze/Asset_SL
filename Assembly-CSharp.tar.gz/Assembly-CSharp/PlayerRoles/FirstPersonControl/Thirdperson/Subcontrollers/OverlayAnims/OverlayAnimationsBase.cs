using InventorySystem.Items.Thirdperson;
using Mirror;
using UnityEngine;

namespace PlayerRoles.FirstPersonControl.Thirdperson.Subcontrollers.OverlayAnims
{
	public abstract class OverlayAnimationsBase
	{
		private static readonly int HashReplayInstant;

		private static readonly int HashReplaySoft;

		public bool IsPlaying { get; private set; }

		protected byte SyncIndex { get; private set; }

		protected OverlayAnimationsSubcontroller Controller { get; private set; }

		public AnimatedCharacterModel Model { get; private set; }

		public abstract bool WantsToPlay { get; }

		public abstract bool Bypassable { get; }

		public abstract AnimationClip Clip { get; }

		public abstract float GetLayerWeight(AnimItemLayer3p layer);

		public virtual void UpdateActive()
		{
		}

		public virtual void OnStarted()
		{
		}

		public virtual void OnStopped()
		{
		}

		public virtual void OnReassigned()
		{
		}

		public virtual void OnReset()
		{
		}

		public virtual void ProcessRpc(NetworkReader reader)
		{
		}

		public virtual void Init(OverlayAnimationsSubcontroller ctrl, int index)
		{
		}

		public void SendRpc()
		{
		}

		public void Replay(bool instant)
		{
		}

		private void WriteRpcHeader(NetworkWriter writer)
		{
		}
	}
}
