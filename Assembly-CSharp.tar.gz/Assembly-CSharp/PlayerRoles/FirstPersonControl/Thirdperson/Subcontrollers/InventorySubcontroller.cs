using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using AnimatorLayerManagement;
using GameObjectPools;
using InventorySystem.Items;
using InventorySystem.Items.Thirdperson;
using UnityEngine;

namespace PlayerRoles.FirstPersonControl.Thirdperson.Subcontrollers
{
	public class InventorySubcontroller : SubcontrollerBehaviour, IPoolResettable, ILookatModifier, IHandPoseModifier
	{
		[Serializable]
		private struct DefaultAnimatorOverrides
		{
			public AnimationClip Original;

			public AnimationClip Override;
		}

		private enum TransitionStatus
		{
			RetractingPrevious = 0,
			EquippingNew = 1,
			Done = 2
		}

		private const float DefaultTransitionTime = 0.5f;

		private ItemIdentifier _prevItem;

		private Dictionary<AnimationClip, AnimationClip> _dictionarizedDefaultOverrides;

		private float _weightAdjustSpeed;

		private TransitionStatus _transitionStatus;

		private bool _hasThirdpersonInstance;

		private ThirdpersonItemBase _lastThirdpersonInstance;

		private int _regularIdleLayerIndex;

		private int _itemIdleLayerIndex;

		private int? _cuffedOverrideLayerIndex;

		private int _movementOverrideLayerIndex;

		private float _transitionWeight;

		private float _prevCuffWeight;

		[SerializeField]
		private ItemLayerLink[] _itemLayers;

		[SerializeField]
		private DefaultAnimatorOverrides[] _defaultAnimatorOverrides;

		[SerializeField]
		private LayerRefId _regularIdleLayer;

		[SerializeField]
		private LayerRefId _itemIdleLayer;

		[SerializeField]
		private LayerRefId _movementOverrideLayer;

		[SerializeField]
		private LayerRefId _cuffedOverrideLayer;

		[SerializeField]
		private float _cuffedAdjustSpeed;

		public bool PoolHeldItem;

		public Transform ItemSpawnpoint { get; private set; }

		public float TransitionWeight
		{
			get
			{
				return 0f;
			}
			private set
			{
			}
		}

		public event Action OnUpdated
		{
			[CompilerGenerated]
			add
			{
			}
			[CompilerGenerated]
			remove
			{
			}
		}

		private void OnAnimatorIK(int layerIndex)
		{
		}

		private void OnFadeChanged()
		{
		}

		private void OnVisibilityChanged()
		{
		}

		private void ResetThirdpersonItem()
		{
		}

		private void SwapThirdpersonItem(ItemIdentifier itemId)
		{
		}

		private float GetTransitionTime(ItemIdentifier itemId)
		{
			return 0f;
		}

		private void UpdateLayerWeights()
		{
		}

		private void UpdateCuffWeight()
		{
		}

		public override void Init(AnimatedCharacterModel model, int index)
		{
		}

		private void CacheLayerIndexes()
		{
		}

		private void Update()
		{
		}

		public bool TryGetCurrentInstance(out ThirdpersonItemBase instance)
		{
			instance = null;
			return false;
		}

		public bool TryGetCurrentInstance<T>(out T instance)
		{
			instance = default(T);
			return false;
		}

		public void ResetObject()
		{
		}

		public void UpdateHeldItem(ItemIdentifier itemId)
		{
		}

		public LookatData ProcessLookat(LookatData original)
		{
			return default(LookatData);
		}

		public HandPoseData ProcessHandPose(HandPoseData original)
		{
			return default(HandPoseData);
		}
	}
}
