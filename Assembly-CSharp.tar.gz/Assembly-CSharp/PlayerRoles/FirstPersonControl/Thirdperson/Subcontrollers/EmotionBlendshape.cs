namespace PlayerRoles.FirstPersonControl.Thirdperson.Subcontrollers
{
	public enum EmotionBlendshape
	{
		Undefined = 0,
		Frown = 1,
		BrowRaise = 2,
		EyeTapLeft = 3,
		EyeTapRight = 4,
		EyeCloseLeft = 5,
		EyeCloseRight = 6,
		EyeOpenLeft = 7,
		EyeOpenRight = 8,
		EyesBottom = 9,
		Worried = 10,
		MouthOpen = 11,
		JawDrop = 12,
		Grin = 13,
		SmileOpen = 14,
		Disgusted = 15,
		Angry = 16,
		LipsTop = 17,
		LipsNormalBottom = 18,
		LipsStretchBottom = 19,
		Ogre = 20,
		Chad = 21,
		MixClosedEyes = 22
	}
}
