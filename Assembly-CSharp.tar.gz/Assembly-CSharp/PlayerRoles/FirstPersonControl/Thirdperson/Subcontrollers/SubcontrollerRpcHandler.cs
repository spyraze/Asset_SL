using System;
using Mirror;
using UnityEngine;

namespace PlayerRoles.FirstPersonControl.Thirdperson.Subcontrollers
{
	public static class SubcontrollerRpcHandler
	{
		public readonly struct SubcontrollerRpcMessage : NetworkMessage
		{
			private static readonly byte[] Buffer;

			private static readonly NetworkReader Reader;

			private readonly int _bytesWritten;

			private readonly RecyclablePlayerId _player;

			private readonly RoleTypeId _roleFailsafe;

			private readonly int _syncIndex;

			public SubcontrollerRpcMessage(NetworkWriter writer, AnimatedCharacterModel model, int syncIndex)
			{
				_bytesWritten = 0;
				_player = default(RecyclablePlayerId);
				_roleFailsafe = default(RoleTypeId);
				_syncIndex = 0;
			}

			public override string ToString()
			{
				return null;
			}

			internal SubcontrollerRpcMessage(NetworkReader reader)
			{
				_bytesWritten = 0;
				_player = default(RecyclablePlayerId);
				_roleFailsafe = default(RoleTypeId);
				_syncIndex = 0;
			}

			internal void Serialize(NetworkWriter writer)
			{
			}

			internal void ProcessRpc()
			{
			}
		}

		public static void ServerSendRpc(SubcontrollerBehaviour behaviour, Action<NetworkWriter> rpcWriter)
		{
		}

		public static void ServerSendRpc(AnimatedCharacterModel model, int syncIndex, Action<NetworkWriter> rpcWriter)
		{
		}

		[RuntimeInitializeOnLoadMethod]
		private static void Init()
		{
		}

		private static void ClientProcessMessage(SubcontrollerRpcMessage msg)
		{
		}

		public static SubcontrollerRpcMessage ReadSubcontrollerRpcMessage(this NetworkReader reader)
		{
			return default(SubcontrollerRpcMessage);
		}

		public static void WriteSubcontrollerRpcMessage(this NetworkWriter writer, SubcontrollerRpcMessage msg)
		{
		}
	}
}
