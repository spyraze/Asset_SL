namespace PlayerRoles.FirstPersonControl.Thirdperson.Subcontrollers
{
	public enum EmotionPresetType : byte
	{
		Neutral = 0,
		Happy = 1,
		AwkwardSmile = 2,
		Scared = 3,
		Angry = 4,
		Chad = 5,
		Ogre = 6
	}
}
