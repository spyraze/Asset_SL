using System;
using AnimatorLayerManagement;
using UnityEngine;

namespace PlayerRoles.FirstPersonControl.Thirdperson.Subcontrollers
{
	public class FeetStabilizerSubcontroller : SubcontrollerBehaviour
	{
		[Serializable]
		private class Foot
		{
			[SerializeField]
			private AvatarIKGoal _goal;

			[SerializeField]
			private HumanBodyBones _bone;

			[SerializeField]
			private Vector3 _modelspacePosition;

			[SerializeField]
			private bool _calibrate;

			private Transform _footTr;

			public void Init(Animator anim)
			{
			}

			public void OnIK(AnimatedCharacterModel model, float weight)
			{
			}
		}

		[SerializeField]
		private LayerRefId _ikLayer;

		[SerializeField]
		private Foot[] _feet;

		[SerializeField]
		private float _maxWeightAdjustSpeed;

		[SerializeField]
		private float _maxWeightTurnDecreaseSpeed;

		private IRotationRetainer _rotationRetainer;

		private float _lastRetentionWeight;

		private float _maxWeight;

		public override void Init(AnimatedCharacterModel model, int index)
		{
		}

		private void OnAnimatorIK(int layerIndex)
		{
		}

		private void UpdateWeight()
		{
		}

		private void Update()
		{
		}
	}
}
