using UnityEngine;

namespace PlayerRoles.FirstPersonControl.Thirdperson.Subcontrollers
{
	public class IdlePoseRetainerSubcontroller : SubcontrollerBehaviour, IRotationRetainer
	{
		private enum TurnStatus
		{
			Idle = 0,
			TurningRight = 1,
			TurningLeft = 2
		}

		private static readonly int TurnTriggerHash;

		private static readonly int TurnBlendHash;

		private static readonly AnimationCurve TurningCurve;

		private const float TurnAngle = 66f;

		private const float FullTurnTime = 0.7f;

		private const float FastTurnTime = 0.45f;

		private const float TurnAnimCooldown = 0.3f;

		private const float UncomfortableAngle = 35f;

		private const float UncomfortableTurnDelay = 2.5f;

		private const float MaxAngularDesync = 95f;

		private const float LayerAdjustSpeed = 5f;

		private const float FullLockThreshold = 0.12f;

		private const float UnlockThreshold = 0.3f;

		private float _uncomfortableElapsed;

		private float _startTurningRotation;

		private float _targetTurningRotation;

		private float _turningElapsed;

		private float _turningAnimCooldown;

		private TurnStatus _turnStatus;

		private float _prevAngleDelta;

		private Quaternion _relativeRotation;

		private byte _lastWaypointId;

		private Transform _lastOwnerRoot;

		public float AngleDelta { get; private set; }

		public float AngleAbsDiff { get; private set; }

		public float RetentionWeight => 0f;

		public bool IsTurning => false;

		private float OwnerRotation => 0f;

		private float ModelRotation
		{
			get
			{
				return 0f;
			}
			set
			{
			}
		}

		public override void OnReassigned()
		{
		}

		public override void Init(AnimatedCharacterModel model, int index)
		{
		}

		private void OnPlayerMoved()
		{
		}

		private void Update()
		{
		}

		private void CalculateDeltas()
		{
		}

		private void ClampOwner()
		{
		}

		private void UpdateTurning()
		{
		}

		private void UpdateComfort()
		{
		}

		private void StartTurning()
		{
		}
	}
}
