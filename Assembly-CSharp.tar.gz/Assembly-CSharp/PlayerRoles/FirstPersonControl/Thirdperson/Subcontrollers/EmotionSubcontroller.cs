using GameObjectPools;
using UnityEngine;

namespace PlayerRoles.FirstPersonControl.Thirdperson.Subcontrollers
{
	public class EmotionSubcontroller : SubcontrollerBehaviour, IPoolResettable
	{
		public const EmotionPresetType FallbackPreset = EmotionPresetType.Neutral;

		private int _rendCnt;

		[field: SerializeField]
		public EmotionRenderer[] Renderers { get; private set; }

		[field: SerializeField]
		public EmotionPreset[] Presets { get; private set; }

		public override void Init(AnimatedCharacterModel model, int index)
		{
		}

		public override void OnReassigned()
		{
		}

		public void ResetObject()
		{
		}

		public void SetPreset(EmotionPresetType presetType)
		{
		}

		private void ResetWeights()
		{
		}

		private void SetWeight(EmotionBlendshape blendshape, float weight)
		{
		}
	}
}
