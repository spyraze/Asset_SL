using AnimatorLayerManagement;
using UnityEngine;

namespace PlayerRoles.FirstPersonControl.Thirdperson.Subcontrollers
{
	public class LookatSubcontroller : SubcontrollerBehaviour
	{
		private const float LookDistance = 50f;

		private const float LookClampHorizontalDot = 0.03f;

		private const float LookClampYPositiveScale = 0.65f;

		private const float LookClampYNegativeScale = 0.85f;

		private int _lookPassIndex;

		[SerializeField]
		private AnimationCurve _bodyWeightOverDot;

		[SerializeField]
		private LayerRefId _lookPassLayer;

		public override void Init(AnimatedCharacterModel model, int index)
		{
		}

		private void OnAnimatorIK(int layerIndex)
		{
		}

		private void IKLookatPass()
		{
		}

		private Vector3 ClampHorizontal(Vector3 v3, Vector3 modelFwd)
		{
			return default(Vector3);
		}

		private Vector3 ClampVertical(Vector3 v3)
		{
			return default(Vector3);
		}
	}
}
