using AnimatorLayerManagement;
using UnityEngine;

namespace PlayerRoles.FirstPersonControl.Thirdperson.Subcontrollers
{
	public class HandPoseSubcontroller : SubcontrollerBehaviour
	{
		private static readonly int LeftHandPoseHash;

		private static readonly int RightHandPoseHash;

		private int _leftHandLayerIndex;

		private int _rightHandLayerIndex;

		[SerializeField]
		private LayerRefId _leftHandLayer;

		[SerializeField]
		private LayerRefId _rightHandLayer;

		public override void Init(AnimatedCharacterModel model, int index)
		{
		}

		private void LateUpdate()
		{
		}

		private void Evaluate()
		{
		}
	}
}
