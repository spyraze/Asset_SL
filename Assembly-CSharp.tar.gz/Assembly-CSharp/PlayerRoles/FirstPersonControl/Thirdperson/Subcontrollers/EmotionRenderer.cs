using UnityEngine;

namespace PlayerRoles.FirstPersonControl.Thirdperson.Subcontrollers
{
	public class EmotionRenderer : MonoBehaviour
	{
		private SkinnedMeshRenderer _rend;

		private int?[] _blendshapeToIndex;

		[field: SerializeField]
		public EmotionBlendshape[] Blendshapes { get; private set; }

		private void Awake()
		{
		}

		public float GetWeight(EmotionBlendshape blendshape)
		{
			return 0f;
		}

		public void SetWeight(EmotionBlendshape blendshape, float weight)
		{
		}

		public void ResetWeights()
		{
		}
	}
}
