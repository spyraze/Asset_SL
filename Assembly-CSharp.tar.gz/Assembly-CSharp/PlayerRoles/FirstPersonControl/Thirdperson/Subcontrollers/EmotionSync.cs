using System.Collections.Generic;
using Mirror;
using UnityEngine;

namespace PlayerRoles.FirstPersonControl.Thirdperson.Subcontrollers
{
	public static class EmotionSync
	{
		public struct EmotionSyncMessage : NetworkMessage
		{
			public uint HubNetId;

			public EmotionPresetType Data;
		}

		private static readonly Dictionary<ReferenceHub, EmotionPresetType> Database;

		public static EmotionPresetType GetEmotionPreset(ReferenceHub hub)
		{
			return default(EmotionPresetType);
		}

		public static void ServerSetEmotionPreset(this ReferenceHub hub, EmotionPresetType preset)
		{
		}

		[RuntimeInitializeOnLoadMethod]
		private static void Init()
		{
		}

		private static void OnClientReady()
		{
		}

		private static void ProcessMessage(EmotionSyncMessage msg)
		{
		}

		private static void OnHubRemoved(ReferenceHub hub)
		{
		}

		private static void OnHubAdded(ReferenceHub hub)
		{
		}

		private static void OnServerRoleSet(ReferenceHub userHub, RoleTypeId newRole, RoleChangeReason reason)
		{
		}

		private static void TempServerProcessMessage(NetworkConnection conn, EmotionSyncMessage msg)
		{
		}
	}
}
