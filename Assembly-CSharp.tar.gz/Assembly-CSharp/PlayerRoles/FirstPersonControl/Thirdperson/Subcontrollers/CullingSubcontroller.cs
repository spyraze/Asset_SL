using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using ProgressiveCulling;

namespace PlayerRoles.FirstPersonControl.Thirdperson.Subcontrollers
{
	public class CullingSubcontroller : CullableSimpleDynamic, IAnimatedModelSubcontroller
	{
		private AnimatedCharacterModel _model;

		private readonly Stopwatch _culledElapsed;

		private const float MaxDeltaTime = 5f;

		public bool AnimCulled { get; private set; }

		public event Action OnAnimatorUpdated
		{
			[CompilerGenerated]
			add
			{
			}
			[CompilerGenerated]
			remove
			{
			}
		}

		public event Action OnBeforeAnimatorUpdated
		{
			[CompilerGenerated]
			add
			{
			}
			[CompilerGenerated]
			remove
			{
			}
		}

		public void Init(AnimatedCharacterModel model, int index)
		{
		}

		private void EvaluateCulling(out bool allowCulling)
		{
			allowCulling = default(bool);
		}

		private void OnPlyMoved()
		{
		}
	}
}
