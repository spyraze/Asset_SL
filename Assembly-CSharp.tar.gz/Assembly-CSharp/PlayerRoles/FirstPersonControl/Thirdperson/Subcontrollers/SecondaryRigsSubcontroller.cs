using System;
using UnityEngine;

namespace PlayerRoles.FirstPersonControl.Thirdperson.Subcontrollers
{
	public class SecondaryRigsSubcontroller : SubcontrollerBehaviour
	{
		[Serializable]
		public struct SecondaryBone
		{
			public Transform Original;

			public Transform Target;

			public readonly void Match()
			{
			}
		}

		[SerializeField]
		private SecondaryBone[] _secondaryBones;

		private void LateUpdate()
		{
		}

		private void MatchAll()
		{
		}

		public override void Init(AnimatedCharacterModel model, int index)
		{
		}
	}
}
