using System;

namespace CommandSystem.Commands.RemoteAdmin.Inventory
{
	[CommandHandler(typeof(RemoteAdminCommandHandler))]
	public class ForceEquipCommand : ICommand, IUsageProvider
	{
		public string Command { get; }

		public string[] Aliases { get; }

		public string Description { get; }

		public string[] Usage { get; }

		public bool Execute(ArraySegment<string> arguments, ICommandSender sender, out string response)
		{
			response = null;
			return false;
		}

		private bool TryEquip(ReferenceHub hub, ItemType itemToEquip)
		{
			return false;
		}

		private bool TryHolster(ReferenceHub hub, ItemType parsedItem)
		{
			return false;
		}
	}
}
