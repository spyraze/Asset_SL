using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace CommandSystem.Commands.RemoteAdmin.Inventory
{
	[CommandHandler(typeof(RemoteAdminCommandHandler))]
	public class GiveCommand : ICommand, IUsageProvider
	{
		[CompilerGenerated]
		private sealed class _003CParseItems_003Ed__13 : IEnumerable<ItemType>, IEnumerable, IEnumerator<ItemType>, IEnumerator, IDisposable
		{
			private int _003C_003E1__state;

			private ItemType _003C_003E2__current;

			private int _003C_003El__initialThreadId;

			private string argument;

			public string _003C_003E3__argument;

			private string[] _003C_003E7__wrap1;

			private int _003C_003E7__wrap2;

			ItemType IEnumerator<ItemType>.Current
			{
				[DebuggerHidden]
				get
				{
					return default(ItemType);
				}
			}

			object IEnumerator.Current
			{
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			[DebuggerHidden]
			public _003CParseItems_003Ed__13(int _003C_003E1__state)
			{
			}

			[DebuggerHidden]
			void IDisposable.Dispose()
			{
			}

			private bool MoveNext()
			{
				return false;
			}

			bool IEnumerator.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in MoveNext
				return this.MoveNext();
			}

			[DebuggerHidden]
			void IEnumerator.Reset()
			{
			}

			[DebuggerHidden]
			IEnumerator<ItemType> IEnumerable<ItemType>.GetEnumerator()
			{
				return null;
			}

			[DebuggerHidden]
			IEnumerator IEnumerable.GetEnumerator()
			{
				return null;
			}
		}

		public string Command { get; }

		public string[] Aliases { get; }

		public string Description { get; }

		public string[] Usage { get; }

		public bool Execute(ArraySegment<string> arguments, ICommandSender sender, out string response)
		{
			response = null;
			return false;
		}

		[IteratorStateMachine(typeof(_003CParseItems_003Ed__13))]
		private static IEnumerable<ItemType> ParseItems(string argument)
		{
			return null;
		}

		private static void AddItem(ReferenceHub ply, ICommandSender sender, ItemType id)
		{
		}
	}
}
