using System;

namespace CommandSystem.Commands.RemoteAdmin.Broadcasts
{
	public abstract class BroadcastCommandBase : ICommand, IUsageProvider
	{
		public abstract string Command { get; }

		public abstract string[] Aliases { get; }

		public abstract string Description { get; }

		public abstract string[] Usage { get; }

		public virtual int MinimumArguments => 0;

		public virtual bool Execute(ArraySegment<string> arguments, ICommandSender sender, out string response)
		{
			response = null;
			return false;
		}

		public abstract bool OnExecute(ArraySegment<string> arguments, ICommandSender sender, out string response);

		protected bool HasInputFlag(string inputFlag, out Broadcast.BroadcastFlags broadcastFlag, int argumentCount = 0)
		{
			broadcastFlag = default(Broadcast.BroadcastFlags);
			return false;
		}

		protected bool IsValidDuration(string inputDuration, out ushort time)
		{
			time = default(ushort);
			return false;
		}
	}
}
