using System;

namespace CommandSystem.Commands.RemoteAdmin.Broadcasts
{
	[CommandHandler(typeof(RemoteAdminCommandHandler))]
	public class PlayerBroadcastCommand : BroadcastCommandBase
	{
		public override string Command { get; }

		public override string[] Aliases { get; }

		public override string Description { get; }

		public override string[] Usage { get; }

		public override bool OnExecute(ArraySegment<string> arguments, ICommandSender sender, out string response)
		{
			response = null;
			return false;
		}
	}
}
