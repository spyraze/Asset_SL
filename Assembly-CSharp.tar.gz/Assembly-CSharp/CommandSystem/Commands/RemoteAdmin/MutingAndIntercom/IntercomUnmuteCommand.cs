using System;

namespace CommandSystem.Commands.RemoteAdmin.MutingAndIntercom
{
	[CommandHandler(typeof(RemoteAdminCommandHandler))]
	public class IntercomUnmuteCommand : ICommand, IUsageProvider
	{
		public string Command { get; }

		public string[] Aliases { get; }

		public string Description { get; }

		public string[] Usage { get; }

		public bool Execute(ArraySegment<string> arguments, ICommandSender sender, out string response)
		{
			response = null;
			return false;
		}
	}
}
