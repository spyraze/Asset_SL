using System;
using UnityEngine;

namespace CommandSystem.Commands.RemoteAdmin.Doors
{
	[CommandHandler(typeof(RemoteAdminCommandHandler))]
	public class DoorTPCommand : ICommand, IUsageProvider
	{
		private const float WallDetectionRadius = 0.35f;

		public string Command { get; }

		public string[] Aliases { get; }

		public string Description { get; }

		public string[] Usage { get; }

		public bool Execute(ArraySegment<string> arguments, ICommandSender sender, out string response)
		{
			response = null;
			return false;
		}

		public static Vector3 EnsurePositionSafety(Transform doorTransform)
		{
			return default(Vector3);
		}
	}
}
