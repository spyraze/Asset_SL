using Interactables.Interobjects.DoorUtils;

namespace CommandSystem.Commands.RemoteAdmin.Doors
{
	[CommandHandler(typeof(RemoteAdminCommandHandler))]
	public class OpenDoorCommand : BaseDoorCommand
	{
		public override string Command { get; }

		public override string[] Aliases { get; }

		public override string Description { get; }

		protected override void OnTargetFound(DoorVariant door)
		{
		}
	}
}
