using System;
using MEC;
using MapGeneration;

namespace CommandSystem.Commands.RemoteAdmin.Doors
{
	[CommandHandler(typeof(RemoteAdminCommandHandler))]
	public class LockdownCommand : ICommand, IUsageProvider
	{
		private CoroutineHandle _lockdownHandle;

		public string Command { get; }

		public string[] Aliases { get; }

		public string Description { get; }

		public string[] Usage { get; }

		public bool Execute(ArraySegment<string> arguments, ICommandSender sender, out string response)
		{
			response = null;
			return false;
		}

		private void Lockdown(FacilityZone zoneToAffect, float duration, bool doLock, out string commandResponse)
		{
			commandResponse = null;
		}
	}
}
