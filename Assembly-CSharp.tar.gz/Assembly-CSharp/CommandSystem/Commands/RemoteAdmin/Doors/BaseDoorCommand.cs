using System;
using Interactables.Interobjects.DoorUtils;

namespace CommandSystem.Commands.RemoteAdmin.Doors
{
	public abstract class BaseDoorCommand : ICommand, IUsageProvider
	{
		public abstract string Command { get; }

		public abstract string[] Aliases { get; }

		public abstract string Description { get; }

		public virtual string[] Usage { get; }

		public virtual bool AllowNonDamageableTargets => false;

		public bool Execute(ArraySegment<string> arguments, ICommandSender sender, out string response)
		{
			response = null;
			return false;
		}

		protected abstract void OnTargetFound(DoorVariant door);
	}
}
