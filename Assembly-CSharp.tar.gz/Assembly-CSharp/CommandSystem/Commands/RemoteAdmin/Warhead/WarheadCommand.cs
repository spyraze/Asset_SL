using System;

namespace CommandSystem.Commands.RemoteAdmin.Warhead
{
	[CommandHandler(typeof(RemoteAdminCommandHandler))]
	public class WarheadCommand : ParentCommand, IUsageProvider
	{
		public override string Command { get; }

		public override string[] Aliases { get; }

		public override string Description { get; }

		public string[] Usage { get; }

		public static WarheadCommand Create()
		{
			return null;
		}

		protected override bool ExecuteParent(ArraySegment<string> arguments, ICommandSender sender, out string response)
		{
			response = null;
			return false;
		}

		public override void LoadGeneratedCommands()
		{
		}
	}
}
