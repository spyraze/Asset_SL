using System;

namespace CommandSystem.Commands.RemoteAdmin.Stripdown
{
	[CommandHandler(typeof(GameConsoleCommandHandler))]
	[CommandHandler(typeof(RemoteAdminCommandHandler))]
	public class StripdownCommand : ParentCommand, IUsageProvider
	{
		public override string Command { get; }

		public override string[] Aliases => null;

		public override string Description { get; }

		public string[] Usage { get; }

		public static StripdownCommand Create()
		{
			return null;
		}

		protected override bool ExecuteParent(ArraySegment<string> arguments, ICommandSender sender, out string response)
		{
			response = null;
			return false;
		}

		public override void LoadGeneratedCommands()
		{
		}
	}
}
