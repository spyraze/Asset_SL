using System;
using System.Reflection;
using System.Text;

namespace CommandSystem.Commands.RemoteAdmin.Stripdown
{
	public static class StripdownProcessor
	{
		private static readonly StringBuilder ReturnSb;

		private static object[] _selections;

		private static Type _selectedType;

		private const BindingFlags SearchFlags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;

		private static string PrintMembers(object obj, MemberInfo[] infos)
		{
			return null;
		}

		private static string PrintObjToString(object obj)
		{
			return null;
		}

		private static MemberInfo GetValueMemberByName(string name)
		{
			return null;
		}

		public static int SelectUnityObjects(string typeName)
		{
			return 0;
		}

		public static void SelectValues(string valueName)
		{
		}

		public static void SelectComponent(string componentName)
		{
		}

		public static string[] Print(params string[] valueNames)
		{
			return null;
		}
	}
}
