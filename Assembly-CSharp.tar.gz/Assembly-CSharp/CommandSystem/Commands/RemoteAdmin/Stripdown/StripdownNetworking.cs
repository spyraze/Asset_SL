using Mirror;
using UnityEngine;

namespace CommandSystem.Commands.RemoteAdmin.Stripdown
{
	public static class StripdownNetworking
	{
		public struct StripdownResponse : NetworkMessage
		{
			public string[] Lines;
		}

		private static long _lastTime;

		public static bool FileExportEnabled { get; set; }

		[RuntimeInitializeOnLoadMethod]
		private static void Init()
		{
		}

		public static void ProcessMessage(StripdownResponse file)
		{
		}
	}
}
