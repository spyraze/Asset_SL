using System;
using System.Text;
using Mirror;

namespace CommandSystem.Commands.RemoteAdmin.Stripdown
{
	[CommandHandler(typeof(StripdownCommand))]
	public abstract class StripdownInstructionBase : ICommand
	{
		private static readonly StringBuilder Combiner;

		public abstract string Command { get; }

		public string[] Aliases => null;

		public abstract string Description { get; }

		public bool Execute(ArraySegment<string> arguments, ICommandSender sender, out string response)
		{
			response = null;
			return false;
		}

		protected abstract string ProcessInstruction(NetworkConnection conn, string instruction);
	}
}
