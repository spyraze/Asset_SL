using Mirror;

namespace CommandSystem.Commands.RemoteAdmin.Stripdown
{
	[CommandHandler(typeof(StripdownCommand))]
	public class StripdownValueCommand : StripdownInstructionBase
	{
		public override string Command => null;

		public override string Description => null;

		protected override string ProcessInstruction(NetworkConnection sender, string instruction)
		{
			return null;
		}
	}
}
