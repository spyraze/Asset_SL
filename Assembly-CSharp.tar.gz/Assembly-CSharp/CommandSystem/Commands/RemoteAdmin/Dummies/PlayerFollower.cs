using UnityEngine;

namespace CommandSystem.Commands.RemoteAdmin.Dummies
{
	public class PlayerFollower : MonoBehaviour
	{
		private const float DefaultMaxDistance = 20f;

		private const float DefaultMinDistance = 1.75f;

		private const float DefaultSpeed = 30f;

		private ReferenceHub _hub;

		private ReferenceHub _hubToFollow;

		private float _maxDistance;

		private float _minDistance;

		private float _speed;

		public void Init(ReferenceHub playerToFollow, float maxDistance = 20f, float minDistance = 1.75f, float speed = 30f)
		{
		}

		private void Update()
		{
		}
	}
}
