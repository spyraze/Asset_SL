using System;

namespace CommandSystem.Commands.RemoteAdmin.Dummies
{
	[CommandHandler(typeof(RemoteAdminCommandHandler))]
	public class DummiesCommand : ParentCommand, IUsageProvider
	{
		public override string Command { get; }

		public override string[] Aliases { get; }

		public override string Description { get; }

		public string[] Usage { get; }

		public static DummiesCommand Create()
		{
			return null;
		}

		protected override bool ExecuteParent(ArraySegment<string> arguments, ICommandSender sender, out string response)
		{
			response = null;
			return false;
		}

		public override void LoadGeneratedCommands()
		{
		}
	}
}
