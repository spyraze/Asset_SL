using Mirror;
using UnityEngine;

namespace CommandSystem.Commands.RemoteAdmin.Cleanup
{
	public static class DecalCleanupMessageExtensions
	{
		[RuntimeInitializeOnLoadMethod]
		private static void Init()
		{
		}

		private static void ClientMessageReceived(DecalCleanupMessage message)
		{
		}

		public static void WriteDecalCleanupMessage(this NetworkWriter writer, DecalCleanupMessage msg)
		{
		}

		public static DecalCleanupMessage ReadRadioStatusMessage(this NetworkReader reader)
		{
			return default(DecalCleanupMessage);
		}
	}
}
