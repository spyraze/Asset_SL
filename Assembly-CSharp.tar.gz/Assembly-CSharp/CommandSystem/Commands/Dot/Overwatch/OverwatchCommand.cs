using System;

namespace CommandSystem.Commands.Dot.Overwatch
{
	[CommandHandler(typeof(ClientCommandHandler))]
	public class OverwatchCommand : ParentCommand
	{
		public override string Command { get; }

		public override string[] Aliases { get; }

		public override string Description { get; }

		public static OverwatchCommand Create()
		{
			return null;
		}

		protected override bool ExecuteParent(ArraySegment<string> arguments, ICommandSender sender, out string response)
		{
			response = null;
			return false;
		}

		public override void LoadGeneratedCommands()
		{
		}

		internal static bool SetOverwatchStatus(ICommandSender sender, int status, out string response)
		{
			response = null;
			return false;
		}
	}
}
